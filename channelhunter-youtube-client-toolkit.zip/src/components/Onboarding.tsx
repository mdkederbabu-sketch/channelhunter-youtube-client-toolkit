import { useState } from "react";
import { useSettings } from "@/lib/settings";
import { NICHES, SERVICES } from "@/lib/types";
import { Button, Dialog, Field, Input, Progress } from "./ui";
import { cn } from "@/utils/cn";

/** 4-step first-visit welcome (no account): services → niches → subscriber range → weekly goals. */
export function Onboarding() {
  const [s, save] = useSettings();
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState({ name: s.profile.name, services: s.services, niches: s.niches, subRange: s.subRange, weeklyGoals: s.weeklyGoals });
  if (s.onboarded) return null;

  const toggle = <T extends string>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  const finish = () => save({ ...draft, profile: { ...s.profile, name: draft.name }, onboarded: true });
  const Chip = ({ active, onClick, children }: { active: boolean; onClick: () => void; children: string }) => (
    <button onClick={onClick} className={cn("rounded-full border px-3 py-1.5 text-xs transition", active ? "border-brand bg-brand text-white" : "border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800")}>{children}</button>
  );

  return (
    <Dialog open onClose={finish} title={`Welcome to ChannelHunter · step ${step + 1} of 4`} footer={<>{step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)}>Back</Button>}{step < 3 ? <Button onClick={() => setStep(step + 1)}>Next</Button> : <Button onClick={finish}>Start hunting</Button>}</>}>
      <Progress value={((step + 1) / 4) * 100} className="mb-4" />
      {step === 0 && (
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-300">No account needed – everything stays in your browser. First, what do you sell?</p>
          <Field label="Your name (used in messages & reports)"><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Rafi" /></Field>
          <div className="flex flex-wrap gap-2">{SERVICES.map((x) => <Chip key={x} active={draft.services.includes(x)} onClick={() => setDraft({ ...draft, services: toggle(draft.services, x) })}>{x}</Chip>)}</div>
        </div>
      )}
      {step === 1 && (
        <div className="space-y-3">
          <p className="text-sm text-slate-600 dark:text-slate-300">Which business niches do you want to hunt? (They have budgets and a reason to grow.)</p>
          <div className="flex flex-wrap gap-2">{NICHES.map((x) => <Chip key={x} active={draft.niches.includes(x)} onClick={() => setDraft({ ...draft, niches: toggle(draft.niches, x) })}>{x}</Chip>)}</div>
        </div>
      )}
      {step === 2 && (
        <div className="space-y-3">
          <p className="text-sm text-slate-600 dark:text-slate-300">Subscriber range. Sweet spot: 1K-100K – big enough to pay, small enough to need you. 1M+ channels are skipped automatically.</p>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Min"><Input type="number" value={draft.subRange.min} onChange={(e) => setDraft({ ...draft, subRange: { ...draft.subRange, min: +e.target.value } })} /></Field>
            <Field label="Max"><Input type="number" value={draft.subRange.max} onChange={(e) => setDraft({ ...draft, subRange: { ...draft.subRange, max: +e.target.value } })} /></Field>
          </div>
        </div>
      )}
      {step === 3 && (
        <div className="space-y-3">
          <p className="text-sm text-slate-600 dark:text-slate-300">Weekly goals (editable later on the Dashboard).</p>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Channels found"><Input type="number" value={draft.weeklyGoals.found} onChange={(e) => setDraft({ ...draft, weeklyGoals: { ...draft.weeklyGoals, found: +e.target.value } })} /></Field>
            <Field label="Audits"><Input type="number" value={draft.weeklyGoals.audits} onChange={(e) => setDraft({ ...draft, weeklyGoals: { ...draft.weeklyGoals, audits: +e.target.value } })} /></Field>
            <Field label="Messages"><Input type="number" value={draft.weeklyGoals.messages} onChange={(e) => setDraft({ ...draft, weeklyGoals: { ...draft.weeklyGoals, messages: +e.target.value } })} /></Field>
            <Field label="Content posts"><Input type="number" value={draft.weeklyGoals.posts} onChange={(e) => setDraft({ ...draft, weeklyGoals: { ...draft.weeklyGoals, posts: +e.target.value } })} /></Field>
          </div>
          <p className="rounded-lg bg-slate-50 p-3 text-xs text-slate-500 dark:bg-slate-800">Tip: add your free YouTube API key in Settings to unlock the Channel Finder. Without it the app works in Manual Mode.</p>
        </div>
      )}
    </Dialog>
  );
}
