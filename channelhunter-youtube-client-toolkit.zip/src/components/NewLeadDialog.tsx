import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Dialog, Field, Input, Select, Textarea } from "./ui";
import { useToast } from "./toast";
import { NICHES } from "@/lib/types";
import { hasApiKey, resolveChannel, getRecentVideos, enrichWithVideos } from "@/lib/youtube";
import { createLeadFromChannel, createManualLead } from "@/lib/leads";

/** Global "N" dialog: add a lead by URL/@handle (API) or by hand (Manual Mode). */
export function NewLeadDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { toast } = useToast();
  const nav = useNavigate();
  const api = hasApiKey();
  const [mode, setMode] = useState<"url" | "manual">(api ? "url" : "manual");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [m, setM] = useState({ name: "", channelId: "", subs: "", avgViews: "", niche: NICHES[0] as string, website: "", email: "", description: "", lastUpload: "" });

  const submitUrl = async () => {
    if (!url.trim()) return;
    setBusy(true);
    try {
      const ch = await resolveChannel(url);
      if (!ch) throw new Error("Channel not found");
      const vids = await getRecentVideos(ch.channelId, 15).catch(() => []);
      const lead = await createLeadFromChannel(enrichWithVideos(ch, vids));
      toast(`Added ${lead.name}`);
      onClose();
      nav(`/leads?open=${lead.id}`);
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };

  const submitManual = async () => {
    if (!m.name.trim()) return toast("Channel name is required", "warning");
    setBusy(true);
    try {
      const lead = await createManualLead({ ...m, subs: Number(m.subs) || 0, avgViews: Number(m.avgViews) || undefined, channelId: m.channelId || undefined });
      toast(`Added ${lead.name}`);
      onClose();
      nav(`/leads?open=${lead.id}`);
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} title="New lead">
      <div className="mb-4 flex gap-2 text-xs">
        <button className={`rounded-md px-3 py-1.5 ${mode === "url" ? "bg-brand text-white" : "bg-slate-100 dark:bg-slate-800"}`} onClick={() => setMode("url")}>
          From URL / @handle {api ? "" : "(needs API key)"}
        </button>
        <button className={`rounded-md px-3 py-1.5 ${mode === "manual" ? "bg-brand text-white" : "bg-slate-100 dark:bg-slate-800"}`} onClick={() => setMode("manual")}>
          Manual Mode
        </button>
      </div>
      {mode === "url" ? (
        <div className="space-y-3">
          <Field label="Channel URL, @handle, channel ID or video URL">
            <Input autoFocus placeholder="https://youtube.com/@creator or @creator" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submitUrl()} />
          </Field>
          <p className="text-[11px] text-slate-500">Costs ~3 API units (channels.list + playlistItems.list + videos.list). Cached 24h.</p>
          <div className="flex justify-end">
            <Button onClick={submitUrl} disabled={busy || !api}>
              {busy ? "Resolving…" : "Add lead"}
            </Button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <Field label="Channel name *" className="col-span-2">
            <Input autoFocus value={m.name} onChange={(e) => setM({ ...m, name: e.target.value })} />
          </Field>
          <Field label="Channel ID / URL">
            <Input value={m.channelId} onChange={(e) => setM({ ...m, channelId: e.target.value })} placeholder="UC… (optional)" />
          </Field>
          <Field label="Niche">
            <Select value={m.niche} onChange={(e) => setM({ ...m, niche: e.target.value })}>
              {NICHES.map((n) => (
                <option key={n}>{n}</option>
              ))}
            </Select>
          </Field>
          <Field label="Subscribers">
            <Input type="number" value={m.subs} onChange={(e) => setM({ ...m, subs: e.target.value })} />
          </Field>
          <Field label="Avg views (last 10)">
            <Input type="number" value={m.avgViews} onChange={(e) => setM({ ...m, avgViews: e.target.value })} />
          </Field>
          <Field label="Last upload date">
            <Input type="date" value={m.lastUpload} onChange={(e) => setM({ ...m, lastUpload: e.target.value })} />
          </Field>
          <Field label="Website">
            <Input value={m.website} onChange={(e) => setM({ ...m, website: e.target.value })} />
          </Field>
          <Field label="Business email">
            <Input value={m.email} onChange={(e) => setM({ ...m, email: e.target.value })} />
          </Field>
          <Field label="About / description (paste)" className="col-span-2">
            <Textarea value={m.description} onChange={(e) => setM({ ...m, description: e.target.value })} className="min-h-[70px]" />
          </Field>
          <div className="col-span-2 flex justify-end">
            <Button onClick={submitManual} disabled={busy}>
              Add lead
            </Button>
          </div>
        </div>
      )}
    </Dialog>
  );
}
