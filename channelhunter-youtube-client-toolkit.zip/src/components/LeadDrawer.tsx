import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Link } from "react-router-dom";
import { format, formatDistanceToNow } from "date-fns";
import { ExternalLink, Trash2, ShieldOff, Printer } from "lucide-react";
import { db, logActivity, nowIso, setLeadStage, stopFollowUps } from "@/lib/db";
import { deleteLead, rescoreLead } from "@/lib/leads";
import { useSettings } from "@/lib/settings";
import { auditReportHtml, openPrintWindow } from "@/lib/report";
import { NICHES, STAGES, type ContactInfo, type Lead } from "@/lib/types";
import { Badge, Button, Checkbox, Drawer, Field, Input, ScoreBadge, Select, Tabs, Textarea, fmt } from "./ui";
import { useToast } from "./toast";

type Tab = "overview" | "contact" | "audit" | "messages" | "timeline";

export function channelUrl(l: Lead) {
  if (l.channelId.startsWith("UC")) return `https://www.youtube.com/channel/${l.channelId}`;
  if (l.handle) return `https://www.youtube.com/${l.handle}`;
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(l.name)}`;
}

export function LeadDrawer({ leadId, onClose }: { leadId: number | null; onClose: () => void }) {
  const lead = useLiveQuery(() => (leadId ? db.leads.get(leadId) : undefined), [leadId]);
  const [tab, setTab] = useState<Tab>("overview");
  useEffect(() => setTab("overview"), [leadId]);
  return (
    <Drawer open={!!leadId} onClose={onClose} title={lead ? <span className="flex items-center gap-2">{lead.avatar && <img src={lead.avatar} className="h-7 w-7 rounded-full" alt="" />}{lead.name}</span> : "Lead"}>
      {lead && (
        <>
          <Tabs
            value={tab}
            onChange={setTab}
            className="mb-4"
            tabs={[
              { value: "overview", label: "Overview" },
              { value: "contact", label: "Contact" },
              { value: "audit", label: "Audit" },
              { value: "messages", label: "Messages" },
              { value: "timeline", label: "Timeline" },
            ]}
          />
          {tab === "overview" && <Overview lead={lead} onClose={onClose} />}
          {tab === "contact" && <ContactTab lead={lead} />}
          {tab === "audit" && <AuditTab lead={lead} />}
          {tab === "messages" && <MessagesTab lead={lead} />}
          {tab === "timeline" && <TimelineTab lead={lead} />}
        </>
      )}
    </Drawer>
  );
}

function Overview({ lead, onClose }: { lead: Lead; onClose: () => void }) {
  const { toast } = useToast();
  const [notes, setNotes] = useState(lead.notes);
  const [tags, setTags] = useState(lead.tags.join(", "));
  useEffect(() => {
    setNotes(lead.notes);
    setTags(lead.tags.join(", "));
  }, [lead.id, lead.notes, lead.tags]);
  const update = (patch: Partial<Lead>) => db.leads.update(lead.id!, { ...patch, updatedAt: nowIso() });
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <ScoreBadge score={lead.score} label={lead.scoreLabel} />
        <Badge color="brand">{lead.niche}</Badge>
        <Badge>{lead.stage}</Badge>
        {lead.doNotContact && <Badge color="red">Do not contact</Badge>}
        <a href={channelUrl(lead)} target="_blank" rel="noreferrer" className="ml-auto inline-flex items-center gap-1 text-xs text-brand hover:underline">
          Open channel <ExternalLink className="h-3 w-3" />
        </a>
      </div>
      <div className="grid grid-cols-3 gap-2 text-center sm:grid-cols-6">
        {[
          ["Subs", fmt(lead.subs)],
          ["Total views", fmt(lead.totalViews)],
          ["Avg views", fmt(lead.avgViews)],
          ["Views/sub", lead.viewsToSubRatio !== undefined ? `${Math.round(lead.viewsToSubRatio * 100)}%` : "–"],
          ["Uploads/mo", lead.uploadsPerMonth ?? "–"],
          ["Last upload", lead.lastUpload ? formatDistanceToNow(new Date(lead.lastUpload), { addSuffix: true }).replace("about ", "") : "–"],
        ].map(([k, v]) => (
          <div key={k as string} className="rounded-lg bg-slate-50 p-2 dark:bg-slate-800">
            <div className="text-[10px] text-slate-500">{k}</div>
            <div className="text-sm font-semibold">{v}</div>
          </div>
        ))}
      </div>
      {lead.scoreBreakdown && (
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] sm:grid-cols-4">
          {Object.entries(lead.scoreBreakdown).map(([k, v]) => (
            <div key={k} className="flex justify-between">
              <span className="text-slate-500">{k}</span>
              <span className="font-medium">{v}</span>
            </div>
          ))}
        </div>
      )}
      <div className="grid grid-cols-2 gap-3">
        <Field label="Stage">
          <Select value={lead.stage} onChange={(e) => setLeadStage(lead.id!, e.target.value as Lead["stage"])}>
            {STAGES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </Select>
        </Field>
        <Field label="Niche">
          <Select value={lead.niche} onChange={async (e) => { await update({ niche: e.target.value }); rescoreLead(lead.id!); }}>
            {NICHES.map((n) => (
              <option key={n}>{n}</option>
            ))}
          </Select>
        </Field>
        <Field label="Deal value ($)">
          <Input type="number" value={lead.dealValue || ""} onChange={(e) => update({ dealValue: Number(e.target.value) || 0 })} />
        </Field>
        <Field label="Deal type">
          <Select value={lead.dealType} onChange={(e) => update({ dealType: e.target.value as Lead["dealType"] })}>
            <option value="one-time">One-time</option>
            <option value="retainer">Monthly retainer</option>
          </Select>
        </Field>
        <Field label="Tags (comma separated)" className="col-span-2">
          <Input value={tags} onChange={(e) => setTags(e.target.value)} onBlur={() => update({ tags: tags.split(",").map((t) => t.trim()).filter(Boolean) })} />
        </Field>
        <Field label="Notes" className="col-span-2">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} onBlur={() => notes !== lead.notes && update({ notes })} />
        </Field>
      </div>
      {lead.description && (
        <details className="text-xs">
          <summary className="cursor-pointer font-medium">About / description</summary>
          <p className="mt-1 whitespace-pre-wrap text-slate-500">{lead.description.slice(0, 1200)}</p>
        </details>
      )}
      <div className="flex flex-wrap gap-2 border-t border-slate-200 pt-4 dark:border-slate-800">
        <Link to={`/audit/${lead.id}`}><Button size="sm" variant="secondary">Run audit</Button></Link>
        <Link to={`/outreach?lead=${lead.id}`}><Button size="sm" variant="secondary">Write message</Button></Link>
        <Link to={`/proposals?lead=${lead.id}`}><Button size="sm" variant="secondary">Proposal</Button></Link>
        <Button size="sm" variant="outline" onClick={async () => { await update({ doNotContact: !lead.doNotContact }); if (!lead.doNotContact) { await stopFollowUps(lead.id!); toast("Marked do-not-contact; follow-ups stopped", "info"); } }}>
          <ShieldOff className="h-3.5 w-3.5" /> {lead.doNotContact ? "Allow contact" : "Do not contact"}
        </Button>
        <Button size="sm" variant="danger" className="ml-auto" onClick={async () => { if (confirm(`Delete ${lead.name} and all its data?`)) { await deleteLead(lead.id!); onClose(); toast("Lead deleted", "info"); } }}>
          <Trash2 className="h-3.5 w-3.5" /> Delete
        </Button>
      </div>
    </div>
  );
}

const CONTACT_FIELDS: { key: keyof ContactInfo; label: string; placeholder?: string }[] = [
  { key: "email", label: "Business email", placeholder: "hello@…" },
  { key: "website", label: "Website", placeholder: "https://" },
  { key: "instagram", label: "Instagram" },
  { key: "linkedin", label: "LinkedIn" },
  { key: "x", label: "X / Twitter" },
  { key: "facebook", label: "Facebook" },
  { key: "whatsapp", label: "Telegram / WhatsApp" },
  { key: "source", label: "Where found (source)", placeholder: "About tab, banner link…" },
];

export function ContactTab({ lead }: { lead: Lead }) {
  const [c, setC] = useState<ContactInfo>(lead.contact);
  useEffect(() => setC(lead.contact), [lead.id, lead.contact]);
  const save = (next: ContactInfo) => {
    setC(next);
    db.leads.update(lead.id!, { contact: next, updatedAt: nowIso() });
  };
  const owner = lead.name;
  const links = [
    { label: "Channel About page", href: `${channelUrl(lead)}/about` },
    { label: `Google: "${owner}" contact email`, href: `https://www.google.com/search?q=${encodeURIComponent(`"${owner}" contact email`)}` },
    { label: "LinkedIn people search", href: `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(owner)}` },
    ...(c.website ? [{ label: "Channel website", href: c.website.startsWith("http") ? c.website : `https://${c.website}` }] : []),
  ];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {links.map((l) => (
          <a key={l.label} href={l.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">
            {l.label} <ExternalLink className="h-3 w-3" />
          </a>
        ))}
      </div>
      <div className="rounded-lg bg-slate-50 p-3 text-xs dark:bg-slate-800">
        <div className="mb-1 font-medium">Where to look (manual, compliance-first)</div>
        <ul className="list-inside list-disc space-y-0.5 text-slate-500">
          <li>About tab → "View email address" (business inquiries)</li>
          <li>Banner links & description links</li>
          <li>Website → Contact / About page</li>
          <li>LinkedIn profile of the owner (DM or email in Contact info)</li>
          <li>Instagram bio / X bio</li>
        </ul>
        <p className="mt-2 text-[11px] text-slate-400">Never use scraped or purchased lists. Only contact details the creator published for business inquiries.</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {CONTACT_FIELDS.map((f) => (
          <Field key={f.key} label={f.label}>
            <Input value={c[f.key] as string} placeholder={f.placeholder} onChange={(e) => save({ ...c, [f.key]: e.target.value })} />
          </Field>
        ))}
        <Field label="Contact notes" className="col-span-2">
          <Textarea value={c.notes} onChange={(e) => save({ ...c, notes: e.target.value })} className="min-h-[60px]" />
        </Field>
      </div>
      <div className="flex flex-wrap gap-4">
        <Checkbox checked={c.found} onChange={(v) => save({ ...c, found: v })} label="Contact found?" />
        <Checkbox checked={lead.doNotContact} onChange={async (v) => { await db.leads.update(lead.id!, { doNotContact: v }); if (v) await stopFollowUps(lead.id!); }} label="Do not contact" />
      </div>
    </div>
  );
}

function AuditTab({ lead }: { lead: Lead }) {
  const audits = useLiveQuery(() => db.audits.where("leadId").equals(lead.id!).reverse().sortBy("createdAt"), [lead.id]);
  const [settings] = useSettings();
  if (!audits?.length)
    return (
      <div className="space-y-3 text-sm">
        <p className="text-slate-500">No audit yet. Run the 5-minute audit to collect pitch proof.</p>
        <Link to={`/audit/${lead.id}`}><Button size="sm">Run audit</Button></Link>
      </div>
    );
  const a = audits[0];
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="text-4xl font-bold text-brand">{a.overall}<span className="text-base text-slate-400">/100</span></div>
        <div className="text-xs text-slate-500">{format(new Date(a.createdAt), "d MMM yyyy")} · {audits.length} audit(s)</div>
        <div className="ml-auto flex gap-2">
          <Link to={`/audit/${lead.id}`}><Button size="sm" variant="outline">Re-audit</Button></Link>
          <Button size="sm" variant="secondary" onClick={() => openPrintWindow(auditReportHtml(lead, a, settings))}><Printer className="h-3.5 w-3.5" /> Report</Button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {Object.entries(a.categories).map(([k, v]) => (
          <div key={k} className="rounded-lg bg-slate-50 p-2 text-xs dark:bg-slate-800">
            <div className="flex justify-between"><span className="text-slate-500">{k}</span><b>{v}</b></div>
            <div className="mt-1 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700"><div className="h-full rounded-full bg-brand" style={{ width: `${v}%` }} /></div>
          </div>
        ))}
      </div>
      <p className="text-sm">{a.summary}</p>
      <div>
        <div className="mb-1 text-xs font-semibold">Top problems</div>
        <ol className="list-inside list-decimal space-y-1 text-xs">{a.problems.slice(0, 5).map((p, i) => <li key={i}><b>{p.category}:</b> {p.issue} → <i className="text-slate-500">{p.fix}</i></li>)}</ol>
      </div>
      <div>
        <div className="mb-1 text-xs font-semibold">Quick wins</div>
        <ul className="list-inside list-disc space-y-1 text-xs">{a.quickWins.map((w, i) => <li key={i}>{w}</li>)}</ul>
      </div>
    </div>
  );
}

function MessagesTab({ lead }: { lead: Lead }) {
  const msgs = useLiveQuery(() => db.messages.where("leadId").equals(lead.id!).reverse().sortBy("sentAt"), [lead.id]);
  if (!msgs?.length) return <p className="text-sm text-slate-500">No messages logged yet. Use Outreach Studio → "Mark as sent".</p>;
  return (
    <div className="space-y-3">
      {msgs.map((m) => (
        <div key={m.id} className="rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800">
          <div className="mb-1 flex flex-wrap items-center gap-2 text-slate-500">
            <Badge color="brand">{m.kind === "first" ? "First message" : m.kind === "followup" ? `Follow-up day ${m.followUpDay}` : "Comment"}</Badge>
            <span>{m.medium}</span>·<span>{m.service}</span>·<span>{m.tone}</span>·<span>{m.language}</span>
            <span className="ml-auto">{format(new Date(m.sentAt), "d MMM, HH:mm")}</span>
          </div>
          {m.subject && <div className="font-medium">Subject: {m.subject}</div>}
          <p className="whitespace-pre-wrap">{m.body}</p>
        </div>
      ))}
    </div>
  );
}

function TimelineTab({ lead }: { lead: Lead }) {
  const acts = useLiveQuery(() => db.activities.where("leadId").equals(lead.id!).reverse().sortBy("at"), [lead.id]);
  const tasks = useLiveQuery(() => db.tasks.where("leadId").equals(lead.id!).sortBy("dueAt"), [lead.id]);
  const [note, setNote] = useState("");
  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input placeholder="Add a note to the timeline…" value={note} onChange={(e) => setNote(e.target.value)} />
        <Button size="sm" onClick={async () => { if (note.trim()) { await logActivity("note", note.trim(), lead.id); setNote(""); } }}>Add</Button>
      </div>
      {!!tasks?.filter((t) => !t.done).length && (
        <div className="rounded-lg bg-amber-50 p-3 text-xs dark:bg-amber-950/30">
          <div className="mb-1 font-medium">Pending follow-ups</div>
          {tasks.filter((t) => !t.done).map((t) => <div key={t.id}>• {t.title} – {format(new Date(t.dueAt), "d MMM")}</div>)}
        </div>
      )}
      <ol className="relative space-y-3 border-l border-slate-200 pl-4 dark:border-slate-800">
        {acts?.map((a) => (
          <li key={a.id} className="text-xs">
            <span className="absolute -left-1 mt-1 h-2 w-2 rounded-full bg-brand" />
            <div>{a.text}</div>
            <div className="text-[10px] text-slate-400">{format(new Date(a.at), "d MMM yyyy, HH:mm")} · {a.type}</div>
          </li>
        ))}
        {!acts?.length && <li className="text-xs text-slate-500">No activity yet.</li>}
      </ol>
    </div>
  );
}
