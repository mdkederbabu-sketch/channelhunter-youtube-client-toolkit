import { useEffect, useRef, useState, type ReactNode } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import {
  LayoutDashboard, Search, ClipboardCheck, Users, MessageSquareText, BellRing, KanbanSquare, FileText, BarChart3, Settings as SettingsIcon, ListChecks, Menu, Moon, Sun, Plus, Zap, X,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { useSettings } from "@/lib/settings";
import { db, getQuotaToday, QUOTA_LIMIT, quotaDateKey } from "@/lib/db";
import { NewLeadDialog } from "./NewLeadDialog";
import { Progress } from "./ui";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/finder", label: "Channel Finder", icon: Search },
  { to: "/audit", label: "Audit Engine", icon: ClipboardCheck },
  { to: "/leads", label: "Leads & Contacts", icon: Users },
  { to: "/outreach", label: "Outreach Studio", icon: MessageSquareText },
  { to: "/followups", label: "Follow-ups", icon: BellRing },
  { to: "/pipeline", label: "Pipeline", icon: KanbanSquare },
  { to: "/proposals", label: "Proposals & Proof", icon: FileText },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/routine", label: "Daily Routine", icon: ListChecks },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
];

export function QuotaMeter({ compact = false }: { compact?: boolean }) {
  const quotaRows = useLiveQuery(() => db.quota.toArray(), []);
  const used = quotaRows?.find((q) => q.date === quotaDateKey())?.units ?? 0;
  const pct = (used / QUOTA_LIMIT) * 100;
  const color = pct >= 80 ? "bg-rose-500" : pct >= 50 ? "bg-amber-500" : "bg-emerald-500";
  return (
    <div className={cn("space-y-1", compact ? "" : "card p-4")}>
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1 font-medium">
          <Zap className="h-3.5 w-3.5" /> API quota today
        </span>
        <span className={cn(pct >= 80 && "font-semibold text-rose-500")}>
          {used.toLocaleString()} / {QUOTA_LIMIT.toLocaleString()}
        </span>
      </div>
      <Progress value={pct} color={color} />
      {!compact && <p className="text-[11px] text-slate-500">{pct >= 80 ? "⚠️ Over 80% – pause search.list calls. " : ""}Resets at midnight Pacific time.</p>}
    </div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const [settings, save] = useSettings();
  const [open, setOpen] = useState(false);
  const [newLead, setNewLead] = useState(false);
  const [q, setQ] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);
  const nav = useNavigate();
  const loc = useLocation();
  const dueCount = useLiveQuery(async () => {
    const end = new Date();
    end.setHours(23, 59, 59, 999);
    const iso = end.toISOString();
    return db.tasks.filter((t) => !t.done && t.dueAt <= iso).count();
  }, []);

  // Keyboard shortcuts: "/" focuses search, "N" opens new lead
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (e.target as HTMLElement)?.isContentEditable;
      if (e.key === "/" && !typing) {
        e.preventDefault();
        searchRef.current?.focus();
      } else if ((e.key === "n" || e.key === "N") && !typing && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setNewLead(true);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  useEffect(() => setOpen(false), [loc.pathname]);

  const toggleTheme = () => {
    const isDark = document.documentElement.classList.contains("dark");
    save({ theme: isDark ? "light" : "dark" });
  };

  useEffect(() => {
    getQuotaToday();
  }, []);

  const Sidebar = (
    <aside className="flex h-full w-64 flex-col border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-center gap-2 px-5 py-4">
        {settings.profile.logo ? <img src={settings.profile.logo} className="h-8 w-8 rounded-lg object-cover" alt="" /> : <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-white">▶</div>}
        <div>
          <div className="text-sm font-bold leading-tight">ChannelHunter</div>
          <div className="text-[10px] text-slate-500">Client-hunting toolkit</div>
        </div>
        <button className="ml-auto rounded-md p-1 lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
          <X className="h-4 w-4" />
        </button>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3">
        {NAV.map((n) => (
          <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => cn("flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition", isActive ? "bg-brand/10 font-medium text-brand" : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800")}>
            <n.icon className="h-4 w-4" />
            <span className="flex-1">{n.label}</span>
            {n.to === "/followups" && !!dueCount && <span className="rounded-full bg-rose-500 px-1.5 text-[10px] font-semibold text-white">{dueCount}</span>}
          </NavLink>
        ))}
      </nav>
      <div className="space-y-3 p-4">
        <QuotaMeter compact />
        <p className="text-[10px] leading-snug text-slate-500">This tool helps you write personalized, low-volume outreach. Sending is always manual.</p>
      </div>
    </aside>
  );

  return (
    <div className="flex h-full">
      <div className="hidden lg:block">{Sidebar}</div>
      {open && (
        <div className="fixed inset-0 z-40 flex lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <div className="relative z-10 h-full">{Sidebar}</div>
        </div>
      )}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b border-slate-200 bg-white/80 px-4 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80">
          <button className="rounded-md p-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Menu">
            <Menu className="h-5 w-5" />
          </button>
          <form
            className="relative flex-1 max-w-md"
            onSubmit={(e) => {
              e.preventDefault();
              nav(`/leads?q=${encodeURIComponent(q)}`);
            }}
          >
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input ref={searchRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search leads…  ( / )" className="input pl-9 pr-10" />
            <kbd className="kbd absolute right-2 top-1/2 -translate-y-1/2">/</kbd>
          </form>
          <div className="ml-auto flex items-center gap-1.5">
            <button onClick={() => setNewLead(true)} className="hidden items-center gap-1.5 rounded-lg bg-brand px-3 py-1.5 text-xs font-medium text-white sm:flex">
              <Plus className="h-3.5 w-3.5" /> New lead <kbd className="kbd ml-1 border-white/30 bg-white/20 text-white">N</kbd>
            </button>
            <button onClick={toggleTheme} className="rounded-lg p-2 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Toggle theme">
              <Sun className="hidden h-4 w-4 dark:block" />
              <Moon className="h-4 w-4 dark:hidden" />
            </button>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="mx-auto max-w-7xl">{children}</div>
        </main>
      </div>
      <NewLeadDialog open={newLead} onClose={() => setNewLead(false)} />
    </div>
  );
}

export function PageHeader({ title, description, action }: { title: string; description?: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-xl font-bold tracking-tight">{title}</h1>
        {description && <p className="mt-0.5 text-sm text-slate-500">{description}</p>}
      </div>
      {action && <div className="flex flex-wrap gap-2">{action}</div>}
    </div>
  );
}
