/**
 * Lead scoring – pure. Produces a 0-100 score from channel data (+ optional audit),
 * weighted by user-editable weights in Settings. Hot 75+, Warm 50-74, Cold <50.
 */
import type { Audit, ChannelData, ScoreLabel } from "./types";
import type { Weights } from "./settings";

const clamp = (n: number, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));

export interface ScoreInput {
  channel: ChannelData;
  niche?: string;
  audit?: Pick<Audit, "categories" | "metrics"> | null;
  weights: Weights;
  subRange: { min: number; max: number };
  targetNiches: string[];
}

export interface ScoreResult {
  score: number;
  label: ScoreLabel;
  breakdown: Record<string, number>; // each factor 0-100 (before weighting)
}

export function labelFor(score: number): ScoreLabel {
  return score >= 75 ? "Hot" : score >= 50 ? "Warm" : "Cold";
}

/** Subscriber fit: 100 inside range, decays outside. 1M+ is a hard 0. */
export function subFitScore(subs: number, range: { min: number; max: number }) {
  if (subs >= 1_000_000) return 0;
  if (subs >= range.min && subs <= range.max) {
    // sweet spot: middle of the range on a log scale
    return 100;
  }
  if (subs < range.min) return clamp((subs / range.min) * 70);
  return clamp(100 - ((subs - range.max) / range.max) * 60);
}

export function consistencyScore(ch: ChannelData) {
  if (!ch.lastUpload) return 50;
  const days = (Date.now() - +new Date(ch.lastUpload)) / 86400000;
  if (days > 180) return 0;
  const recency = clamp(100 - days * 1.5);
  const cadence = ch.uploadsPerMonth ? clamp(ch.uploadsPerMonth * 25) : 50;
  return Math.round(recency * 0.6 + cadence * 0.4);
}

/** Weak SEO = opportunity. Without an audit, infer from the About description. */
export function weakSeoScore(ch: ChannelData, audit?: ScoreInput["audit"]) {
  if (audit) {
    const seo = (audit.categories.Titles + audit.categories.Descriptions + audit.categories.Tags) / 3;
    return clamp(100 - seo);
  }
  const d = ch.description ?? "";
  let s = 50;
  if (d.length < 150) s += 25;
  if (!/https?:\/\//.test(d)) s += 10;
  if (!ch.keywords) s += 15;
  return clamp(s);
}

export function weakThumbScore(audit?: ScoreInput["audit"]) {
  if (!audit) return 50;
  return clamp(100 - audit.categories.Thumbnails);
}

export function businessScore(ch: ChannelData) {
  const sig = ch.businessSignals ?? [];
  const weightsMap: Record<string, number> = { website: 25, course: 25, product: 20, sponsor: 15, services: 30, contact: 10, newsletter: 10 };
  return clamp(sig.reduce((s, k) => s + (weightsMap[k] ?? 5), 0));
}

/** Big gap between subs and views = under-performing packaging = good pitch. */
export function viewsGapScore(ch: ChannelData) {
  const r = ch.viewsToSubRatio;
  if (r === undefined || !ch.subs) return 50;
  if (r < 0.05) return 100;
  if (r < 0.1) return 85;
  if (r < 0.2) return 65;
  if (r < 0.4) return 40;
  return 15;
}

export function nicheMatchScore(niche: string | undefined, targets: string[], ch: ChannelData) {
  if (niche && targets.includes(niche)) return 100;
  const text = `${ch.description ?? ""} ${ch.keywords ?? ""}`.toLowerCase();
  const hit = targets.some((t) => text.includes(t.toLowerCase().split(" ")[0]));
  return hit ? 70 : niche && niche !== "Other" ? 50 : 25;
}

export function scoreLead(input: ScoreInput): ScoreResult {
  const { channel, weights, subRange, targetNiches, niche, audit } = input;
  const breakdown = {
    subFit: subFitScore(channel.subs, subRange),
    consistency: consistencyScore(channel),
    weakSeo: weakSeoScore(channel, audit),
    weakThumb: weakThumbScore(audit),
    business: businessScore(channel),
    viewsGap: viewsGapScore(channel),
    nicheMatch: nicheMatchScore(niche, targetNiches, channel),
  };
  const totalW = Object.values(weights).reduce((s, w) => s + w, 0) || 1;
  const raw = (Object.keys(breakdown) as (keyof typeof breakdown)[]).reduce((s, k) => s + breakdown[k] * (weights[k] ?? 0), 0) / totalW;
  // Hard skips
  const dead = channel.lastUpload ? (Date.now() - +new Date(channel.lastUpload)) / 86400000 > 180 : false;
  const score = channel.subs >= 1_000_000 || dead ? Math.min(Math.round(raw), 25) : Math.round(raw);
  return { score, label: labelFor(score), breakdown };
}

/** "Skip" flag used by the finder table. */
export function skipReason(ch: ChannelData): string | null {
  if (ch.subs >= 1_000_000) return "1M+ subscribers";
  if (ch.lastUpload && (Date.now() - +new Date(ch.lastUpload)) / 86400000 > 180) return "No upload in 180 days";
  return null;
}

export const WEIGHT_LABELS: Record<keyof Weights, string> = {
  subFit: "Subscriber range fit",
  consistency: "Upload consistency",
  weakSeo: "Weak SEO signals",
  weakThumb: "Weak thumbnail signals",
  business: "Business signals",
  viewsGap: "Views-to-sub gap",
  nicheMatch: "Niche match",
};
