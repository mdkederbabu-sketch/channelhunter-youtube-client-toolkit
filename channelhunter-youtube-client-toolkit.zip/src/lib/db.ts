import Dexie, { type Table } from "dexie";
import type {
  Activity,
  Audit,
  CacheEntry,
  CaseStudy,
  IgnoredChannel,
  Lead,
  Message,
  Package,
  PitchProof,
  QuotaLog,
  SavedList,
  Stage,
  Task,
  Template,
} from "./types";
import { stageIndex } from "./types";

/** All ChannelHunter data lives in this IndexedDB database. */
export class ChannelHunterDB extends Dexie {
  leads!: Table<Lead, number>;
  audits!: Table<Audit, number>;
  proofs!: Table<PitchProof, number>;
  templates!: Table<Template, number>;
  messages!: Table<Message, number>;
  tasks!: Table<Task, number>;
  activities!: Table<Activity, number>;
  caseStudies!: Table<CaseStudy, number>;
  packages!: Table<Package, number>;
  lists!: Table<SavedList, number>;
  cache!: Table<CacheEntry, string>;
  quota!: Table<QuotaLog, string>;
  ignored!: Table<IgnoredChannel, string>;

  constructor() {
    super("channelhunter");
    this.version(1).stores({
      leads: "++id, &channelId, stage, score, niche, nextFollowUpAt, createdAt, updatedAt",
      audits: "++id, leadId, createdAt",
      proofs: "++id, leadId, auditId, category",
      templates: "++id, service, language, type, builtIn",
      messages: "++id, leadId, sentAt, kind, service, medium, templateName",
      tasks: "++id, leadId, dueAt, done",
      activities: "++id, leadId, type, at",
      caseStudies: "++id, createdAt",
      packages: "++id, name",
      lists: "++id, name",
      cache: "key, expiresAt",
      quota: "date",
      ignored: "channelId",
    });
  }
}

export const db = new ChannelHunterDB();

export const TABLE_NAMES = [
  "leads",
  "audits",
  "proofs",
  "templates",
  "messages",
  "tasks",
  "activities",
  "caseStudies",
  "packages",
  "lists",
  "quota",
  "ignored",
] as const;

export const nowIso = () => new Date().toISOString();

/** Log an activity (used by dashboard charts, weekly goals and lead timelines). */
export async function logActivity(type: Activity["type"], text: string, leadId?: number) {
  await db.activities.add({ type, text, leadId, at: nowIso() });
  if (leadId) await db.leads.update(leadId, { lastActivityAt: nowIso() });
}

/** Move a lead to a new stage, log it, and stop follow-ups when the sequence should end. */
export async function setLeadStage(leadId: number, stage: Stage) {
  const lead = await db.leads.get(leadId);
  if (!lead || lead.stage === stage) return;
  const patch: Partial<Lead> = { stage, updatedAt: nowIso(), lastActivityAt: nowIso() };
  if (stage === "Won") patch.wonAt = nowIso();
  const stopStages: Stage[] = ["Replied", "Call Booked", "Proposal Sent", "Won", "Lost"];
  if (stopStages.includes(stage)) {
    await db.tasks.where("leadId").equals(leadId).and((t) => !t.done).delete();
    patch.nextFollowUpAt = undefined;
  }
  await db.leads.update(leadId, patch);
  const typeMap: Partial<Record<Stage, Activity["type"]>> = {
    Audited: "audited",
    Contacted: "contacted",
    Replied: "replied",
    "Call Booked": "call",
    "Proposal Sent": "proposal",
    Won: "won",
    Lost: "lost",
  };
  const t = typeMap[stage] ?? "stage";
  // Only log forward moves to keep funnel counts honest
  if (stageIndex(stage) > stageIndex(lead.stage) || stage === "Lost") {
    await logActivity(t, `Moved to ${stage}`, leadId);
  }
}

/** Stop all pending follow-ups for a lead (e.g. do-not-contact). */
export async function stopFollowUps(leadId: number) {
  await db.tasks.where("leadId").equals(leadId).and((t) => !t.done).delete();
  await db.leads.update(leadId, { nextFollowUpAt: undefined });
}

/** Recompute nextFollowUpAt from pending tasks. */
export async function refreshNextFollowUp(leadId: number) {
  const pending = await db.tasks.where("leadId").equals(leadId).and((t) => !t.done).sortBy("dueAt");
  await db.leads.update(leadId, { nextFollowUpAt: pending[0]?.dueAt });
}

/* ---------------- 24h API cache ---------------- */

export async function cacheGet<T>(key: string): Promise<T | undefined> {
  const hit = await db.cache.get(key);
  if (!hit) return undefined;
  if (hit.expiresAt < Date.now()) {
    await db.cache.delete(key);
    return undefined;
  }
  return hit.value as T;
}

export async function cacheSet(key: string, value: unknown, ttlMs = 24 * 60 * 60 * 1000) {
  await db.cache.put({ key, value, expiresAt: Date.now() + ttlMs });
}

export async function purgeExpiredCache() {
  await db.cache.where("expiresAt").below(Date.now()).delete();
}

/* ---------------- Quota tracking ---------------- */

/** Google resets quota at midnight Pacific Time. */
export function quotaDateKey(d = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Los_Angeles",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

export async function addQuota(units: number) {
  const date = quotaDateKey();
  const row = await db.quota.get(date);
  await db.quota.put({ date, units: (row?.units ?? 0) + units });
}

export async function getQuotaToday() {
  const row = await db.quota.get(quotaDateKey());
  return row?.units ?? 0;
}

export const QUOTA_LIMIT = 10000;
