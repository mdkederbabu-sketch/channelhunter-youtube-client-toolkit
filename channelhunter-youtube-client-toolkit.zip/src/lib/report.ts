/** Printable, branded HTML for audit reports and proposals (opens a window and calls print). */
import { format } from "date-fns";
import type { Settings } from "./settings";
import type { Audit, CaseStudy, Lead, Package } from "./types";

const esc = (s: unknown) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);

function shell(title: string, body: string, s: Settings) {
  const accent = s.profile.accentColor || "#6366f1";
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>
  :root{--a:${accent}}
  *{box-sizing:border-box} body{font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;margin:0;padding:40px;max-width:900px;margin:auto;line-height:1.5}
  header{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid var(--a);padding-bottom:16px;margin-bottom:28px}
  header img{height:44px;border-radius:8px} .brand{font-weight:700;font-size:20px} .muted{color:#64748b;font-size:13px}
  h1{font-size:26px;margin:0 0 4px} h2{font-size:17px;margin:28px 0 10px;color:var(--a);text-transform:uppercase;letter-spacing:.04em}
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
  .kpi{border:1px solid #e2e8f0;border-radius:12px;padding:12px} .kpi b{font-size:22px;display:block} .kpi span{font-size:12px;color:#64748b}
  .bar{height:8px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin-top:6px} .bar i{display:block;height:100%;background:var(--a)}
  table{width:100%;border-collapse:collapse;font-size:14px} td,th{padding:8px;border-bottom:1px solid #e2e8f0;text-align:left;vertical-align:top}
  .score{font-size:48px;font-weight:800;color:var(--a)} .pill{display:inline-block;padding:2px 10px;border-radius:99px;background:var(--a);color:#fff;font-size:12px}
  .box{border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin:10px 0} .pkg{border:2px solid #e2e8f0;border-radius:14px;padding:18px} .pkg.hl{border-color:var(--a)}
  .price{font-size:28px;font-weight:800} ul{margin:6px 0;padding-left:20px} footer{margin-top:40px;border-top:1px solid #e2e8f0;padding-top:12px;font-size:12px;color:#64748b}
  .btn{position:fixed;top:12px;right:12px;background:var(--a);color:#fff;border:0;padding:10px 16px;border-radius:10px;font-weight:600;cursor:pointer}
  @media print{.btn{display:none} body{padding:0}}
</style></head><body>
<button class="btn" onclick="window.print()">Print / Save as PDF</button>
<header><div style="display:flex;gap:12px;align-items:center">${s.profile.logo ? `<img src="${s.profile.logo}" alt="logo">` : ""}<div><div class="brand">${esc(s.profile.name || "ChannelHunter")}</div><div class="muted">${esc(s.profile.tagline)}</div></div></div>
<div class="muted" style="text-align:right">${s.profile.portfolioLink ? `<div>${esc(s.profile.portfolioLink)}</div>` : ""}${s.profile.calendarLink ? `<div>${esc(s.profile.calendarLink)}</div>` : ""}<div>${format(new Date(), "d MMM yyyy")}</div></div></header>
${body}
<footer>Prepared by ${esc(s.profile.name || "ChannelHunter")} · Data from the public YouTube Data API · This report is a free, no-obligation audit.</footer>
</body></html>`;
}

export function openPrintWindow(html: string) {
  const w = window.open("", "_blank", "noopener,noreferrer,width=960,height=800");
  if (!w) {
    alert("Please allow pop-ups to export the report.");
    return;
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
}

export function auditReportHtml(lead: Lead, audit: Audit, s: Settings) {
  const m = audit.metrics;
  const cats = Object.entries(audit.categories)
    .map(([k, v]) => `<div class="kpi"><span>${esc(k)}</span><b>${v}</b><div class="bar"><i style="width:${v}%"></i></div></div>`)
    .join("");
  const problems = audit.problems
    .slice(0, 5)
    .map((p, i) => `<tr><td>${i + 1}</td><td><b>${esc(p.category)}</b><br>${esc(p.issue)}${p.videoTitle ? `<div class="muted">e.g. "${esc(p.videoTitle)}"</div>` : ""}</td><td>${esc(p.fix)}</td></tr>`)
    .join("");
  const wins = audit.quickWins.map((w) => `<li>${esc(w)}</li>`).join("");
  const body = `
  <h1>YouTube Channel Audit – ${esc(lead.name)}</h1>
  <div class="muted">${lead.subs.toLocaleString()} subscribers · ${lead.videoCount.toLocaleString()} videos · ${esc(lead.niche)} · Audit date ${format(new Date(audit.createdAt), "d MMM yyyy")}</div>
  <div style="display:flex;gap:28px;align-items:center;margin:24px 0"><div class="score">${audit.overall}<span style="font-size:18px;color:#64748b">/100</span></div><div><div class="pill">Overall optimisation score</div><p style="margin:8px 0 0">${esc(audit.summary)}</p></div></div>
  <h2>Category scores</h2><div class="grid">${cats}</div>
  <h2>Key metrics</h2><div class="grid">
    <div class="kpi"><span>Avg views (recent)</span><b>${m.avgViews.toLocaleString()}</b></div>
    <div class="kpi"><span>Views-to-sub ratio</span><b>${Math.round(m.viewsToSubRatio * 100)}%</b></div>
    <div class="kpi"><span>Engagement rate</span><b>${m.engagementRate}%</b></div>
    <div class="kpi"><span>Upload gap</span><b>${m.uploadGapDays}d</b></div>
    <div class="kpi"><span>Titles with keyword</span><b>${m.titleKeywordPct}%</b></div>
    <div class="kpi"><span>Videos with chapters</span><b>${m.descChaptersPct}%</b></div>
    <div class="kpi"><span>Avg title length</span><b>${m.avgTitleLen}</b></div>
    <div class="kpi"><span>Shorts share</span><b>${m.shortsPct}%</b></div>
  </div>
  <h2>Top 5 problems</h2><table><thead><tr><th>#</th><th>Problem</th><th>Recommended fix</th></tr></thead><tbody>${problems || "<tr><td colspan=3>No major problems detected.</td></tr>"}</tbody></table>
  <h2>Top 5 quick wins</h2><ol>${wins}</ol>
  <h2>Opportunity</h2><div class="box">${esc(audit.opportunity)}</div>
  <h2>Next step</h2><div class="box">Want these fixes implemented? ${s.profile.calendarLink ? `Book a free 15-minute call: <b>${esc(s.profile.calendarLink)}</b>` : "Reply to this report and we'll map out the first 30 days together."}</div>`;
  return shell(`Audit – ${lead.name}`, body, s);
}

export function proposalHtml(lead: Lead, audit: Audit | null, pkgs: Package[], selected: Package, cases: CaseStudy[], s: Settings, notes: string) {
  const problems = audit ? audit.problems.slice(0, 4).map((p) => `<li><b>${esc(p.category)}:</b> ${esc(p.issue)} → <i>${esc(p.fix)}</i></li>`).join("") : "<li>Full audit to be delivered in week 1.</li>";
  const pkgHtml = pkgs
    .map(
      (p) => `<div class="pkg ${p.id === selected.id ? "hl" : ""}"><div style="display:flex;justify-content:space-between;align-items:baseline"><b style="font-size:18px">${esc(p.name)}</b>${p.id === selected.id ? '<span class="pill">Recommended</span>' : ""}</div><div class="price">$${p.price.toLocaleString()}<span class="muted" style="font-size:13px"> ${esc(p.period)}</span></div><ul>${p.deliverables.map((d) => `<li>${esc(d)}</li>`).join("")}</ul></div>`
    )
    .join("");
  const caseHtml = cases.length
    ? cases
        .map(
          (c) => `<div class="box"><b>${esc(c.client)}</b> <span class="muted">· ${esc(c.niche)}</span><div class="grid" style="margin-top:8px"><div class="kpi"><span>CTR</span><b>${c.beforeCtr}% → ${c.afterCtr}%</b></div><div class="kpi"><span>Views</span><b>${c.beforeViews.toLocaleString()} → ${c.afterViews.toLocaleString()}</b></div><div class="kpi"><span>Subscribers</span><b>${c.beforeSubs.toLocaleString()} → ${c.afterSubs.toLocaleString()}</b></div></div>${c.screenshot ? `<img src="${c.screenshot}" style="max-width:100%;border-radius:8px;margin-top:10px">` : ""}${c.notes ? `<p class="muted">${esc(c.notes)}</p>` : ""}</div>`
        )
        .join("")
    : "";
  const body = `
  <h1>Growth Proposal for ${esc(lead.name)}</h1>
  <div class="muted">Prepared for ${esc(lead.name)} · ${lead.subs.toLocaleString()} subscribers · ${esc(lead.niche)}</div>
  <h2>Where the channel is today</h2>
  ${audit ? `<div style="display:flex;gap:20px;align-items:center"><div class="score">${audit.overall}/100</div><p>${esc(audit.summary)}</p></div>` : "<p>We'll begin with a full audit to establish a baseline.</p>"}
  <h2>What we found & what we'll fix</h2><ul>${problems}</ul>
  ${audit ? `<div class="box"><b>Opportunity:</b> ${esc(audit.opportunity)}</div>` : ""}
  <h2>Packages</h2><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">${pkgHtml}</div>
  ${caseHtml ? `<h2>Results for similar channels</h2>${caseHtml}` : ""}
  ${notes ? `<h2>Notes</h2><div class="box">${esc(notes).replace(/\n/g, "<br>")}</div>` : ""}
  <h2>Next step</h2><div class="box">Reply "yes" to the ${esc(selected.name)} package and we start within 48 hours.${s.profile.calendarLink ? ` Or book a call: <b>${esc(s.profile.calendarLink)}</b>` : ""} Proposal valid 14 days.</div>`;
  return shell(`Proposal – ${lead.name}`, body, s);
}
