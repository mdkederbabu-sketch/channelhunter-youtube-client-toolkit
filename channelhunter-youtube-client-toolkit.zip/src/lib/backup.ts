/** Backup / restore (JSON) and CSV import/export – all client-side. */
import { z } from "zod";
import { db, TABLE_NAMES } from "./db";
import { loadSettings, replaceSettings } from "./settings";
import { parseCsv, toCsv } from "./outreach";
import { createManualLead } from "./leads";
import type { Lead } from "./types";

export function downloadFile(name: string, content: string, type = "application/json") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function exportBackup() {
  const data: Record<string, unknown> = { version: 1, exportedAt: new Date().toISOString(), settings: loadSettings() };
  for (const t of TABLE_NAMES) data[t] = await db.table(t).toArray();
  downloadFile(`channelhunter-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(data, null, 2));
}

const BackupSchema = z.object({ version: z.number(), settings: z.unknown().optional() }).passthrough();

export async function importBackup(json: string, mode: "replace" | "merge" = "replace") {
  const raw = JSON.parse(json);
  const parsed = BackupSchema.safeParse(raw);
  if (!parsed.success) throw new Error("Not a valid ChannelHunter backup file.");
  const data = parsed.data as Record<string, unknown>;
  await db.transaction("rw", TABLE_NAMES.map((t) => db.table(t)), async () => {
    for (const t of TABLE_NAMES) {
      const rows = data[t];
      if (!Array.isArray(rows)) continue;
      if (mode === "replace") await db.table(t).clear();
      await db.table(t).bulkPut(rows);
    }
  });
  if (data.settings) replaceSettings(data.settings);
}

export async function deleteAllData() {
  await db.transaction("rw", [...TABLE_NAMES.map((t) => db.table(t)), db.cache], async () => {
    for (const t of TABLE_NAMES) await db.table(t).clear();
    await db.cache.clear();
  });
  localStorage.clear();
}

export function leadsToCsv(leads: Lead[]) {
  return toCsv(
    leads.map((l) => ({
      name: l.name,
      channel_url: l.channelId.startsWith("UC") ? `https://www.youtube.com/channel/${l.channelId}` : "",
      handle: l.handle ?? "",
      niche: l.niche,
      stage: l.stage,
      score: l.score,
      label: l.scoreLabel,
      subs: l.subs,
      total_views: l.totalViews,
      avg_views: l.avgViews ?? "",
      views_to_sub: l.viewsToSubRatio ?? "",
      uploads_per_month: l.uploadsPerMonth ?? "",
      last_upload: l.lastUpload ?? "",
      email: l.contact.email,
      website: l.contact.website,
      linkedin: l.contact.linkedin,
      instagram: l.contact.instagram,
      x: l.contact.x,
      facebook: l.contact.facebook,
      whatsapp: l.contact.whatsapp,
      contact_found: l.contact.found,
      do_not_contact: l.doNotContact,
      deal_value: l.dealValue,
      deal_type: l.dealType,
      tags: l.tags.join("|"),
      notes: l.notes,
      next_follow_up: l.nextFollowUpAt ?? "",
      created_at: l.createdAt,
    }))
  );
}

/** Import leads from CSV. Recognised columns: name, channel_url/channel_id/url, subs, niche, email, website, notes, avg_views, last_upload. */
export async function importLeadsCsv(text: string): Promise<number> {
  const rows = parseCsv(text);
  let n = 0;
  for (const r of rows) {
    const name = r.name || r.channel || r.channel_name;
    if (!name) continue;
    const url = r.channel_url || r.url || r.channel_id || "";
    const idMatch = /UC[\w-]{22}/.exec(url);
    await createManualLead({
      name,
      channelId: idMatch?.[0] ?? (url.trim() || undefined),
      subs: Number(String(r.subs || r.subscribers || "0").replace(/[^0-9.]/g, "")) || 0,
      totalViews: Number(r.total_views) || 0,
      niche: r.niche || "Other",
      email: r.email,
      website: r.website,
      notes: r.notes,
      avgViews: Number(r.avg_views) || undefined,
      lastUpload: r.last_upload || undefined,
    });
    n++;
  }
  return n;
}
