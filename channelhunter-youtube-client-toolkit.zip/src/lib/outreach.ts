/**
 * Outreach template engine – pure functions.
 *  - {variable} substitution
 *  - [a|b|c] spin syntax for randomized phrasing variants
 *  - synonym rotation for extra variety (English)
 *  - spam-risk checker (green / yellow / red)
 */
import type { Language, Lead, PitchProof, Template, Tone } from "./types";
import type { Settings } from "./settings";
import { POOLS } from "./templates";

export type Vars = Record<string, string>;

export const VARIABLE_LIST = [
  "name",
  "channel",
  "video_title",
  "issue",
  "fix",
  "keyword",
  "ctr_gain",
  "niche",
  "my_name",
  "portfolio_link",
  "calendar_link",
  "case_study",
  "takeaway",
  "tip",
] as const;

/** Builds the variable map from a lead, a pitch proof and the user's settings. */
export function buildVars(lead: Lead | null, proof: PitchProof | null, settings: Settings, extra: Partial<Vars> = {}): Vars {
  const firstName = (lead?.name ?? "there").split(/[\s|–-]+/)[0];
  return {
    name: firstName,
    channel: lead?.name ?? "your channel",
    video_title: proof?.videoTitle || lead?.recentVideos?.[0]?.title || "your latest video",
    issue: proof?.issue || "the titles don't include the keyword people search for",
    fix: proof?.fix || "putting the main keyword in the first 3 words of the title",
    keyword: proof?.keyword || (lead?.niche ?? "your niche").toLowerCase(),
    ctr_gain: "20-30%",
    niche: lead?.niche ?? "your niche",
    my_name: settings.profile.name || "me",
    portfolio_link: settings.profile.portfolioLink || "",
    calendar_link: settings.profile.calendarLink || "",
    case_study: "",
    takeaway: "the main framework",
    tip: "batching the research step first",
    ...extra,
  };
}

/** Resolve [a|b|c] spin groups deterministically by variant index. */
export function resolveSpins(text: string, variant: number): string {
  let i = 0;
  return text.replace(/\[([^\[\]]+\|[^\[\]]*)\]/g, (_m, group: string) => {
    const opts = group.split("|");
    const pick = opts[(variant + i) % opts.length];
    i++;
    return pick;
  });
}

const SYNONYMS: Record<number, [RegExp, string][]> = {
  1: [
    [/\bHi\b/, "Hey"],
    [/\bsolid\b/, "strong"],
    [/\bnoticed\b/, "spotted"],
    [/\bquick\b/i, "fast"],
    [/\bWant me to\b/, "Would you like me to"],
  ],
  2: [
    [/\bHi\b/, "Hello"],
    [/\bsolid\b/, "genuinely good"],
    [/\bnoticed\b/, "saw"],
    [/\bA quick fix\b/, "An easy fix"],
    [/\bWant me to send\b/, "Should I send"],
  ],
};

export function substitute(text: string, vars: Vars): string {
  return text.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? vars[k] : m));
}

/** Render one variant of a template body. */
export function render(body: string, vars: Vars, variant = 0, language: Language = "English"): string {
  let t = resolveSpins(body, variant);
  if (language === "English" && SYNONYMS[variant]) {
    SYNONYMS[variant].forEach(([re, rep]) => {
      t = t.replace(re, rep);
    });
  }
  t = substitute(t, vars);
  // Capitalise first letter of sentences after substitution (issues start lowercase by design)
  return t.replace(/\s{2,}/g, " ").trim();
}

export const wordCount = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;

/** Tone adjustment – light-touch wording tweaks (English only; other languages rely on template pools). */
export function applyTone(text: string, tone: Tone, language: Language) {
  if (language !== "English") return text;
  if (tone === "Professional") return text.replace(/^Hey\b/, "Hello").replace(/^Hi\b/, "Hello").replace(/\bquick one\b/, "a brief note").replace(/\bno strings\b/, "no obligation");
  if (tone === "Direct") return text.replace(/^(Hello|Hey)\b/, "Hi").replace(/\bIf it's useful, I can send\b/, "I can send").replace(/\bHappy to put\b/, "I'll put").replace(/\s*–\s*no pitch,?\s*just the fixes\.?/, ".");
  return text;
}

export interface Variant {
  subject: string;
  body: string;
  words: number;
}

/** Generate 3 variants (different spins/synonyms/subjects) for a template. */
export function generateVariants(tpl: Template, vars: Vars, tone: Tone, settings: Settings, medium: string, count = 3): Variant[] {
  const subjects = tpl.subjectPool.length ? tpl.subjectPool : POOLS[tpl.language].subjects;
  const out: Variant[] = [];
  for (let v = 0; v < count; v++) {
    let body = applyTone(render(tpl.body, vars, v, tpl.language), tone, tpl.language);
    if (medium === "Email" && tpl.type === "first") {
      const sig = [vars.my_name !== "me" ? vars.my_name : "", vars.portfolio_link].filter(Boolean).join(" · ");
      if (sig) body += `\n\n– ${sig}`;
    }
    const subject = substitute(resolveSpins(subjects[(v * 2) % subjects.length], v), vars);
    out.push({ subject, body, words: wordCount(body) });
  }
  void settings;
  return out;
}

/* ---------------- Spam-risk checker ---------------- */

export interface SpamResult {
  level: "green" | "yellow" | "red";
  score: number; // 0 = clean, 100 = spam
  flags: string[];
}

const GENERIC_PHRASES = [
  "i can grow your channel",
  "guaranteed",
  "seo expert here",
  "i am an seo expert",
  "100% results",
  "best in the market",
  "dear sir",
  "dear sir/madam",
  "to whom it may concern",
  "i help creators like you",
  "limited time offer",
  "viral",
  "millions of views",
  "skyrocket",
];

export function spamCheck(body: string, maxWords: number, personalisationVars = ["video_title", "issue"]): SpamResult {
  const flags: string[] = [];
  let score = 0;
  const lower = body.toLowerCase();
  GENERIC_PHRASES.forEach((p) => {
    if (lower.includes(p)) {
      flags.push(`Generic phrase: "${p}"`);
      score += 25;
    }
  });
  const links = (body.match(/https?:\/\/|www\./gi) ?? []).length;
  if (links > 1) {
    flags.push(`${links} links – keep it to one`);
    score += 20;
  }
  // Ignore quoted video titles (e.g. 'Pricing 101') when looking for pricing mentions
  const unquoted = body.replace(/['"‘“][^'"’”]{0,120}['"’”]/g, "");
  if (/\$\s?\d|\d+\s?(usd|bdt|tk|taka|€|£|\/mo\b)|\bpricing\b|\bper month\b|\bpackages?\b|\bmy rates?\b|\bretainer\b/i.test(unquoted)) {
    flags.push("Pricing mention – never price in the first message");
    score += 30;
  }
  const words = wordCount(body);
  if (words > maxWords) {
    flags.push(`Too long: ${words} words (max ${maxWords})`);
    score += Math.min(30, (words - maxWords) / 2);
  }
  const caps = body.match(/\b[A-Z]{4,}\b/g)?.filter((w) => !["SEO", "AEO", "GEO", "CTR", "FAQ", "URL", "HTML"].includes(w)) ?? [];
  if (caps.length) {
    flags.push(`ALL CAPS words: ${caps.slice(0, 3).join(", ")}`);
    score += 15;
  }
  const unresolved = body.match(/\{\w+\}/g);
  if (unresolved) {
    flags.push(`Unfilled variables: ${Array.from(new Set(unresolved)).join(", ")}`);
    score += 30;
  }
  if (!/['"‘“]/.test(body) && !/video/i.test(body)) {
    flags.push("No specific video reference – add personalisation");
    score += 15;
  }
  if ((body.match(/!/g) ?? []).length > 2) {
    flags.push("Too many exclamation marks");
    score += 10;
  }
  void personalisationVars;
  score = Math.min(100, Math.round(score));
  return { level: score < 20 ? "green" : score < 50 ? "yellow" : "red", score, flags };
}

/** Which template type to use for a follow-up on day N. */
export function followUpType(day: number): Template["type"] | "check" {
  if (day <= 1) return "check";
  if (day <= 4) return "followup3";
  if (day <= 10) return "followup7";
  return "followup14";
}

/** Comment warm-up drafts for a specific video. */
export function commentDrafts(language: Language, vars: Vars): string[] {
  return POOLS[language].comments.map((c, i) => render(c, vars, i, language));
}

/** Parse CSV text into rows (handles quoted fields). */
export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) {
      if (c === '"' && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else if (c === '"') inQ = false;
      else cell += c;
    } else if (c === '"') inQ = true;
    else if (c === ",") {
      row.push(cell);
      cell = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else cell += c;
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  const [header, ...body] = rows.filter((r) => r.some((c) => c.trim()));
  if (!header) return [];
  const keys = header.map((h) => h.trim().toLowerCase().replace(/\s+/g, "_"));
  return body.map((r) => Object.fromEntries(keys.map((k, i) => [k, (r[i] ?? "").trim()])));
}

export function toCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const keys = Object.keys(rows[0]);
  const esc = (v: unknown) => {
    const s = v === undefined || v === null ? "" : typeof v === "object" ? JSON.stringify(v) : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [keys.join(","), ...rows.map((r) => keys.map((k) => esc(r[k])).join(","))].join("\n");
}
