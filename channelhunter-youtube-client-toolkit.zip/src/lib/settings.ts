import { z } from "zod";
import { useSyncExternalStore } from "react";

/** Settings live in localStorage (small, synchronous, includes the user's own API key). */

export const WeightsSchema = z.object({
  subFit: z.number().min(0).max(100),
  consistency: z.number().min(0).max(100),
  weakSeo: z.number().min(0).max(100),
  weakThumb: z.number().min(0).max(100),
  business: z.number().min(0).max(100),
  viewsGap: z.number().min(0).max(100),
  nicheMatch: z.number().min(0).max(100),
});
export type Weights = z.infer<typeof WeightsSchema>;

export const SettingsSchema = z.object({
  onboarded: z.boolean().default(false),
  theme: z.enum(["light", "dark", "system"]).default("system"),
  apiKey: z.string().default(""),
  profile: z
    .object({
      name: z.string().default(""),
      logo: z.string().default(""),
      accentColor: z.string().default("#6366f1"),
      portfolioLink: z.string().default(""),
      calendarLink: z.string().default(""),
      tagline: z.string().default("YouTube SEO & Growth Specialist"),
    })
    .default({ name: "", logo: "", accentColor: "#6366f1", portfolioLink: "", calendarLink: "", tagline: "YouTube SEO & Growth Specialist" }),
  services: z.array(z.string()).default(["YouTube SEO", "Thumbnail/CTR"]),
  niches: z.array(z.string()).default(["Coach", "Course Creator", "SaaS"]),
  subRange: z.object({ min: z.number(), max: z.number() }).default({ min: 1000, max: 100000 }),
  weeklyGoals: z
    .object({
      found: z.number().default(40),
      audits: z.number().default(15),
      messages: z.number().default(15),
      posts: z.number().default(2),
    })
    .default({ found: 40, audits: 15, messages: 15, posts: 2 }),
  weights: WeightsSchema.default({
    subFit: 20,
    consistency: 10,
    weakSeo: 20,
    weakThumb: 15,
    business: 15,
    viewsGap: 10,
    nicheMatch: 10,
  }),
  followUpDays: z.array(z.number()).default([1, 3, 7, 14]),
  maxWords: z.number().default(90),
  notifications: z.boolean().default(false),
  doNotContactList: z.array(z.string()).default([]),
  defaultLanguage: z.enum(["English", "Bangla", "Banglish"]).default("English"),
  defaultTone: z.enum(["Friendly", "Professional", "Direct"]).default("Friendly"),
});
export type Settings = z.infer<typeof SettingsSchema>;

const KEY = "channelhunter.settings.v1";
const listeners = new Set<() => void>();
let cached: Settings | null = null;

export function loadSettings(): Settings {
  if (cached) return cached;
  try {
    const raw = localStorage.getItem(KEY);
    cached = SettingsSchema.parse(raw ? JSON.parse(raw) : {});
  } catch {
    cached = SettingsSchema.parse({});
  }
  return cached;
}

export function saveSettings(patch: Partial<Settings> | ((s: Settings) => Settings)) {
  const current = loadSettings();
  const next = typeof patch === "function" ? patch(current) : { ...current, ...patch };
  cached = SettingsSchema.parse(next);
  localStorage.setItem(KEY, JSON.stringify(cached));
  listeners.forEach((l) => l());
  return cached;
}

export function resetSettings() {
  localStorage.removeItem(KEY);
  cached = null;
  listeners.forEach((l) => l());
}

export function replaceSettings(raw: unknown) {
  const parsed = SettingsSchema.safeParse(raw);
  if (!parsed.success) throw new Error("Invalid settings payload");
  cached = parsed.data;
  localStorage.setItem(KEY, JSON.stringify(cached));
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/** React hook: re-renders whenever settings change. */
export function useSettings(): [Settings, typeof saveSettings] {
  const s = useSyncExternalStore(subscribe, loadSettings, loadSettings);
  return [s, saveSettings];
}

/** Apply theme + accent colour to the document. */
export function applyTheme(s: Settings) {
  const root = document.documentElement;
  const prefersDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches;
  const dark = s.theme === "dark" || (s.theme === "system" && prefersDark);
  root.classList.toggle("dark", dark);
  root.style.setProperty("--brand", s.profile.accentColor || "#6366f1");
}
