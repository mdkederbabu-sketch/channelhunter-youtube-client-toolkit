/** Lead lifecycle helpers that glue db + scoring + follow-ups together. */
import { addDays } from "date-fns";
import { db, logActivity, nowIso, refreshNextFollowUp } from "./db";
import { loadSettings } from "./settings";
import { scoreLead } from "./scoring";
import { buildBuiltInTemplates, DEFAULT_PACKAGES } from "./templates";
import { emptyContact, type Audit, type ChannelData, type Lead, type Medium, type Message, type Service, type Tone, type Language } from "./types";

/** Seed built-in templates & packages on first run (idempotent). */
export async function seedDefaults() {
  const tCount = await db.templates.count();
  if (tCount === 0) await db.templates.bulkAdd(buildBuiltInTemplates());
  const pCount = await db.packages.count();
  if (pCount === 0) await db.packages.bulkAdd(DEFAULT_PACKAGES);
}

/** Create (or return existing) lead from channel data. */
export async function createLeadFromChannel(ch: ChannelData, niche?: string, sourceKeyword?: string): Promise<Lead> {
  const existing = await db.leads.where("channelId").equals(ch.channelId).first();
  if (existing) return existing;
  const s = loadSettings();
  const n = niche ?? guessNiche(ch, s.niches);
  const { score, label, breakdown } = scoreLead({ channel: ch, niche: n, weights: s.weights, subRange: s.subRange, targetNiches: s.niches });
  const now = nowIso();
  const lead: Lead = {
    ...ch,
    recentVideos: ch.recentVideos?.slice(0, 20),
    niche: n,
    stage: "Found",
    score,
    scoreLabel: label,
    scoreBreakdown: breakdown,
    tags: [],
    notes: "",
    dealValue: 0,
    dealType: "one-time",
    contact: emptyContact(),
    doNotContact: s.doNotContactList.some((d) => d && (ch.channelId === d || ch.name.toLowerCase() === d.toLowerCase())),
    createdAt: now,
    updatedAt: now,
    lastActivityAt: now,
    sourceKeyword,
  };
  const id = await db.leads.add(lead);
  await logActivity("found", `Found ${ch.name}`, id);
  return { ...lead, id };
}

/** Very light niche guess from description/keywords. */
export function guessNiche(ch: ChannelData, targets: string[]): string {
  const text = `${ch.description ?? ""} ${ch.keywords ?? ""} ${ch.name}`.toLowerCase();
  const map: [string, RegExp][] = [
    ["Coach", /coach/],
    ["Consultant", /consult/],
    ["Agency", /agency/],
    ["SaaS", /saas|software|app\b|startup/],
    ["E-commerce", /ecommerce|e-commerce|shopify|amazon fba|dropship/],
    ["Real Estate", /real estate|realtor|property|mortgage/],
    ["Finance", /financ|invest|stock|crypto|money|tax/],
    ["Health", /health|fitness|nutrition|doctor|wellness|yoga/],
    ["Education", /educat|teacher|tutor|learn|school|exam/],
    ["Course Creator", /course|masterclass|academy|bootcamp/],
    ["Local Business", /restaurant|salon|dentist|clinic|law firm|plumb|roofing|contractor/],
  ];
  for (const [n, re] of map) if (re.test(text)) return n;
  return targets[0] ?? "Other";
}

/** Re-score a lead using the latest audit (if any). */
export async function rescoreLead(leadId: number, audit?: Audit | null) {
  const lead = await db.leads.get(leadId);
  if (!lead) return;
  const s = loadSettings();
  const a = audit === undefined ? (lead.latestAuditId ? await db.audits.get(lead.latestAuditId) : null) : audit;
  const { score, label, breakdown } = scoreLead({ channel: lead, niche: lead.niche, audit: a ?? null, weights: s.weights, subRange: s.subRange, targetNiches: s.niches });
  await db.leads.update(leadId, { score, scoreLabel: label, scoreBreakdown: breakdown, updatedAt: nowIso() });
}

export async function rescoreAll() {
  const leads = await db.leads.toArray();
  for (const l of leads) await rescoreLead(l.id!);
}

export interface SendPayload {
  leadId: number;
  service: Service;
  medium: Medium;
  tone: Tone;
  language: Language;
  templateId?: number;
  templateName: string;
  subject?: string;
  body: string;
  kind: Message["kind"];
  followUpDay?: number;
}

/** "Mark as sent": logs the touchpoint and (for first messages) starts the follow-up sequence. */
export async function markAsSent(p: SendPayload) {
  const sentAt = nowIso();
  const msgId = await db.messages.add({ ...p, sentAt });
  const lead = await db.leads.get(p.leadId);
  if (!lead) return msgId;
  if (p.kind === "first") {
    const days = loadSettings().followUpDays;
    const existing = await db.tasks.where("leadId").equals(p.leadId).and((t) => !t.done).count();
    if (!existing) {
      await db.tasks.bulkAdd(
        days.map((d) => ({
          leadId: p.leadId,
          title: d <= 1 ? `Day ${d}: check reply + engage with latest video` : `Day ${d} follow-up: ${lead.name}`,
          dueAt: addDays(new Date(sentAt), d).toISOString(),
          day: d,
          done: false,
          createdAt: sentAt,
        }))
      );
    }
    if (["Found", "Audited"].includes(lead.stage)) {
      await db.leads.update(p.leadId, { stage: "Contacted", updatedAt: sentAt });
    }
    await logActivity("contacted", `Sent ${p.medium} (${p.service}, ${p.templateName})`, p.leadId);
  } else if (p.kind === "followup") {
    await logActivity("followup", `Follow-up day ${p.followUpDay ?? "?"} via ${p.medium}`, p.leadId);
  } else {
    await logActivity("note", `Posted warm-up comment`, p.leadId);
  }
  await refreshNextFollowUp(p.leadId);
  return msgId;
}

export async function completeTask(taskId: number) {
  const t = await db.tasks.get(taskId);
  if (!t) return;
  await db.tasks.update(taskId, { done: true, completedAt: nowIso() });
  await logActivity("followup", `Completed: ${t.title}`, t.leadId);
  await refreshNextFollowUp(t.leadId);
}

export async function deleteLead(leadId: number) {
  await db.transaction("rw", [db.leads, db.audits, db.proofs, db.messages, db.tasks, db.activities], async () => {
    await db.audits.where("leadId").equals(leadId).delete();
    await db.proofs.where("leadId").equals(leadId).delete();
    await db.messages.where("leadId").equals(leadId).delete();
    await db.tasks.where("leadId").equals(leadId).delete();
    await db.activities.where("leadId").equals(leadId).delete();
    await db.leads.delete(leadId);
  });
}

/** Manual-mode lead creation. */
export async function createManualLead(input: { name: string; channelId?: string; subs: number; totalViews?: number; videoCount?: number; niche: string; description?: string; avgViews?: number; lastUpload?: string; website?: string; email?: string; notes?: string }) {
  const channelId = input.channelId?.trim() || `manual-${input.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now().toString(36)}`;
  const ch: ChannelData = {
    channelId,
    name: input.name,
    subs: input.subs || 0,
    totalViews: input.totalViews ?? 0,
    videoCount: input.videoCount ?? 0,
    description: input.description,
    avgViews: input.avgViews,
    viewsToSubRatio: input.avgViews && input.subs ? +(input.avgViews / input.subs).toFixed(3) : undefined,
    lastUpload: input.lastUpload ? new Date(input.lastUpload).toISOString() : undefined,
    businessSignals: input.website ? ["website"] : [],
  };
  const lead = await createLeadFromChannel(ch, input.niche);
  if (input.website || input.email || input.notes) {
    await db.leads.update(lead.id!, {
      contact: { ...lead.contact, website: input.website ?? "", email: input.email ?? "", found: Boolean(input.email || input.website) },
      notes: input.notes ?? "",
    });
  }
  return lead;
}
