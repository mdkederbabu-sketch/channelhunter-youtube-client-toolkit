/** Shared domain types for ChannelHunter. Everything is stored client-side (Dexie / localStorage). */

export const STAGES = [
  "Found",
  "Audited",
  "Contacted",
  "Replied",
  "Call Booked",
  "Proposal Sent",
  "Won",
  "Lost",
] as const;
export type Stage = (typeof STAGES)[number];

export const SERVICES = [
  "YouTube SEO",
  "Thumbnail/CTR",
  "AEO/GEO",
  "Channel Optimization",
  "Analytics",
  "Full Growth Strategy",
] as const;
export type Service = (typeof SERVICES)[number];

export const MEDIUMS = ["Email", "LinkedIn DM", "Instagram DM", "YouTube comment", "WhatsApp"] as const;
export type Medium = (typeof MEDIUMS)[number];

export const TONES = ["Friendly", "Professional", "Direct"] as const;
export type Tone = (typeof TONES)[number];

export const LANGUAGES = ["English", "Bangla", "Banglish"] as const;
export type Language = (typeof LANGUAGES)[number];

export const NICHES = [
  "Coach",
  "Consultant",
  "Agency",
  "SaaS",
  "E-commerce",
  "Real Estate",
  "Finance",
  "Health",
  "Education",
  "Course Creator",
  "Local Business",
  "Other",
] as const;

export type ScoreLabel = "Hot" | "Warm" | "Cold";

export interface ContactInfo {
  email: string;
  website: string;
  instagram: string;
  linkedin: string;
  x: string;
  facebook: string;
  whatsapp: string;
  source: string;
  notes: string;
  found: boolean;
}

export const emptyContact = (): ContactInfo => ({
  email: "",
  website: "",
  instagram: "",
  linkedin: "",
  x: "",
  facebook: "",
  whatsapp: "",
  source: "",
  notes: "",
  found: false,
});

/** A normalized YouTube channel snapshot (from API or manual entry). */
export interface ChannelData {
  channelId: string;
  name: string;
  handle?: string;
  avatar?: string;
  description?: string;
  country?: string;
  subs: number;
  totalViews: number;
  videoCount: number;
  publishedAt?: string;
  keywords?: string;
  bannerUrl?: string;
  // Enriched from recent uploads
  avgViews?: number;
  viewsToSubRatio?: number;
  uploadsPerMonth?: number;
  lastUpload?: string;
  businessSignals?: string[];
  recentVideos?: VideoData[];
}

export interface VideoData {
  videoId: string;
  title: string;
  description: string;
  publishedAt: string;
  thumbnail?: string;
  views: number;
  likes: number;
  comments: number;
  durationSec: number;
  tags?: string[];
  hasCaptions?: boolean;
}

export interface Lead extends ChannelData {
  id?: number;
  niche: string;
  stage: Stage;
  score: number;
  scoreLabel: ScoreLabel;
  scoreBreakdown?: Record<string, number>;
  tags: string[];
  notes: string;
  dealValue: number;
  dealType: "retainer" | "one-time";
  contact: ContactInfo;
  doNotContact: boolean;
  createdAt: string;
  updatedAt: string;
  lastActivityAt: string;
  nextFollowUpAt?: string;
  wonAt?: string;
  sourceKeyword?: string;
  latestAuditId?: number;
}

export interface ThumbCheck {
  textReadable: boolean;
  faceEmotion: boolean;
  highContrast: boolean;
  uncluttered: boolean;
  consistentStyle: boolean;
}

export interface AuditProblem {
  category: string;
  severity: number; // 0-100, higher = worse
  issue: string;
  fix: string;
  videoTitle?: string;
  videoId?: string;
  keyword?: string;
}

export interface AuditMetrics {
  avgTitleLen: number;
  titleKeywordPct: number;
  titlePowerPct: number;
  titleTruncationPct: number;
  titleQuestionPct: number;
  avgDescLen: number;
  descLinksPct: number;
  descChaptersPct: number;
  descKeywordPct: number;
  descCtaPct: number;
  tagsPct: number;
  hashtagsPct: number;
  avgViews: number;
  viewsToSubRatio: number;
  engagementRate: number;
  uploadGapDays: number;
  uploadGapStdDev: number;
  shortsPct: number;
  thumbRisk: number;
  captionsPct: number;
}

export interface Audit {
  id?: number;
  leadId: number;
  createdAt: string;
  overall: number;
  categories: Record<string, number>;
  problems: AuditProblem[];
  quickWins: string[];
  summary: string;
  opportunity: string;
  metrics: AuditMetrics;
  videos: VideoData[];
  thumbChecks: Record<string, ThumbCheck>;
  channelChecks: Record<string, boolean>;
  aeoChecks: Record<string, boolean>;
  niche: string;
}

export interface PitchProof {
  id?: number;
  leadId: number;
  auditId: number;
  category: string;
  issue: string;
  fix: string;
  videoTitle: string;
  videoId?: string;
  keyword?: string;
  createdAt: string;
}

export type TemplateType = "first" | "followup3" | "followup7" | "followup14" | "comment";

export interface Template {
  id?: number;
  name: string;
  service: Service | "Any";
  language: Language;
  type: TemplateType;
  tone?: Tone | "Any";
  body: string;
  subjectPool: string[];
  builtIn: boolean;
}

export interface Message {
  id?: number;
  leadId: number;
  service: Service;
  medium: Medium;
  tone: Tone;
  language: Language;
  templateId?: number;
  templateName: string;
  subject?: string;
  body: string;
  sentAt: string;
  kind: "first" | "followup" | "comment";
  followUpDay?: number;
}

export interface Task {
  id?: number;
  leadId: number;
  title: string;
  dueAt: string;
  day: number;
  done: boolean;
  createdAt: string;
  completedAt?: string;
}

export type ActivityType =
  | "found"
  | "audited"
  | "contacted"
  | "followup"
  | "replied"
  | "call"
  | "proposal"
  | "won"
  | "lost"
  | "post"
  | "note"
  | "stage";

export interface Activity {
  id?: number;
  leadId?: number;
  type: ActivityType;
  text: string;
  at: string;
}

export interface CaseStudy {
  id?: number;
  client: string;
  niche: string;
  beforeCtr: number;
  afterCtr: number;
  beforeViews: number;
  afterViews: number;
  beforeSubs: number;
  afterSubs: number;
  screenshot?: string;
  notes: string;
  createdAt: string;
}

export interface Package {
  id?: number;
  name: string;
  price: number;
  period: "one-time" | "per month";
  deliverables: string[];
  highlight: boolean;
}

export interface SavedList {
  id?: number;
  name: string;
  channelIds: string[];
  createdAt: string;
}

export interface CacheEntry {
  key: string;
  value: unknown;
  expiresAt: number;
}

export interface QuotaLog {
  date: string; // YYYY-MM-DD (Pacific time, matching Google's reset)
  units: number;
}

export interface IgnoredChannel {
  channelId: string;
  at: string;
}

export const stageIndex = (s: Stage) => STAGES.indexOf(s);
