/**
 * YouTube Data API v3 client – quota-aware and cached.
 *
 * Quota costs (per Google docs):
 *  - search.list        = 100 units  (used sparingly, behind a confirm dialog)
 *  - channels.list      = 1 unit     (batched up to 50 IDs)
 *  - playlistItems.list = 1 unit     (uploads playlist UC… -> UU…)
 *  - videos.list        = 1 unit     (batched up to 50 IDs)
 * Every response is cached in IndexedDB for 24h so repeated queries cost 0.
 */
import { addQuota, cacheGet, cacheSet } from "./db";
import { loadSettings } from "./settings";
import type { ChannelData, VideoData } from "./types";

const BASE = "https://www.googleapis.com/youtube/v3";

export const COST = { search: 100, channels: 1, playlistItems: 1, videos: 1 } as const;

export class YouTubeError extends Error {
  constructor(
    message: string,
    public status?: number,
    public reason?: string
  ) {
    super(message);
  }
}

export function hasApiKey() {
  return Boolean(loadSettings().apiKey?.trim());
}

/** Core fetch wrapper: cache -> network -> quota log. */
async function yt<T>(endpoint: keyof typeof COST, params: Record<string, string | number | undefined>): Promise<T> {
  const apiKey = loadSettings().apiKey?.trim();
  if (!apiKey) throw new YouTubeError("No YouTube API key set. Add one in Settings or use Manual Mode.");
  const clean: Record<string, string> = {};
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== "") clean[k] = String(v);
  });
  const qs = new URLSearchParams(clean).toString();
  const cacheKey = `yt:${endpoint}:${qs}`;
  const cached = await cacheGet<T>(cacheKey);
  if (cached) return cached;

  const res = await fetch(`${BASE}/${endpoint}?${qs}&key=${encodeURIComponent(apiKey)}`);
  // Google charges quota even on some errors, so log cost before parsing.
  await addQuota(COST[endpoint]);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const reason = json?.error?.errors?.[0]?.reason ?? json?.error?.status;
    const msg = json?.error?.message ?? `YouTube API error (${res.status})`;
    throw new YouTubeError(
      reason === "quotaExceeded"
        ? "Daily YouTube API quota exceeded (10,000 units). Resets at midnight Pacific time."
        : msg,
      res.status,
      reason
    );
  }
  await cacheSet(cacheKey, json);
  return json as T;
}

/* ---------------- Parsing helpers ---------------- */

/** ISO 8601 duration (PT1H2M3S) -> seconds */
export function parseDuration(iso: string): number {
  const m = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(iso || "");
  if (!m) return 0;
  return (+(m[1] || 0)) * 3600 + (+(m[2] || 0)) * 60 + +(m[3] || 0);
}

/** Extracts a channel ID / handle / username / video id from any YouTube URL or raw string. */
export function parseChannelInput(input: string): { kind: "id" | "handle" | "username" | "video"; value: string } | null {
  const s = input.trim();
  if (!s) return null;
  if (/^UC[\w-]{22}$/.test(s)) return { kind: "id", value: s };
  if (s.startsWith("@")) return { kind: "handle", value: s };
  try {
    const url = new URL(s.includes("://") ? s : `https://${s}`);
    const parts = url.pathname.split("/").filter(Boolean);
    if (url.hostname.includes("youtu.be")) return { kind: "video", value: parts[0] };
    if (parts[0] === "watch" && url.searchParams.get("v")) return { kind: "video", value: url.searchParams.get("v")! };
    if (parts[0] === "shorts" && parts[1]) return { kind: "video", value: parts[1] };
    if (parts[0] === "channel" && parts[1]) return { kind: "id", value: parts[1] };
    if (parts[0]?.startsWith("@")) return { kind: "handle", value: parts[0] };
    if ((parts[0] === "c" || parts[0] === "user") && parts[1]) return { kind: "username", value: parts[1] };
    if (parts[0] && !parts[1]) return { kind: "handle", value: `@${parts[0]}` };
  } catch {
    /* not a URL */
  }
  return { kind: "handle", value: s.startsWith("@") ? s : `@${s}` };
}

/** Finds website / course / product / sponsor style business signals in channel text. */
export function detectBusinessSignals(text: string): string[] {
  const t = (text || "").toLowerCase();
  const signals: string[] = [];
  if (/https?:\/\/|www\.|\.com|\.io|\.co\b/.test(t)) signals.push("website");
  if (/course|masterclass|bootcamp|academy|training|workshop|webinar/.test(t)) signals.push("course");
  if (/product|shop|store|buy|order|merch/.test(t)) signals.push("product");
  if (/sponsor|partner|brand deal|collab/.test(t)) signals.push("sponsor");
  if (/coach|consult|agency|clients?|book a call|free call|strategy call|calendly/.test(t)) signals.push("services");
  if (/business inquir|contact|email|@/.test(t)) signals.push("contact");
  if (/newsletter|subscribe to my|substack|mailing list/.test(t)) signals.push("newsletter");
  return signals;
}

/* ---------------- API types (minimal) ---------------- */
interface ChannelItem {
  id: string;
  snippet: { title: string; description: string; customUrl?: string; publishedAt: string; country?: string; thumbnails?: { default?: { url: string }; medium?: { url: string } } };
  statistics: { subscriberCount?: string; viewCount?: string; videoCount?: string; hiddenSubscriberCount?: boolean };
  contentDetails?: { relatedPlaylists?: { uploads?: string } };
  brandingSettings?: { channel?: { keywords?: string }; image?: { bannerExternalUrl?: string } };
}
interface VideoItem {
  id: string;
  snippet: { title: string; description: string; publishedAt: string; tags?: string[]; thumbnails?: { medium?: { url: string }; high?: { url: string } } };
  statistics?: { viewCount?: string; likeCount?: string; commentCount?: string };
  contentDetails?: { duration?: string; caption?: string };
}

function toChannel(c: ChannelItem): ChannelData {
  return {
    channelId: c.id,
    name: c.snippet.title,
    handle: c.snippet.customUrl,
    avatar: c.snippet.thumbnails?.medium?.url ?? c.snippet.thumbnails?.default?.url,
    description: c.snippet.description,
    country: c.snippet.country,
    publishedAt: c.snippet.publishedAt,
    subs: Number(c.statistics?.subscriberCount ?? 0),
    totalViews: Number(c.statistics?.viewCount ?? 0),
    videoCount: Number(c.statistics?.videoCount ?? 0),
    keywords: c.brandingSettings?.channel?.keywords,
    bannerUrl: c.brandingSettings?.image?.bannerExternalUrl,
    businessSignals: detectBusinessSignals(c.snippet.description),
  };
}

function toVideo(v: VideoItem): VideoData {
  return {
    videoId: v.id,
    title: v.snippet.title,
    description: v.snippet.description,
    publishedAt: v.snippet.publishedAt,
    thumbnail: v.snippet.thumbnails?.high?.url ?? v.snippet.thumbnails?.medium?.url,
    views: Number(v.statistics?.viewCount ?? 0),
    likes: Number(v.statistics?.likeCount ?? 0),
    comments: Number(v.statistics?.commentCount ?? 0),
    durationSec: parseDuration(v.contentDetails?.duration ?? ""),
    tags: v.snippet.tags,
    hasCaptions: v.contentDetails?.caption === "true",
  };
}

/* ---------------- Public API ---------------- */

export interface SearchOptions {
  q: string;
  pageToken?: string;
  regionCode?: string;
  relevanceLanguage?: string;
  maxResults?: number;
  order?: "relevance" | "viewCount" | "date";
}

/** search.list (100 units). Returns channel IDs + nextPageToken. */
export async function searchChannels(opts: SearchOptions): Promise<{ channelIds: string[]; nextPageToken?: string; total: number }> {
  const json = await yt<{ items: { id: { channelId?: string } }[]; nextPageToken?: string; pageInfo?: { totalResults: number } }>("search", {
    part: "id",
    type: "channel",
    q: opts.q,
    maxResults: opts.maxResults ?? 50,
    pageToken: opts.pageToken,
    regionCode: opts.regionCode,
    relevanceLanguage: opts.relevanceLanguage,
    order: opts.order ?? "relevance",
  });
  return {
    channelIds: json.items.map((i) => i.id.channelId!).filter(Boolean),
    nextPageToken: json.nextPageToken,
    total: json.pageInfo?.totalResults ?? 0,
  };
}

/** channels.list batched by 50 (1 unit each batch). */
export async function getChannels(ids: string[]): Promise<ChannelData[]> {
  const out: ChannelData[] = [];
  const uniq = Array.from(new Set(ids.filter(Boolean)));
  for (let i = 0; i < uniq.length; i += 50) {
    const batch = uniq.slice(i, i + 50);
    const json = await yt<{ items?: ChannelItem[] }>("channels", {
      part: "snippet,statistics,contentDetails,brandingSettings",
      id: batch.join(","),
      maxResults: 50,
    });
    (json.items ?? []).forEach((c) => out.push(toChannel(c)));
  }
  return out;
}

/** Resolve a URL / @handle / channel ID / video URL to a channel. */
export async function resolveChannel(input: string): Promise<ChannelData | null> {
  const parsed = parseChannelInput(input);
  if (!parsed) return null;
  if (parsed.kind === "id") return (await getChannels([parsed.value]))[0] ?? null;
  if (parsed.kind === "video") {
    const json = await yt<{ items?: { snippet: { channelId: string } }[] }>("videos", { part: "snippet", id: parsed.value });
    const cid = json.items?.[0]?.snippet.channelId;
    return cid ? ((await getChannels([cid]))[0] ?? null) : null;
  }
  const params = parsed.kind === "handle" ? { forHandle: parsed.value } : { forUsername: parsed.value };
  const json = await yt<{ items?: ChannelItem[] }>("channels", {
    part: "snippet,statistics,contentDetails,brandingSettings",
    ...params,
  });
  return json.items?.[0] ? toChannel(json.items[0]) : null;
}

/** videos.list batched (1 unit per 50). */
export async function getVideos(ids: string[]): Promise<VideoData[]> {
  const out: VideoData[] = [];
  for (let i = 0; i < ids.length; i += 50) {
    const json = await yt<{ items?: VideoItem[] }>("videos", {
      part: "snippet,statistics,contentDetails",
      id: ids.slice(i, i + 50).join(","),
      maxResults: 50,
    });
    (json.items ?? []).forEach((v) => out.push(toVideo(v)));
  }
  return out;
}

/** Recent uploads via the UU playlist (1 unit) + videos.list (1 unit) – instead of search.list (100). */
export async function getRecentVideos(channelId: string, max = 20): Promise<VideoData[]> {
  const uploads = "UU" + channelId.slice(2);
  const json = await yt<{ items?: { contentDetails: { videoId: string } }[] }>("playlistItems", {
    part: "contentDetails",
    playlistId: uploads,
    maxResults: Math.min(max, 50),
  });
  const ids = (json.items ?? []).map((i) => i.contentDetails.videoId);
  if (!ids.length) return [];
  const vids = await getVideos(ids);
  return vids.sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt));
}

/** Pure: compute derived stats from a channel's recent videos. */
export function enrichWithVideos(ch: ChannelData, videos: VideoData[]): ChannelData {
  if (!videos.length) return { ...ch, recentVideos: [] };
  const last10 = videos.slice(0, 10);
  const avgViews = Math.round(last10.reduce((s, v) => s + v.views, 0) / last10.length);
  const sorted = [...videos].sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt));
  const first = +new Date(sorted[sorted.length - 1].publishedAt);
  const last = +new Date(sorted[0].publishedAt);
  const spanMonths = Math.max((last - first) / (1000 * 60 * 60 * 24 * 30), 0.5);
  const uploadsPerMonth = +(videos.length / spanMonths).toFixed(1);
  const descText = videos.map((v) => v.description).join("\n");
  return {
    ...ch,
    avgViews,
    viewsToSubRatio: ch.subs ? +(avgViews / ch.subs).toFixed(3) : 0,
    uploadsPerMonth,
    lastUpload: sorted[0].publishedAt,
    businessSignals: Array.from(new Set([...(ch.businessSignals ?? []), ...detectBusinessSignals(descText)])),
    recentVideos: videos,
  };
}

/** Estimated cost of enriching N channels (used in confirm dialogs). */
export function estimateEnrichCost(n: number) {
  return n * (COST.playlistItems + COST.videos);
}
