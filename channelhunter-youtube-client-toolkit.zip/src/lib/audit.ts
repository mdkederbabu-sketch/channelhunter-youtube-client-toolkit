/**
 * Audit Engine – pure functions. Given a channel, its recent videos and the manual checklists,
 * compute per-category scores (0-100), detected problems (pitch proofs), quick wins and a
 * rule-based plain-English summary. No AI APIs – everything is driven by numbers and templates.
 */
import type { AuditMetrics, AuditProblem, ChannelData, ThumbCheck, VideoData } from "./types";

export const POWER_WORDS = [
  "secret", "proven", "ultimate", "complete", "guide", "mistakes", "best", "worst", "free", "easy",
  "fast", "step", "how to", "why", "truth", "stop", "never", "always", "new", "exposed", "beginner",
  "advanced", "simple", "framework", "blueprint", "checklist", "strategy", "hack", "tips", "vs",
];
export const CTA_WORDS = ["subscribe", "download", "free", "join", "book", "call", "link", "sign up", "signup", "grab", "get your", "apply", "dm", "comment"];

export const THUMB_FIELDS: { key: keyof ThumbCheck; label: string }[] = [
  { key: "textReadable", label: "Text readable" },
  { key: "faceEmotion", label: "Face / emotion" },
  { key: "highContrast", label: "High contrast" },
  { key: "uncluttered", label: "Uncluttered" },
  { key: "consistentStyle", label: "Consistent style" },
];

export const CHANNEL_CHECKS: { key: string; label: string; fix: string }[] = [
  { key: "banner", label: "Banner states who it's for + upload schedule", fix: "redesign the banner with a clear value proposition and CTA" },
  { key: "about", label: "About section keyword-rich (150+ words)", fix: "rewrite the About section with target keywords and a clear offer" },
  { key: "keywords", label: "Channel keywords set", fix: "add 10-15 niche channel keywords in YouTube Studio" },
  { key: "featured", label: "Featured video / channel trailer", fix: "set a 60-90s trailer for new visitors" },
  { key: "playlists", label: "Topic playlists organised", fix: "group videos into 4-6 keyword-named playlists" },
  { key: "links", label: "Website / social links on banner", fix: "add website and lead-magnet links to the banner" },
  { key: "email", label: "Business email visible", fix: "add a business inquiry email in About" },
];

export const AEO_CHECKS: { key: string; label: string; fix: string }[] = [
  { key: "faq", label: "FAQ-style descriptions (Q&A blocks)", fix: "add a 3-question FAQ block to descriptions so AI engines can quote answers" },
  { key: "entity", label: "Consistent brand/entity naming across titles & About", fix: "use one consistent brand/person name everywhere (titles, About, pinned comment)" },
  { key: "captions", label: "Captions / transcripts available (manual check)", fix: "upload edited captions so answer engines can index the spoken content" },
  { key: "clusters", label: "Topic clusters via playlists", fix: "build playlist clusters around 3-5 core questions your audience asks" },
];

const avg = (a: number[]) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
const pct = (n: number, d: number) => (d ? Math.round((n / d) * 100) : 0);
const clamp = (n: number, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, Math.round(n)));
const stdDev = (a: number[]) => {
  if (a.length < 2) return 0;
  const m = avg(a);
  return Math.sqrt(avg(a.map((x) => (x - m) ** 2)));
};

/** Tokenise a niche string into keywords ("Course Creator" -> ["course","creator"]). */
export function nicheKeywords(niche: string, extra = ""): string[] {
  return `${niche} ${extra}`
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 2 && !["and", "the", "for", "with", "your"].includes(w));
}

export function titleHasKeyword(title: string, kws: string[]) {
  const t = title.toLowerCase();
  return kws.some((k) => t.includes(k));
}
export const hasChapters = (d: string) => /(^|\n)\s*0?0:00/.test(d) && (d.match(/\d{1,2}:\d{2}/g) ?? []).length >= 3;
export const hasLinks = (d: string) => /https?:\/\/|www\./i.test(d);
export const hasCta = (d: string) => CTA_WORDS.some((w) => d.toLowerCase().includes(w));
export const hasPower = (t: string) => /\d/.test(t) || POWER_WORDS.some((w) => t.toLowerCase().includes(w));
export const isQuestion = (t: string) => /\?|^(how|why|what|when|should|can|is|do|does)\b/i.test(t.trim());
export const isShort = (v: VideoData) => v.durationSec > 0 && v.durationSec <= 60;

export function thumbRiskFromChecks(checks: Record<string, ThumbCheck>, videos: VideoData[]): number {
  const ids = videos.slice(0, 12).map((v) => v.videoId);
  const checked = ids.filter((id) => checks[id]);
  if (!checked.length) return 50; // unknown -> neutral
  const total = checked.length * THUMB_FIELDS.length;
  const passed = checked.reduce((s, id) => s + THUMB_FIELDS.filter((f) => checks[id][f.key]).length, 0);
  return clamp(100 - (passed / total) * 100); // risk = % of failed checks
}

export function computeMetrics(ch: ChannelData, videos: VideoData[], niche: string, thumbChecks: Record<string, ThumbCheck>): AuditMetrics {
  const kws = nicheKeywords(niche, ch.keywords ?? "");
  const n = videos.length || 1;
  const titles = videos.map((v) => v.title);
  const descs = videos.map((v) => v.description ?? "");
  const longForm = videos.filter((v) => !isShort(v));
  const vv = longForm.length ? longForm : videos;
  const avgViews = avg(vv.map((v) => v.views));
  const eng = vv.filter((v) => v.views > 0);
  const sorted = [...videos].sort((a, b) => +new Date(a.publishedAt) - +new Date(b.publishedAt));
  const gaps: number[] = [];
  for (let i = 1; i < sorted.length; i++) gaps.push((+new Date(sorted[i].publishedAt) - +new Date(sorted[i - 1].publishedAt)) / 86400000);
  return {
    avgTitleLen: Math.round(avg(titles.map((t) => t.length))),
    titleKeywordPct: pct(titles.filter((t) => titleHasKeyword(t, kws)).length, n),
    titlePowerPct: pct(titles.filter(hasPower).length, n),
    titleTruncationPct: pct(titles.filter((t) => t.length > 70).length, n),
    titleQuestionPct: pct(titles.filter(isQuestion).length, n),
    avgDescLen: Math.round(avg(descs.map((d) => d.length))),
    descLinksPct: pct(descs.filter(hasLinks).length, n),
    descChaptersPct: pct(descs.filter(hasChapters).length, n),
    descKeywordPct: pct(descs.filter((d) => titleHasKeyword(d, kws)).length, n),
    descCtaPct: pct(descs.filter(hasCta).length, n),
    tagsPct: pct(videos.filter((v) => (v.tags?.length ?? 0) >= 3).length, n),
    hashtagsPct: pct(descs.filter((d) => /#\w+/.test(d)).length, n),
    avgViews: Math.round(avgViews),
    viewsToSubRatio: ch.subs ? +(avgViews / ch.subs).toFixed(3) : 0,
    engagementRate: +(avg(eng.map((v) => ((v.likes + v.comments) / v.views) * 100)) || 0).toFixed(2),
    uploadGapDays: +avg(gaps).toFixed(1),
    uploadGapStdDev: +stdDev(gaps).toFixed(1),
    shortsPct: pct(videos.filter(isShort).length, n),
    thumbRisk: thumbRiskFromChecks(thumbChecks, videos),
    captionsPct: pct(videos.filter((v) => v.hasCaptions).length, n),
  };
}

/* ---------------- Category scores ---------------- */

export function scoreTitles(m: AuditMetrics) {
  const lenScore = m.avgTitleLen >= 40 && m.avgTitleLen <= 70 ? 100 : m.avgTitleLen < 40 ? clamp((m.avgTitleLen / 40) * 100) : clamp(100 - (m.avgTitleLen - 70) * 3);
  return clamp(lenScore * 0.25 + m.titleKeywordPct * 0.35 + m.titlePowerPct * 0.2 + (100 - m.titleTruncationPct) * 0.1 + Math.min(m.titleQuestionPct * 2, 100) * 0.1);
}
export function scoreDescriptions(m: AuditMetrics) {
  const lenScore = clamp((m.avgDescLen / 600) * 100);
  return clamp(lenScore * 0.25 + m.descLinksPct * 0.15 + m.descChaptersPct * 0.25 + m.descKeywordPct * 0.2 + m.descCtaPct * 0.15);
}
export function scoreTags(m: AuditMetrics) {
  return clamp(m.tagsPct * 0.6 + m.hashtagsPct * 0.4);
}
export function scorePerformance(m: AuditMetrics) {
  // views/sub: 0.2 = healthy for small channels; engagement 4%+ is great; consistent gaps are good.
  const ratioScore = clamp((m.viewsToSubRatio / 0.2) * 100);
  const engScore = clamp((m.engagementRate / 4) * 100);
  const consistency = m.uploadGapDays ? clamp(100 - (m.uploadGapStdDev / Math.max(m.uploadGapDays, 1)) * 60) : 50;
  const cadence = m.uploadGapDays ? clamp(100 - Math.max(0, m.uploadGapDays - 7) * 4) : 50;
  return clamp(ratioScore * 0.35 + engScore * 0.25 + consistency * 0.2 + cadence * 0.2);
}
export function scoreThumbnails(m: AuditMetrics) {
  return clamp(100 - m.thumbRisk);
}
export function scoreChannel(checks: Record<string, boolean>) {
  const done = CHANNEL_CHECKS.filter((c) => checks[c.key]).length;
  return pct(done, CHANNEL_CHECKS.length);
}
export function scoreAeo(m: AuditMetrics, checks: Record<string, boolean>) {
  const manual = pct(AEO_CHECKS.filter((c) => checks[c.key]).length, AEO_CHECKS.length);
  return clamp(Math.min(m.titleQuestionPct * 2.5, 100) * 0.3 + m.descChaptersPct * 0.3 + manual * 0.4);
}

/* ---------------- Problems & quick wins ---------------- */

export function detectProblems(ch: ChannelData, videos: VideoData[], m: AuditMetrics, niche: string, channelChecks: Record<string, boolean>, aeoChecks: Record<string, boolean>, thumbChecks: Record<string, ThumbCheck>): AuditProblem[] {
  const kws = nicheKeywords(niche, ch.keywords ?? "");
  const kw = kws[0] ?? niche.toLowerCase();
  const P: AuditProblem[] = [];
  const top = videos[0];
  const noKw = videos.find((v) => !titleHasKeyword(v.title, kws)) ?? top;
  const longT = videos.find((v) => v.title.length > 70);
  const shortT = videos.find((v) => v.title.length < 30);
  const noChap = videos.find((v) => !isShort(v) && v.durationSec > 480 && !hasChapters(v.description)) ?? videos.find((v) => !hasChapters(v.description));
  const shortDesc = videos.find((v) => (v.description ?? "").length < 200);
  const noCta = videos.find((v) => !hasCta(v.description ?? ""));
  const noTags = videos.find((v) => (v.tags?.length ?? 0) < 3);

  if (m.titleKeywordPct < 60 && noKw)
    P.push({ category: "Titles", severity: 100 - m.titleKeywordPct, issue: `${100 - m.titleKeywordPct}% of recent titles don't include a searchable keyword like "${kw}"`, fix: `front-load the title with "${kw}" so it ranks for what people actually type`, videoTitle: noKw.title, videoId: noKw.videoId, keyword: kw });
  if (m.titleTruncationPct > 20 && longT)
    P.push({ category: "Titles", severity: m.titleTruncationPct + 20, issue: `titles over 70 characters get cut off in search and suggested (e.g. "${longT.title.slice(0, 50)}…")`, fix: "trim titles to 45-65 characters with the keyword in the first 3 words", videoTitle: longT.title, videoId: longT.videoId, keyword: kw });
  if (m.avgTitleLen < 35 && shortT)
    P.push({ category: "Titles", severity: 60, issue: `titles are very short (avg ${m.avgTitleLen} chars) and miss context and keywords`, fix: "expand titles to 40-60 characters with a specific outcome and the keyword", videoTitle: shortT.title, videoId: shortT.videoId, keyword: kw });
  if (m.titlePowerPct < 50 && top)
    P.push({ category: "Titles", severity: 70 - m.titlePowerPct, issue: "most titles have no number or curiosity trigger, so they blend in on the browse page", fix: "add a number or a specific result (e.g. '3 mistakes', 'in 30 days') to the title", videoTitle: top.title, videoId: top.videoId, keyword: kw });
  if (m.descChaptersPct < 40 && noChap)
    P.push({ category: "Descriptions", severity: 100 - m.descChaptersPct, issue: `${100 - m.descChaptersPct}% of videos have no chapters/timestamps, which hurts Key Moments in Google and watch time`, fix: "add 5-8 keyword-named chapters (00:00 Intro, …) to each description", videoTitle: noChap.title, videoId: noChap.videoId, keyword: kw });
  if (m.avgDescLen < 300 && shortDesc)
    P.push({ category: "Descriptions", severity: 80, issue: `descriptions average only ${m.avgDescLen} characters, leaving search context on the table`, fix: "write a 2-3 sentence keyword-rich summary in the first 150 characters, then links and chapters", videoTitle: shortDesc.title, videoId: shortDesc.videoId, keyword: kw });
  if (m.descCtaPct < 50 && noCta)
    P.push({ category: "Descriptions", severity: 60, issue: "there is no clear call-to-action in most descriptions, so viewers don't know the next step", fix: "add one CTA line (free resource / book a call) above the fold in every description", videoTitle: noCta.title, videoId: noCta.videoId, keyword: kw });
  if (m.descLinksPct < 50)
    P.push({ category: "Descriptions", severity: 50, issue: "most descriptions don't link to your website or offer", fix: "add your main link + one lead magnet link in the first 3 lines", videoTitle: top?.title ?? "", videoId: top?.videoId, keyword: kw });
  if (m.tagsPct < 50 && noTags)
    P.push({ category: "Tags", severity: 45, issue: "tags are missing or thin on most videos, so misspellings and variants aren't covered", fix: "add 8-12 tags: exact keyword, variants, and the channel name", videoTitle: noTags.title, videoId: noTags.videoId, keyword: kw });
  if (m.viewsToSubRatio < 0.1 && ch.subs > 0)
    P.push({ category: "Performance", severity: 85, issue: `recent videos average ${m.avgViews.toLocaleString()} views for ${ch.subs.toLocaleString()} subscribers (${Math.round(m.viewsToSubRatio * 100)}% reach)`, fix: "fix packaging (title + thumbnail) on the next 3 uploads and refresh thumbnails on the top 5 evergreen videos", videoTitle: top?.title ?? "", videoId: top?.videoId, keyword: kw });
  if (m.engagementRate < 2 && videos.length)
    P.push({ category: "Performance", severity: 55, issue: `engagement is ${m.engagementRate}% (likes+comments / views), below the 3-4% healthy range`, fix: "ask one specific question in the first 30 seconds and pin a comment prompt", videoTitle: top?.title ?? "", videoId: top?.videoId, keyword: kw });
  if (m.uploadGapStdDev > m.uploadGapDays * 0.8 && videos.length > 4)
    P.push({ category: "Performance", severity: 50, issue: `upload schedule is irregular (avg gap ${m.uploadGapDays} days, ±${m.uploadGapStdDev})`, fix: "commit to one fixed weekly slot; batch-record 4 videos to stay consistent", videoTitle: top?.title ?? "", videoId: top?.videoId, keyword: kw });
  if (m.thumbRisk >= 50 && videos.length) {
    const worst = videos.slice(0, 12).find((v) => thumbChecks[v.videoId] && THUMB_FIELDS.filter((f) => thumbChecks[v.videoId][f.key]).length <= 2) ?? top;
    P.push({ category: "Thumbnails", severity: m.thumbRisk, issue: "thumbnails have small text / low contrast and no clear focal point, which caps click-through rate", fix: "use 3-4 word text, one expressive face, and a high-contrast background in a consistent style", videoTitle: worst?.title ?? "", videoId: worst?.videoId, keyword: kw });
  }
  if (m.shortsPct > 70 && videos.length)
    P.push({ category: "Performance", severity: 45, issue: `${m.shortsPct}% of recent uploads are Shorts, which rarely convert to clients or search traffic`, fix: "add one searchable long-form video per week aimed at a buyer question", videoTitle: top?.title ?? "", videoId: top?.videoId, keyword: kw });
  CHANNEL_CHECKS.forEach((c) => {
    if (channelChecks[c.key] === false) P.push({ category: "Channel", severity: 40, issue: `channel page: missing – ${c.label.toLowerCase()}`, fix: c.fix, videoTitle: top?.title ?? "", keyword: kw });
  });
  AEO_CHECKS.forEach((c) => {
    if (aeoChecks[c.key] === false) P.push({ category: "AEO/GEO", severity: 42, issue: `AEO/GEO: ${c.label.toLowerCase()} is missing, so AI answer engines can't cite the channel`, fix: c.fix, videoTitle: top?.title ?? "", keyword: kw });
  });
  if (m.titleQuestionPct < 20 && top)
    P.push({ category: "AEO/GEO", severity: 48, issue: "almost no question-style titles, which are what ChatGPT/Perplexity/Google AI Overviews pull from", fix: "turn 1 in 3 titles into the exact question a buyer would ask", videoTitle: top.title, videoId: top.videoId, keyword: kw });
  return P.sort((a, b) => b.severity - a.severity);
}

export function quickWins(problems: AuditProblem[], m: AuditMetrics): string[] {
  const wins: string[] = [];
  const cats = new Set(problems.map((p) => p.category));
  if (cats.has("Titles")) wins.push("Rewrite the 5 most-viewed titles with the keyword first (15 min).");
  if (m.descChaptersPct < 40) wins.push("Add chapters to the top 10 videos – unlocks Key Moments in Google.");
  if (cats.has("Thumbnails")) wins.push("Refresh thumbnails on 3 evergreen videos and compare CTR after 14 days.");
  if (m.descCtaPct < 50) wins.push("Paste one CTA line + link into every description via Studio bulk edit.");
  if (m.tagsPct < 50) wins.push("Set default upload tags and description template in YouTube Studio.");
  if (cats.has("Channel")) wins.push("Fix the About section + channel keywords today (20 min, zero cost).");
  if (cats.has("AEO/GEO")) wins.push("Add a 3-question FAQ block to the pinned comment and description.");
  if (m.engagementRate < 2) wins.push("Pin a comment with a specific question on the latest video.");
  if (wins.length < 5) wins.push("Create 2 keyword-named playlists to cluster the main topics.");
  if (wins.length < 5) wins.push("Add end screens pointing to the best-converting video.");
  return wins.slice(0, 5);
}

/** Rule-based plain-English narrative, driven by the numbers. */
export function buildSummary(ch: ChannelData, m: AuditMetrics, overall: number, cats: Record<string, number>, problems: AuditProblem[]): { summary: string; opportunity: string } {
  const worst = Object.entries(cats).sort((a, b) => a[1] - b[1])[0];
  const best = Object.entries(cats).sort((a, b) => b[1] - a[1])[0];
  const grade = overall >= 75 ? "well-optimised" : overall >= 50 ? "partly optimised" : "under-optimised";
  const reach = ch.subs ? `${Math.round(m.viewsToSubRatio * 100)}% of subscribers watch a typical new upload` : "subscriber reach is unknown";
  const parts = [
    `${ch.name} is ${/^[aeiou]/.test(grade) ? "an" : "a"} ${grade} channel (${overall}/100). ${best ? `Strongest area: ${best[0]} (${best[1]}/100).` : ""} ${worst ? `Weakest area: ${worst[0]} (${worst[1]}/100).` : ""}`,
    `Recent videos average ${m.avgViews.toLocaleString()} views – ${reach} – with ${m.engagementRate}% engagement and uploads every ~${m.uploadGapDays || "?"} days.`,
    problems[0] ? `The single biggest fix: ${problems[0].issue}.` : "No major problems were detected.",
  ];
  const potential = Math.round(m.avgViews * (overall < 50 ? 0.6 : overall < 75 ? 0.35 : 0.15));
  const opportunity = `Fixing titles, thumbnails and descriptions typically lifts CTR 20-30% and search impressions 30-50% within 60-90 days. For this channel that is roughly +${potential.toLocaleString()} views per video without publishing more content.`;
  return { summary: parts.join(" "), opportunity };
}

export interface AuditInput {
  channel: ChannelData;
  videos: VideoData[];
  niche: string;
  thumbChecks: Record<string, ThumbCheck>;
  channelChecks: Record<string, boolean>;
  aeoChecks: Record<string, boolean>;
}

export interface AuditResult {
  overall: number;
  categories: Record<string, number>;
  problems: AuditProblem[];
  quickWins: string[];
  summary: string;
  opportunity: string;
  metrics: AuditMetrics;
}

/** Main entry: run the full 5-minute audit. */
export function runAudit(input: AuditInput): AuditResult {
  const { channel, videos, niche, thumbChecks, channelChecks, aeoChecks } = input;
  const m = computeMetrics(channel, videos, niche, thumbChecks);
  const categories = {
    Titles: scoreTitles(m),
    Descriptions: scoreDescriptions(m),
    Tags: scoreTags(m),
    Performance: scorePerformance(m),
    Thumbnails: scoreThumbnails(m),
    Channel: scoreChannel(channelChecks),
    "AEO/GEO": scoreAeo(m, aeoChecks),
  };
  const weights: Record<string, number> = { Titles: 0.2, Descriptions: 0.15, Tags: 0.05, Performance: 0.2, Thumbnails: 0.2, Channel: 0.1, "AEO/GEO": 0.1 };
  const overall = clamp(Object.entries(categories).reduce((s, [k, v]) => s + v * weights[k], 0));
  const problems = detectProblems(channel, videos, m, niche, channelChecks, aeoChecks, thumbChecks);
  const wins = quickWins(problems, m);
  const { summary, opportunity } = buildSummary(channel, m, overall, categories, problems);
  return { overall, categories, problems, quickWins: wins, summary, opportunity, metrics: m };
}

/** Parse manual video rows: "Title ;; views ;; likes ;; comments ;; YYYY-MM-DD ;; durationSec ;; description" */
export function parseManualVideos(text: string): VideoData[] {
  return text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line, i) => {
      const [title = "", views = "0", likes = "0", comments = "0", date = "", dur = "0", ...rest] = line.split(";;").map((s) => s.trim());
      const publishedAt = date && !isNaN(Date.parse(date)) ? new Date(date).toISOString() : new Date(Date.now() - i * 7 * 86400000).toISOString();
      return { videoId: `manual-${i}-${title.slice(0, 8)}`, title, description: rest.join(";;"), publishedAt, views: +views || 0, likes: +likes || 0, comments: +comments || 0, durationSec: +dur || 0, tags: [] };
    });
}
