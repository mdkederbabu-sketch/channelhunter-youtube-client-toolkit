/**
 * Built-in outreach template library.
 * Templates use {variables} and [spin|syntax] for randomized phrasing variants.
 * Every first-message template follows the formula:
 *   specific compliment + one specific problem + small free value + tiny ask (free 2-minute audit)
 * Pricing is never included in first messages.
 */
import { LANGUAGES, SERVICES, type Language, type Service, type Template } from "./types";

type Pools = {
  openers: string[];
  problems: string[];
  value: Record<Service, string[]>;
  asks: string[];
  subjects: string[];
  followups: { day3: string; day7: string; day14: string };
  comments: string[];
};

const EN: Pools = {
  openers: [
    "Hi {name}, I watched '{video_title}' and the content is solid.",
    "[Hey|Hi] {name} – just finished '{video_title}'. [Really clear|Genuinely useful] breakdown.",
    "Hello {name}, '{video_title}' popped up in my feed and I [ended up watching the whole thing|took notes].",
    "{name}, quick one – I've been going through your channel and '{video_title}' [stood out|is a great example of your teaching style].",
  ],
  problems: [
    "One thing I noticed: {issue}.",
    "One small thing [that's|which is] holding it back: {issue}.",
    "[Here's what I spotted|What caught my eye]: {issue}.",
    "I did a quick check and {issue}.",
  ],
  value: {
    "YouTube SEO": [
      "That's likely holding back search discovery. A quick fix would be {fix}, which can lift CTR by {ctr_gain}.",
      "That means Google and YouTube search [can't|struggle to] match the video to '{keyword}'. Fix: {fix}.",
      "Videos like that usually [rank|show up] for '{keyword}' once you {fix} – [typically|often] a {ctr_gain} CTR lift.",
      "The fix is simple: {fix}. On similar channels it lifted search impressions 30-50%.",
    ],
    "Thumbnail/CTR": [
      "That caps click-through before the video even gets a chance. A quick win: {fix} – usually worth {ctr_gain} in CTR.",
      "Packaging does the heavy lifting on YouTube, and right now it's underselling the content. Fix: {fix}.",
      "Thumbnails [decide|control] whether the algorithm keeps pushing a video. {fix} would be the first thing I'd test.",
      "I sketched how {fix} could look on that video – happy to send it over, no strings.",
    ],
    "AEO/GEO": [
      "That's why ChatGPT, Perplexity and Google AI Overviews aren't citing you for '{keyword}' questions yet. Fix: {fix}.",
      "AI answer engines pull from videos that answer a question directly. {fix} makes your content quotable.",
      "A quick AEO fix: {fix}. It takes 10 minutes per video and compounds over time.",
      "Being the cited source for '{keyword}' is a free lead channel most creators ignore. Step one: {fix}.",
    ],
    "Channel Optimization": [
      "First-time visitors decide in 5 seconds. {fix} makes the channel page convert them into subscribers and leads.",
      "Your channel page is the landing page for your business. Quick fix: {fix}.",
      "A quick fix would be {fix} – a 20-minute change that lifts subscribe rate from the channel page.",
      "I'd start with {fix}; it's low effort and makes every future video work harder.",
    ],
    Analytics: [
      "Your analytics will show exactly where viewers drop and which topics bring buyers. Quick fix: {fix}.",
      "I'd {fix} and then watch CTR + average view duration for 14 days – the data usually points to the next win.",
      "Most of the gap shows up in the first 30 seconds of retention. A fix: {fix}.",
      "The numbers suggest {fix} first. It's measurable within two weeks.",
    ],
    "Full Growth Strategy": [
      "That's a symptom of packaging + search strategy, not content quality. Fix: {fix}.",
      "Fixing that plus a simple keyword plan is usually worth {ctr_gain} CTR and steadier growth in 90 days.",
      "The content is already there; a focused plan ({fix} first) would make it compound.",
      "A small system – {fix}, keyword clusters, consistent thumbnails – is what turns views into clients.",
    ],
  },
  asks: [
    "Want me to send a free 2-minute audit of your channel?",
    "If it's useful, I can send a free 2-minute audit – [no pitch|no strings], just the fixes.",
    "Happy to put a free 2-minute audit together – [want it|shall I send it]?",
    "Can I send over a free 2-minute audit? [Takes 2 minutes to read|Just 5 bullet points].",
  ],
  subjects: [
    "Quick idea for {channel}",
    "'{video_title}' – one small fix",
    "{name}, noticed something on your channel",
    "A free 2-minute audit for {channel}?",
    "{keyword} – you're close to ranking",
    "Loved '{video_title}' (one suggestion)",
  ],
  followups: {
    day3: "Hi {name}, quick idea – I [re-watched|went back to] '{video_title}' and I think {fix} could be a fast win on your next upload. Still happy to send that free 2-minute audit if useful.",
    day7: "Hey {name}, one more mini tip from your own data: {issue}. Fixing it ({fix}) is usually worth {ctr_gain} in CTR on channels your size. No reply needed – just thought it'd help.",
    day14: "Hi {name}, last note from me – I know inboxes get busy. If a free 2-minute audit of {channel} is ever useful, just reply 'audit' and I'll send it. Either way, keep going – the content deserves more reach.",
  },
  comments: [
    "The point about {takeaway} was really well explained – most people skip that part. Would love a follow-up going deeper on {keyword}.",
    "Saved this. [One thing I'd add|Something that helped me]: {tip}. Curious what you think, {name}?",
    "This deserves way more views. The {takeaway} part alone is worth the watch. Have you considered a Q&A episode on {keyword}?",
  ],
};

const BANGLISH: Pools = {
  openers: [
    "Hi {name} bhai, apnar '{video_title}' video ta dekhlam – content ta [onek|really] solid.",
    "Assalamu alaikum {name}, '{video_title}' ta [puro|full] dekhe fellam. [Khub|Onek] clear explanation.",
    "{name}, apnar channel ta ghurlam – '{video_title}' ta [best laglo|sotti valo laglo].",
    "Hello {name}, '{video_title}' feed e ashlo ar [sesh porjonto dekhlam|note nilam].",
  ],
  problems: [
    "Ekta jinish notice korlam: {issue}.",
    "Choto ekta problem [ache|dekhlam] jeta growth atkay rakhche: {issue}.",
    "Quick check korlam – {issue}.",
    "Ja chokhe porlo: {issue}.",
  ],
  value: {
    "YouTube SEO": [
      "Ei karone search e video ta [uthche na|discover hocche na]. Quick fix: {fix} – ete CTR {ctr_gain} barte pare.",
      "YouTube search '{keyword}' er sathe video ta match korte parche na. Fix: {fix}.",
      "{fix} korle '{keyword}' e rank kora onek easy hoye jay – usually {ctr_gain} CTR lift.",
      "Fix ta simple: {fix}. Similar channel e search impressions 30-50% bereche.",
    ],
    "Thumbnail/CTR": [
      "Ete click [ashe na|kome jay], video chance e pay na. Quick win: {fix} – usually {ctr_gain} CTR.",
      "YouTube e packaging i sob. Ekhon thumbnail content er theke kom sell korche. Fix: {fix}.",
      "Thumbnail decide kore algorithm push korbe kina. Ami prothome {fix} test kortam.",
      "{fix} kemon dekhabe ekta mockup banaisi – chaile pathiye dibo, free.",
    ],
    "AEO/GEO": [
      "Ei jonno ChatGPT/Perplexity/Google AI Overview '{keyword}' question e apnake cite korche na. Fix: {fix}.",
      "AI answer engine direct question-answer video pick kore. {fix} korle content quotable hoy.",
      "Quick AEO fix: {fix}. Video proti 10 minute lage, long term e compound kore.",
      "'{keyword}' er cited source hoya ekta free lead channel. Step one: {fix}.",
    ],
    "Channel Optimization": [
      "New visitor 5 second e decide kore. {fix} korle channel page theke subscriber ar lead ashe.",
      "Channel page tai apnar business er landing page. Quick fix: {fix}.",
      "Quick fix: {fix} – 20 minute er kaj, subscribe rate bare.",
      "Ami {fix} diye shuru kortam; kom effort, protita video beshi kaj kore.",
    ],
    Analytics: [
      "Analytics e dekha jabe viewer kothay drop korche ar kon topic buyer ane. Quick fix: {fix}.",
      "{fix} kore 14 din CTR + avg view duration dekhun – data i next win dekhay.",
      "Beshirbhag gap first 30 second er retention e. Fix: {fix}.",
      "Number gulo bolche age {fix} korte. 2 week e measurable.",
    ],
    "Full Growth Strategy": [
      "Eta content quality na, packaging + search strategy er symptom. Fix: {fix}.",
      "Eta fix + simple keyword plan = usually {ctr_gain} CTR ar 90 dine steady growth.",
      "Content already ache; focused plan ({fix} age) korle compound korbe.",
      "Choto ekta system – {fix}, keyword cluster, consistent thumbnail – view ke client banay.",
    ],
  },
  asks: [
    "Apnar channel er ekta free 2-minute audit pathabo?",
    "Chaile free 2-minute audit pathiye dite pari – [kono pitch na|no strings], just fix gulo.",
    "Free 2-minute audit ready kore dei? [Chaile bolben|Pathabo?]",
    "Ekta free 2-minute audit pathate pari? [5 ta bullet point matro|2 minute e porte parben].",
  ],
  subjects: [
    "{channel} er jonno quick idea",
    "'{video_title}' – ekta choto fix",
    "{name}, apnar channel e ekta jinish notice korlam",
    "{channel} er free 2-minute audit?",
    "'{video_title}' valo laglo (ekta suggestion)",
  ],
  followups: {
    day3: "Hi {name}, quick ekta idea – '{video_title}' abar dekhlam, mone hoy {fix} korle next upload e fast win pawa jabe. Free 2-minute audit ta ekhono pathate pari chaile.",
    day7: "{name} bhai, apnar data theke aro ekta choto tip: {issue}. Eta fix korle ({fix}) usually {ctr_gain} CTR bare. Reply na dileo problem nai – just help korar jonno bollam.",
    day14: "Hi {name}, amar last message – jani inbox busy thake. {channel} er free 2-minute audit kokhono dorkar hole just 'audit' likhe reply diben. Content ta aro reach deserve kore – continue korben.",
  },
  comments: [
    "{takeaway} er part ta khub valo explain korsen – beshirbhag manush eta skip kore. {keyword} niye ekta deep-dive video chai!",
    "Save kore rakhlam. [Ekta jinish add kortam|Amar jeta kaj e legeche]: {tip}. Apni ki mone koren {name}?",
    "Ei video aro onek view deserve kore. {takeaway} part tai dekhar moto. {keyword} niye ekta Q&A episode korben naki?",
  ],
};

const BN: Pools = {
  openers: [
    "হাই {name}, আপনার '{video_title}' ভিডিওটা দেখলাম – কনটেন্টটা [সত্যিই|অনেক] ভালো।",
    "আসসালামু আলাইকুম {name}, '{video_title}' পুরোটা দেখে ফেললাম। [খুব|অনেক] পরিষ্কার ব্যাখ্যা।",
    "{name}, আপনার চ্যানেলটা ঘুরে দেখলাম – '{video_title}' [সবচেয়ে ভালো লেগেছে|আলাদা করে চোখে পড়েছে]।",
    "হ্যালো {name}, '{video_title}' আমার ফিডে এসেছিল আর [শেষ পর্যন্ত দেখেছি|নোট নিয়েছি]।",
  ],
  problems: [
    "একটা জিনিস খেয়াল করলাম: {issue}।",
    "ছোট একটা সমস্যা [আছে|দেখলাম] যেটা গ্রোথ আটকে রাখছে: {issue}।",
    "দ্রুত একটা চেক করলাম – {issue}।",
    "যেটা চোখে পড়ল: {issue}।",
  ],
  value: {
    "YouTube SEO": [
      "এই কারণে সার্চে ভিডিওটা [উঠছে না|ডিসকভার হচ্ছে না]। দ্রুত সমাধান: {fix} – এতে CTR {ctr_gain} বাড়তে পারে।",
      "ইউটিউব সার্চ '{keyword}'-এর সাথে ভিডিওটা মেলাতে পারছে না। সমাধান: {fix}।",
      "{fix} করলে '{keyword}'-এ র‍্যাংক করা অনেক সহজ হয় – সাধারণত {ctr_gain} CTR বৃদ্ধি।",
      "সমাধানটা সহজ: {fix}। একই ধরনের চ্যানেলে সার্চ ইমপ্রেশন ৩০-৫০% বেড়েছে।",
    ],
    "Thumbnail/CTR": [
      "এতে ক্লিক [আসে না|কমে যায়], ভিডিও সুযোগই পায় না। দ্রুত জয়: {fix} – সাধারণত {ctr_gain} CTR।",
      "ইউটিউবে প্যাকেজিংই সব। এখন থাম্বনেইল কনটেন্টের চেয়ে কম বিক্রি করছে। সমাধান: {fix}।",
      "থাম্বনেইল ঠিক করে অ্যালগরিদম পুশ করবে কি না। আমি প্রথমে {fix} টেস্ট করতাম।",
      "{fix} কেমন দেখাবে তার একটা মকআপ বানিয়েছি – চাইলে পাঠিয়ে দেব, ফ্রি।",
    ],
    "AEO/GEO": [
      "এই জন্য ChatGPT/Perplexity/Google AI Overview '{keyword}' প্রশ্নে আপনাকে সাইট করছে না। সমাধান: {fix}।",
      "AI আনসার ইঞ্জিন সরাসরি প্রশ্ন-উত্তর ভিডিও বেছে নেয়। {fix} করলে কনটেন্ট উদ্ধৃতিযোগ্য হয়।",
      "দ্রুত AEO সমাধান: {fix}। প্রতি ভিডিওতে ১০ মিনিট লাগে, দীর্ঘমেয়াদে কম্পাউন্ড করে।",
      "'{keyword}'-এর সাইটেড সোর্স হওয়া একটা ফ্রি লিড চ্যানেল। প্রথম ধাপ: {fix}।",
    ],
    "Channel Optimization": [
      "নতুন ভিজিটর ৫ সেকেন্ডে সিদ্ধান্ত নেয়। {fix} করলে চ্যানেল পেজ থেকে সাবস্ক্রাইবার ও লিড আসে।",
      "চ্যানেল পেজই আপনার বিজনেসের ল্যান্ডিং পেজ। দ্রুত সমাধান: {fix}।",
      "দ্রুত সমাধান: {fix} – ২০ মিনিটের কাজ, সাবস্ক্রাইব রেট বাড়ে।",
      "আমি {fix} দিয়ে শুরু করতাম; কম পরিশ্রম, প্রতিটি ভিডিও বেশি কাজ করে।",
    ],
    Analytics: [
      "অ্যানালিটিক্সে দেখা যাবে দর্শক কোথায় ড্রপ করছে আর কোন টপিক ক্রেতা আনে। দ্রুত সমাধান: {fix}।",
      "{fix} করে ১৪ দিন CTR + গড় ভিউ ডিউরেশন দেখুন – ডেটাই পরের জয় দেখায়।",
      "বেশিরভাগ গ্যাপ প্রথম ৩০ সেকেন্ডের রিটেনশনে। সমাধান: {fix}।",
      "সংখ্যাগুলো বলছে আগে {fix} করতে। ২ সপ্তাহে পরিমাপযোগ্য।",
    ],
    "Full Growth Strategy": [
      "এটা কনটেন্ট কোয়ালিটি নয়, প্যাকেজিং + সার্চ স্ট্র্যাটেজির লক্ষণ। সমাধান: {fix}।",
      "এটা ঠিক করা + সহজ কিওয়ার্ড প্ল্যান = সাধারণত {ctr_gain} CTR আর ৯০ দিনে স্থির গ্রোথ।",
      "কনটেন্ট ইতিমধ্যে আছে; ফোকাসড প্ল্যান ({fix} আগে) করলে কম্পাউন্ড করবে।",
      "ছোট একটা সিস্টেম – {fix}, কিওয়ার্ড ক্লাস্টার, কনসিস্টেন্ট থাম্বনেইল – ভিউকে ক্লায়েন্ট বানায়।",
    ],
  },
  asks: [
    "আপনার চ্যানেলের একটা ফ্রি ২-মিনিটের অডিট পাঠাব?",
    "চাইলে ফ্রি ২-মিনিটের অডিট পাঠিয়ে দিতে পারি – [কোনো পিচ নয়|কোনো শর্ত নেই], শুধু সমাধানগুলো।",
    "ফ্রি ২-মিনিটের অডিট তৈরি করে দিই? [চাইলে বলবেন|পাঠাব?]",
    "একটা ফ্রি ২-মিনিটের অডিট পাঠাতে পারি? [মাত্র ৫টা বুলেট পয়েন্ট|২ মিনিটে পড়া যাবে]।",
  ],
  subjects: [
    "{channel}-এর জন্য দ্রুত একটা আইডিয়া",
    "'{video_title}' – একটা ছোট সমাধান",
    "{name}, আপনার চ্যানেলে একটা বিষয় খেয়াল করলাম",
    "{channel}-এর ফ্রি ২-মিনিটের অডিট?",
    "'{video_title}' ভালো লেগেছে (একটা পরামর্শ)",
  ],
  followups: {
    day3: "হাই {name}, দ্রুত একটা আইডিয়া – '{video_title}' আবার দেখলাম, মনে হয় {fix} করলে পরের আপলোডেই দ্রুত ফল পাবেন। চাইলে ফ্রি ২-মিনিটের অডিটটা এখনো পাঠাতে পারি।",
    day7: "{name}, আপনার ডেটা থেকে আরেকটা ছোট টিপ: {issue}। এটা ঠিক করলে ({fix}) সাধারণত {ctr_gain} CTR বাড়ে। উত্তর না দিলেও সমস্যা নেই – শুধু সাহায্য করার জন্য বললাম।",
    day14: "হাই {name}, আমার শেষ বার্তা – জানি ইনবক্স ব্যস্ত থাকে। {channel}-এর ফ্রি ২-মিনিটের অডিট কখনো দরকার হলে শুধু 'audit' লিখে রিপ্লাই দেবেন। কনটেন্টটা আরও রিচ পাওয়ার যোগ্য – চালিয়ে যান।",
  },
  comments: [
    "{takeaway} অংশটা খুব ভালো ব্যাখ্যা করেছেন – বেশিরভাগ মানুষ এটা এড়িয়ে যায়। {keyword} নিয়ে একটা গভীর ভিডিও চাই!",
    "সেভ করে রাখলাম। [একটা জিনিস যোগ করতাম|আমার যেটা কাজে লেগেছে]: {tip}। আপনি কী মনে করেন {name}?",
    "এই ভিডিও আরও অনেক ভিউ পাওয়ার যোগ্য। {takeaway} অংশটাই দেখার মতো। {keyword} নিয়ে একটা Q&A পর্ব করবেন নাকি?",
  ],
};

export const POOLS: Record<Language, Pools> = { English: EN, Banglish: BANGLISH, Bangla: BN };

const STYLE_NAMES = ["Specific compliment", "Clear & brief", "Feed discovery", "Channel review"];

/** Build the full built-in template set (72 first-message templates + follow-ups + comments). */
export function buildBuiltInTemplates(): Template[] {
  const out: Template[] = [];
  LANGUAGES.forEach((lang) => {
    const p = POOLS[lang];
    SERVICES.forEach((service) => {
      for (let i = 0; i < 4; i++) {
        out.push({
          name: `${service} – ${STYLE_NAMES[i]} (${lang})`,
          service,
          language: lang,
          type: "first",
          tone: "Any",
          body: `${p.openers[i]} ${p.problems[i]} ${p.value[service][i]} ${p.asks[i]}`,
          subjectPool: p.subjects,
          builtIn: true,
        });
      }
    });
    (["day3", "day7", "day14"] as const).forEach((d) => {
      out.push({
        name: `Follow-up ${d.replace("day", "Day ")} (${lang})`,
        service: "Any",
        language: lang,
        type: `followup${d.slice(3)}` as Template["type"],
        tone: "Any",
        body: p.followups[d],
        subjectPool: lang === "English" ? ["Re: quick idea for {channel}", "Quick idea", "One more thing for {channel}"] : p.subjects.slice(0, 2),
        builtIn: true,
      });
    });
    p.comments.forEach((c, i) => {
      out.push({ name: `Comment warm-up #${i + 1} (${lang})`, service: "Any", language: lang, type: "comment", tone: "Any", body: c, subjectPool: [], builtIn: true });
    });
  });
  return out;
}

export const DEFAULT_PACKAGES = [
  {
    name: "Starter",
    price: 149,
    period: "one-time" as const,
    highlight: false,
    deliverables: ["Full channel audit (PDF)", "Keyword map for 10 videos", "Title + description rewrite for 5 videos", "Thumbnail feedback on 5 videos"],
  },
  {
    name: "Growth",
    price: 399,
    period: "per month" as const,
    highlight: true,
    deliverables: ["Everything in Starter", "SEO for every new upload (titles, descriptions, tags, chapters)", "4 thumbnail designs / month", "Monthly analytics report + strategy call", "AEO/GEO optimisation (FAQ blocks, entity naming)"],
  },
  {
    name: "Premium",
    price: 899,
    period: "per month" as const,
    highlight: false,
    deliverables: ["Everything in Growth", "Unlimited thumbnails + A/B testing", "Content strategy & keyword clusters", "Channel page redesign (banner, about, playlists)", "Weekly performance review", "Priority support"],
  },
];
