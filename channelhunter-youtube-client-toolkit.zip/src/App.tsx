import { lazy, Suspense, useEffect } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import { applyTheme, useSettings } from "@/lib/settings";
import { seedDefaults } from "@/lib/leads";
import { purgeExpiredCache } from "@/lib/db";
import { Layout } from "@/components/Layout";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { ToastProvider } from "@/components/toast";
import { Onboarding } from "@/components/Onboarding";
import { Skeleton } from "@/components/ui";
import { useDueNotifications } from "@/pages/FollowUps";

const Dashboard = lazy(() => import("@/pages/Dashboard"));
const ChannelFinder = lazy(() => import("@/pages/ChannelFinder"));
const AuditPage = lazy(() => import("@/pages/Audit"));
const LeadsPage = lazy(() => import("@/pages/Leads"));
const OutreachPage = lazy(() => import("@/pages/Outreach"));
const FollowUpsPage = lazy(() => import("@/pages/FollowUps"));
const PipelinePage = lazy(() => import("@/pages/Pipeline"));
const ProposalsPage = lazy(() => import("@/pages/Proposals"));
const AnalyticsPage = lazy(() => import("@/pages/Analytics"));
const SettingsPage = lazy(() => import("@/pages/Settings"));
const RoutinePage = lazy(() => import("@/pages/Routine"));

function Fallback() {
  return (
    <div className="space-y-3">
      <Skeleton className="h-8 w-48" />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20" />)}</div>
      <Skeleton className="h-64" />
    </div>
  );
}

export default function App() {
  const [settings] = useSettings();
  useEffect(() => applyTheme(settings), [settings]);
  useEffect(() => {
    seedDefaults();
    purgeExpiredCache();
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const h = () => applyTheme(settings);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, [settings]);
  useDueNotifications(settings.notifications);

  return (
    <HashRouter>
      <ToastProvider>
        <Layout>
          <ErrorBoundary>
            <Suspense fallback={<Fallback />}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/finder" element={<ChannelFinder />} />
                <Route path="/audit" element={<AuditPage />} />
                <Route path="/audit/:leadId" element={<AuditPage />} />
                <Route path="/leads" element={<LeadsPage />} />
                <Route path="/outreach" element={<OutreachPage />} />
                <Route path="/followups" element={<FollowUpsPage />} />
                <Route path="/pipeline" element={<PipelinePage />} />
                <Route path="/proposals" element={<ProposalsPage />} />
                <Route path="/analytics" element={<AnalyticsPage />} />
                <Route path="/settings" element={<SettingsPage />} />
                <Route path="/routine" element={<RoutinePage />} />
                <Route path="*" element={<Dashboard />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </Layout>
        <Onboarding />
      </ToastProvider>
    </HashRouter>
  );
}
