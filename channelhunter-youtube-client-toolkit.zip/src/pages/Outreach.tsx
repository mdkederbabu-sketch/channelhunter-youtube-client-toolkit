import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Link, useSearchParams } from "react-router-dom";
import { Copy, Send, Sparkles, Plus, Trash2, RotateCcw, Save } from "lucide-react";
import { db } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { buildVars, commentDrafts, followUpType, generateVariants, spamCheck, VARIABLE_LIST, type Variant } from "@/lib/outreach";
import { buildBuiltInTemplates } from "@/lib/templates";
import { markAsSent } from "@/lib/leads";
import { LANGUAGES, MEDIUMS, SERVICES, TONES, type Language, type Medium, type Service, type Template, type Tone } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Badge, Button, Card, EmptyState, Field, Input, Select, Tabs, Textarea } from "@/components/ui";
import { copyText, useToast } from "@/components/toast";
import { cn } from "@/utils/cn";

type Mode = "first" | "followup" | "comment" | "library";

export function SpamMeter({ body, maxWords }: { body: string; maxWords: number }) {
  const r = spamCheck(body, maxWords);
  const color = r.level === "green" ? "bg-emerald-500" : r.level === "yellow" ? "bg-amber-500" : "bg-rose-500";
  return (
    <div className="text-[11px]">
      <div className="flex items-center gap-2">
        <span className={cn("inline-block h-2.5 w-2.5 rounded-full", color)} />
        <span className="font-medium capitalize">{r.level === "green" ? "Looks personal" : r.level === "yellow" ? "Some risk" : "High spam risk"}</span>
        <span className="text-slate-400">· {body.trim().split(/\s+/).filter(Boolean).length}/{maxWords} words</span>
        <div className="ml-auto h-1.5 w-24 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800"><div className={cn("h-full", color)} style={{ width: `${Math.max(5, r.score)}%` }} /></div>
      </div>
      {r.flags.length > 0 && <ul className="mt-1 list-inside list-disc text-slate-500">{r.flags.map((f) => <li key={f}>{f}</li>)}</ul>}
    </div>
  );
}

export default function OutreachPage() {
  const [params] = useSearchParams();
  const [settings] = useSettings();
  const { toast } = useToast();
  const leads = useLiveQuery(() => db.leads.filter((l) => !l.doNotContact).sortBy("updatedAt"), []);
  const templates = useLiveQuery(() => db.templates.toArray(), []);
  const [leadId, setLeadId] = useState<number>(Number(params.get("lead")) || 0);
  const lead = useLiveQuery(() => (leadId ? db.leads.get(leadId) : undefined), [leadId]);
  const proofs = useLiveQuery(() => (leadId ? db.proofs.where("leadId").equals(leadId).toArray() : []), [leadId]);
  const [proofId, setProofId] = useState<number>(0);
  const [service, setService] = useState<Service>((settings.services[0] as Service) ?? "YouTube SEO");
  const [medium, setMedium] = useState<Medium>("Email");
  const [tone, setTone] = useState<Tone>(settings.defaultTone);
  const [language, setLanguage] = useState<Language>(settings.defaultLanguage);
  const [mode, setMode] = useState<Mode>("first");
  const [templateId, setTemplateId] = useState<number>(0);
  const [variants, setVariants] = useState<Variant[]>([]);
  const [fuDay, setFuDay] = useState<number>(3);
  const [commentVars, setCommentVars] = useState({ takeaway: "", tip: "", video: "" });

  useEffect(() => {
    if (!leadId && leads?.length) setLeadId(leads[leads.length - 1].id!);
  }, [leads, leadId]);
  useEffect(() => {
    setProofId(proofs?.[0]?.id ?? 0);
  }, [proofs]);

  const typeNeeded: Template["type"] = mode === "followup" ? (followUpType(fuDay) === "check" ? "followup3" : (followUpType(fuDay) as Template["type"])) : mode === "comment" ? "comment" : "first";
  const pool = useMemo(() => (templates ?? []).filter((t) => t.language === language && t.type === typeNeeded && (t.service === service || t.service === "Any")), [templates, language, typeNeeded, service]);
  useEffect(() => {
    if (!pool.some((t) => t.id === templateId)) setTemplateId(pool[0]?.id ?? 0);
  }, [pool, templateId]);

  const proof = proofs?.find((p) => p.id === proofId) ?? null;
  const vars = useMemo(() => buildVars(lead ?? null, proof, settings, { takeaway: commentVars.takeaway || undefined, tip: commentVars.tip || undefined, video_title: commentVars.video || undefined }), [lead, proof, settings, commentVars]);

  const generate = () => {
    const tpl = pool.find((t) => t.id === templateId) ?? pool[0];
    if (!tpl) return toast("No template for this combination – add one in the library", "warning");
    if (mode === "comment") {
      setVariants(commentDrafts(language, vars).map((b) => ({ subject: "", body: b, words: b.split(/\s+/).length })));
      return;
    }
    setVariants(generateVariants(tpl, vars, tone, settings, medium));
  };

  const send = async (v: Variant) => {
    if (!lead) return;
    const tpl = pool.find((t) => t.id === templateId);
    await markAsSent({ leadId: lead.id!, service, medium, tone, language, templateId: tpl?.id, templateName: tpl?.name ?? "custom", subject: medium === "Email" ? v.subject : undefined, body: v.body, kind: mode === "comment" ? "comment" : mode === "followup" ? "followup" : "first", followUpDay: mode === "followup" ? fuDay : undefined });
    toast(mode === "first" ? "Logged as sent · follow-up sequence started" : "Logged as sent");
  };

  return (
    <div className="space-y-5">
      <PageHeader title="Outreach Studio" description="Template engine with real audit data. Formula: specific compliment + one specific problem + free value + tiny ask. No pricing in the first message. Sending is always manual." />
      <Tabs value={mode} onChange={(m) => { setMode(m); setVariants([]); }} tabs={[{ value: "first", label: "First message" }, { value: "followup", label: "Follow-ups" }, { value: "comment", label: "Comment warm-up" }, { value: "library", label: "Template library" }]} />

      {mode === "library" ? (
        <TemplateLibrary templates={templates ?? []} />
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title="Setup" className="space-y-3">
            <Field label="Lead">
              <Select value={leadId} onChange={(e) => setLeadId(Number(e.target.value))}>
                <option value={0}>Select lead…</option>
                {leads?.map((l) => <option key={l.id} value={l.id}>{l.name} · {l.stage}</option>)}
              </Select>
            </Field>
            {lead && (
              <Field label={`Pitch proof (${proofs?.length ?? 0} from audit)`} hint={!proofs?.length ? <span>No audit yet – <Link className="text-brand underline" to={`/audit/${lead.id}`}>run a 5-minute audit</Link> to pull real problems.</span> : undefined}>
                <Select value={proofId} onChange={(e) => setProofId(Number(e.target.value))}>
                  {!proofs?.length && <option value={0}>Generic placeholder</option>}
                  {proofs?.map((p) => <option key={p.id} value={p.id}>[{p.category}] {p.issue.slice(0, 70)}</option>)}
                </Select>
              </Field>
            )}
            <div className="grid grid-cols-2 gap-2">
              <Field label="Service"><Select value={service} onChange={(e) => setService(e.target.value as Service)}>{SERVICES.map((s) => <option key={s}>{s}</option>)}</Select></Field>
              <Field label="Medium"><Select value={medium} onChange={(e) => setMedium(e.target.value as Medium)}>{MEDIUMS.map((s) => <option key={s}>{s}</option>)}</Select></Field>
              <Field label="Tone"><Select value={tone} onChange={(e) => setTone(e.target.value as Tone)}>{TONES.map((s) => <option key={s}>{s}</option>)}</Select></Field>
              <Field label="Language"><Select value={language} onChange={(e) => setLanguage(e.target.value as Language)}>{LANGUAGES.map((s) => <option key={s}>{s}</option>)}</Select></Field>
            </div>
            {mode === "followup" && (
              <Field label="Follow-up day" hint="Day 3 = quick idea · Day 7 = mini tip from their data · Day 14 = polite last note">
                <Select value={fuDay} onChange={(e) => setFuDay(Number(e.target.value))}>{settings.followUpDays.filter((d) => d > 1).map((d) => <option key={d} value={d}>Day {d}</option>)}</Select>
              </Field>
            )}
            {mode === "comment" && (
              <>
                <Field label="Video to comment on"><Select value={commentVars.video} onChange={(e) => setCommentVars({ ...commentVars, video: e.target.value })}><option value="">Latest</option>{lead?.recentVideos?.map((v) => <option key={v.videoId} value={v.title}>{v.title.slice(0, 60)}</option>)}</Select></Field>
                <Field label="Specific takeaway you liked"><Input placeholder="e.g. the 3-step pricing framework" value={commentVars.takeaway} onChange={(e) => setCommentVars({ ...commentVars, takeaway: e.target.value })} /></Field>
                <Field label="A tip you'd add (value)"><Input placeholder="e.g. anchoring the price before the reveal" value={commentVars.tip} onChange={(e) => setCommentVars({ ...commentVars, tip: e.target.value })} /></Field>
              </>
            )}
            {mode !== "comment" && (
              <Field label={`Template (${pool.length})`}>
                <Select value={templateId} onChange={(e) => setTemplateId(Number(e.target.value))}>{pool.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select>
              </Field>
            )}
            <Button className="w-full" onClick={generate} disabled={!lead}><Sparkles className="h-4 w-4" /> Generate 3 variants</Button>
            <details className="text-[11px] text-slate-500">
              <summary className="cursor-pointer">Variables in use</summary>
              <div className="mt-1 grid grid-cols-1 gap-0.5">{VARIABLE_LIST.map((k) => <div key={k} className="truncate"><code>{`{${k}}`}</code> → {vars[k] || <i>empty</i>}</div>)}</div>
            </details>
          </Card>

          <div className="space-y-4 lg:col-span-2">
            {!variants.length ? (
              <EmptyState icon={<Send className="h-8 w-8" />} title="Generate to see 3 variants" hint="Each variant uses a different phrasing pool and subject line. Edit freely, check the spam meter, copy, then paste into your email / DM client and press Mark as sent." />
            ) : (
              variants.map((v, i) => <VariantCard key={i} index={i} v={v} medium={medium} maxWords={settings.maxWords} onChange={(nv) => setVariants((s) => s.map((x, j) => (j === i ? nv : x)))} onSend={() => send(v)} />)
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function VariantCard({ v, index, medium, maxWords, onChange, onSend }: { v: Variant; index: number; medium: Medium; maxWords: number; onChange: (v: Variant) => void; onSend: () => void }) {
  const { toast } = useToast();
  return (
    <Card title={`Variant ${index + 1}`} action={<div className="flex gap-1"><Button size="sm" variant="outline" onClick={() => copyText(medium === "Email" && v.subject ? `Subject: ${v.subject}\n\n${v.body}` : v.body).then(() => toast("Copied"))}><Copy className="h-3.5 w-3.5" /> Copy</Button><Button size="sm" onClick={onSend}><Send className="h-3.5 w-3.5" /> Mark as sent</Button></div>}>
      {medium === "Email" && v.subject !== undefined && v.subject !== "" && (
        <Input className="mb-2 font-medium" value={v.subject} onChange={(e) => onChange({ ...v, subject: e.target.value })} />
      )}
      <Textarea className="min-h-[140px] text-sm leading-relaxed" value={v.body} onChange={(e) => onChange({ ...v, body: e.target.value, words: e.target.value.split(/\s+/).filter(Boolean).length })} />
      <div className="mt-2"><SpamMeter body={v.body} maxWords={maxWords} /></div>
    </Card>
  );
}

function TemplateLibrary({ templates }: { templates: Template[] }) {
  const { toast } = useToast();
  const [filter, setFilter] = useState({ language: "English", type: "first", service: "" });
  const [editing, setEditing] = useState<Template | null>(null);
  const list = templates.filter((t) => t.language === filter.language && t.type === filter.type && (!filter.service || t.service === filter.service || t.service === "Any"));
  const save = async () => {
    if (!editing) return;
    if (editing.id) await db.templates.update(editing.id, { ...editing });
    else await db.templates.add({ ...editing });
    setEditing(null);
    toast("Template saved");
  };
  const reset = async () => {
    if (!confirm("Restore all built-in templates? Your custom templates are kept.")) return;
    await db.templates.filter((t) => t.builtIn).delete();
    await db.templates.bulkAdd(buildBuiltInTemplates());
    toast("Built-in templates restored");
  };
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title={`Templates (${list.length})`} className="lg:col-span-1" action={<Button size="sm" onClick={() => setEditing({ name: "My template", service: (filter.service as Service) || "YouTube SEO", language: filter.language as Language, type: filter.type as Template["type"], tone: "Any", body: "Hi {name}, I watched '{video_title}'… {issue}. {fix}. Want a free 2-minute audit?", subjectPool: ["Quick idea for {channel}"], builtIn: false })}><Plus className="h-3.5 w-3.5" /> New</Button>}>
        <div className="mb-3 grid grid-cols-3 gap-2">
          <Select value={filter.language} onChange={(e) => setFilter({ ...filter, language: e.target.value })}>{LANGUAGES.map((l) => <option key={l}>{l}</option>)}</Select>
          <Select value={filter.type} onChange={(e) => setFilter({ ...filter, type: e.target.value })}><option value="first">First</option><option value="followup3">Day 3</option><option value="followup7">Day 7</option><option value="followup14">Day 14</option><option value="comment">Comment</option></Select>
          <Select value={filter.service} onChange={(e) => setFilter({ ...filter, service: e.target.value })}><option value="">All services</option>{SERVICES.map((s) => <option key={s}>{s}</option>)}</Select>
        </div>
        <ul className="max-h-[480px] space-y-1 overflow-y-auto">
          {list.map((t) => (
            <li key={t.id}><button onClick={() => setEditing({ ...t })} className={cn("w-full rounded-lg border px-3 py-2 text-left text-xs hover:bg-slate-50 dark:hover:bg-slate-800", editing?.id === t.id ? "border-brand" : "border-slate-200 dark:border-slate-800")}><div className="font-medium">{t.name}</div><div className="truncate text-slate-500">{t.body}</div></button></li>
          ))}
        </ul>
        <Button size="sm" variant="ghost" className="mt-3" onClick={reset}><RotateCcw className="h-3.5 w-3.5" /> Restore built-ins</Button>
      </Card>
      <Card title={editing ? (editing.id ? "Edit template" : "New template") : "Editor"} className="lg:col-span-2" action={editing && <div className="flex gap-1">{editing.id && !editing.builtIn && <Button size="sm" variant="danger" onClick={async () => { await db.templates.delete(editing.id!); setEditing(null); }}><Trash2 className="h-3.5 w-3.5" /></Button>}<Button size="sm" onClick={save}><Save className="h-3.5 w-3.5" /> Save</Button></div>}>
        {!editing ? (
          <p className="text-sm text-slate-500">Select a template to edit, or create a new one. Use <code>{"{variables}"}</code> and <code>[option a|option b]</code> for spin variants.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Name" className="col-span-2"><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></Field>
            <Field label="Service"><Select value={editing.service} onChange={(e) => setEditing({ ...editing, service: e.target.value as Template["service"] })}><option>Any</option>{SERVICES.map((s) => <option key={s}>{s}</option>)}</Select></Field>
            <Field label="Language"><Select value={editing.language} onChange={(e) => setEditing({ ...editing, language: e.target.value as Language })}>{LANGUAGES.map((l) => <option key={l}>{l}</option>)}</Select></Field>
            <Field label="Type"><Select value={editing.type} onChange={(e) => setEditing({ ...editing, type: e.target.value as Template["type"] })}><option value="first">First message</option><option value="followup3">Follow-up day 3</option><option value="followup7">Follow-up day 7</option><option value="followup14">Follow-up day 14</option><option value="comment">Comment</option></Select></Field>
            <Field label="Subject pool (one per line)"><Textarea className="min-h-[60px]" value={editing.subjectPool.join("\n")} onChange={(e) => setEditing({ ...editing, subjectPool: e.target.value.split("\n").filter(Boolean) })} /></Field>
            <Field label="Body" className="col-span-2"><Textarea className="min-h-[160px]" value={editing.body} onChange={(e) => setEditing({ ...editing, body: e.target.value })} /></Field>
            <div className="col-span-2 flex flex-wrap gap-1">{VARIABLE_LIST.map((k) => <button key={k} onClick={() => setEditing({ ...editing, body: editing.body + ` {${k}}` })}><Badge color="brand">{`{${k}}`}</Badge></button>)}</div>
            {editing.builtIn && <p className="col-span-2 text-[11px] text-slate-500">Built-in template – edits are saved; use "Restore built-ins" to undo.</p>}
          </div>
        )}
      </Card>
    </div>
  );
}
