import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { useNavigate, useParams } from "react-router-dom";
import { Printer, Save, RefreshCw, Download } from "lucide-react";
import { db, logActivity, nowIso, setLeadStage } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { rescoreLead } from "@/lib/leads";
import { AEO_CHECKS, CHANNEL_CHECKS, THUMB_FIELDS, parseManualVideos, runAudit } from "@/lib/audit";
import { getRecentVideos, hasApiKey } from "@/lib/youtube";
import { auditReportHtml, openPrintWindow } from "@/lib/report";
import type { Audit, Lead, ThumbCheck, VideoData } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Badge, Button, Card, Checkbox, EmptyState, Field, Select, Skeleton, Textarea, fmt } from "@/components/ui";
import { useToast } from "@/components/toast";

const MANUAL_HINT = "How to Rank Videos in 2025 ;; 1200 ;; 45 ;; 12 ;; 2025-01-10 ;; 540 ;; description text\nTitle 2 ;; views ;; likes ;; comments ;; date ;; seconds ;; description";

export default function AuditPage() {
  const { leadId } = useParams();
  const nav = useNavigate();
  const { toast } = useToast();
  const [settings] = useSettings();
  const leads = useLiveQuery(() => db.leads.orderBy("updatedAt").reverse().toArray(), []);
  const lead = useLiveQuery(() => (leadId ? db.leads.get(Number(leadId)) : undefined), [leadId]);
  const previous = useLiveQuery(() => (leadId ? db.audits.where("leadId").equals(Number(leadId)).reverse().sortBy("createdAt") : []), [leadId]);

  const [videos, setVideos] = useState<VideoData[]>([]);
  const [thumbChecks, setThumbChecks] = useState<Record<string, ThumbCheck>>({});
  const [channelChecks, setChannelChecks] = useState<Record<string, boolean>>({});
  const [aeoChecks, setAeoChecks] = useState<Record<string, boolean>>({});
  const [manual, setManual] = useState("");
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState<Audit | null>(null);

  // Initialise from stored videos / previous audit when lead changes
  useEffect(() => {
    if (!lead) return;
    const prev = previous?.[0];
    if (prev) {
      setVideos(prev.videos);
      setThumbChecks(prev.thumbChecks);
      setChannelChecks(prev.channelChecks);
      setAeoChecks(prev.aeoChecks);
    } else {
      setVideos(lead.recentVideos ?? []);
      setThumbChecks({});
      const d = (lead.description ?? "").toLowerCase();
      setChannelChecks({
        banner: false,
        about: d.length > 400,
        keywords: Boolean(lead.keywords),
        featured: false,
        playlists: false,
        links: /https?:\/\/|www\./.test(d) || (lead.businessSignals ?? []).includes("website"),
        email: /@|business inquir/.test(d) || Boolean(lead.contact.email),
      });
      setAeoChecks({ faq: false, entity: true, captions: false, clusters: false });
    }
    setSaved(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lead?.id, previous?.length]);

  const result = useMemo(() => (lead ? runAudit({ channel: lead, videos, niche: lead.niche, thumbChecks, channelChecks, aeoChecks }) : null), [lead, videos, thumbChecks, channelChecks, aeoChecks]);

  const fetchVideos = async () => {
    if (!lead) return;
    setLoading(true);
    try {
      const v = await getRecentVideos(lead.channelId, 20);
      setVideos(v);
      await db.leads.update(lead.id!, { recentVideos: v });
      toast(`Fetched ${v.length} recent videos (2-3 units)`);
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setLoading(false);
    }
  };

  const toggleThumb = (id: string, key: keyof ThumbCheck) =>
    setThumbChecks((s) => {
      const base: ThumbCheck = s[id] ?? { textReadable: false, faceEmotion: false, highContrast: false, uncluttered: false, consistentStyle: false };
      return { ...s, [id]: { ...base, [key]: !base[key] } };
    });

  const save = async () => {
    if (!lead || !result) return;
    const audit: Audit = { leadId: lead.id!, createdAt: nowIso(), ...result, videos, thumbChecks, channelChecks, aeoChecks, niche: lead.niche };
    const id = await db.audits.add(audit);
    // Each detected problem becomes a reusable pitch-proof snippet
    await db.proofs.where("leadId").equals(lead.id!).delete();
    await db.proofs.bulkAdd(result.problems.map((p) => ({ leadId: lead.id!, auditId: id, category: p.category, issue: p.issue, fix: p.fix, videoTitle: p.videoTitle ?? "", videoId: p.videoId, keyword: p.keyword, createdAt: nowIso() })));
    await db.leads.update(lead.id!, { latestAuditId: id, updatedAt: nowIso() });
    if (lead.stage === "Found") await setLeadStage(lead.id!, "Audited");
    else await logActivity("audited", `Audit saved (${result.overall}/100)`, lead.id);
    await rescoreLead(lead.id!, { ...audit, id });
    setSaved({ ...audit, id });
    toast(`Audit saved · ${result.problems.length} pitch proofs created`);
  };

  if (!leads) return <Skeleton className="h-40" />;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Audit Engine"
        description="The 5-minute audit: automatic SEO/performance analysis + manual thumbnail & channel checklists → proof for your pitch."
        action={
          <Select className="w-64" value={leadId ?? ""} onChange={(e) => nav(e.target.value ? `/audit/${e.target.value}` : "/audit")}>
            <option value="">Select a lead…</option>
            {leads.map((l) => <option key={l.id} value={l.id}>{l.name} · {l.stage}</option>)}
          </Select>
        }
      />

      {!lead ? (
        <EmptyState title="Pick a lead to audit" hint="Add leads from the Channel Finder or press N. Then select one above." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          {/* Left: inputs */}
          <div className="space-y-4 lg:col-span-2">
            <Card title={`Videos (${videos.length})`} description="Last 15-20 uploads. Fetched via uploads playlist (2-3 units) or pasted manually." action={<div className="flex gap-2">{hasApiKey() && lead.channelId.startsWith("UC") && <Button size="sm" variant="secondary" onClick={fetchVideos} disabled={loading}><RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Fetch via API</Button>}</div>}>
              {!videos.length && (
                <div className="space-y-2">
                  <Field label="Manual mode – one video per line" hint="Format: Title ;; views ;; likes ;; comments ;; YYYY-MM-DD ;; durationSec ;; description (only title is required)">
                    <Textarea className="min-h-[120px] font-mono text-xs" placeholder={MANUAL_HINT} value={manual} onChange={(e) => setManual(e.target.value)} />
                  </Field>
                  <Button size="sm" onClick={() => { const v = parseManualVideos(manual); if (!v.length) return toast("Paste at least one line", "warning"); setVideos(v); db.leads.update(lead.id!, { recentVideos: v }); }}><Download className="h-3.5 w-3.5" /> Use these videos</Button>
                </div>
              )}
              {!!videos.length && (
                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="text-slate-500"><tr><th className="p-1.5">Title</th><th className="p-1.5">Len</th><th className="p-1.5">Views</th><th className="p-1.5">Eng%</th><th className="p-1.5">Chapters</th><th className="p-1.5">Tags</th></tr></thead>
                    <tbody>
                      {videos.map((v) => (
                        <tr key={v.videoId} className="border-t border-slate-100 dark:border-slate-800/60">
                          <td className="max-w-[260px] truncate p-1.5" title={v.title}>{v.durationSec > 0 && v.durationSec <= 60 && <Badge className="mr-1">Short</Badge>}{v.title}</td>
                          <td className={`p-1.5 ${v.title.length > 70 || v.title.length < 40 ? "text-amber-500" : ""}`}>{v.title.length}</td>
                          <td className="p-1.5">{fmt(v.views)}</td>
                          <td className="p-1.5">{v.views ? (((v.likes + v.comments) / v.views) * 100).toFixed(1) : "–"}</td>
                          <td className="p-1.5">{/0?0:00/.test(v.description) ? "✓" : "–"}</td>
                          <td className="p-1.5">{v.tags?.length ?? 0}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <button className="mt-2 text-[11px] text-slate-500 underline" onClick={() => setVideos([])}>Clear & paste manually</button>
                </div>
              )}
            </Card>

            <Card title="Thumbnail checklist (last 12)" description="Toggle what each thumbnail does well. CTR-risk score is computed from the failed checks.">
              {!videos.length ? (
                <p className="text-xs text-slate-500">Add videos first.</p>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {videos.slice(0, 12).map((v) => (
                    <div key={v.videoId} className="rounded-lg border border-slate-200 p-2 dark:border-slate-800">
                      {v.thumbnail ? <img src={v.thumbnail} className="mb-2 aspect-video w-full rounded-md object-cover" alt="" loading="lazy" /> : <div className="mb-2 flex aspect-video items-center justify-center rounded-md bg-slate-100 text-[10px] text-slate-400 dark:bg-slate-800">no thumbnail (manual)</div>}
                      <div className="mb-1 truncate text-[11px] font-medium" title={v.title}>{v.title}</div>
                      <div className="flex flex-wrap gap-1">
                        {THUMB_FIELDS.map((f) => (
                          <button key={f.key} onClick={() => toggleThumb(v.videoId, f.key)} className={`rounded-full border px-2 py-0.5 text-[10px] ${thumbChecks[v.videoId]?.[f.key] ? "border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950" : "border-slate-300 text-slate-500 dark:border-slate-700"}`}>{f.label}</button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <div className="grid gap-4 md:grid-cols-2">
              <Card title="Channel-level checklist" description="Auto-prefilled where possible; verify on the channel page.">
                <div className="space-y-2">{CHANNEL_CHECKS.map((c) => <Checkbox key={c.key} checked={!!channelChecks[c.key]} onChange={(v) => setChannelChecks((s) => ({ ...s, [c.key]: v }))} label={c.label} />)}</div>
              </Card>
              <Card title="AEO / GEO readiness" description="Answer-engine & generative-engine signals. Captions are a manual check (captions.list is quota-heavy).">
                <div className="space-y-2">{AEO_CHECKS.map((c) => <Checkbox key={c.key} checked={!!aeoChecks[c.key]} onChange={(v) => setAeoChecks((s) => ({ ...s, [c.key]: v }))} label={c.label} />)}</div>
                {result && <div className="mt-3 text-[11px] text-slate-500">Auto: question titles {result.metrics.titleQuestionPct}% · chapters {result.metrics.descChaptersPct}% · captions flag {result.metrics.captionsPct}%</div>}
              </Card>
            </div>
          </div>

          {/* Right: live results */}
          <div className="space-y-4">
            <Card title="Audit result" description={videos.length ? "Live – updates as you toggle checks" : "Add videos to compute"} action={<div className="flex gap-1"><Button size="sm" onClick={save} disabled={!videos.length}><Save className="h-3.5 w-3.5" /> Save</Button><Button size="sm" variant="outline" disabled={!saved && !previous?.[0]} onClick={() => openPrintWindow(auditReportHtml(lead, (saved ?? previous?.[0])!, settings))}><Printer className="h-3.5 w-3.5" /></Button></div>}>
              {result && (
                <>
                  <div className="mb-4 flex items-end gap-3">
                    <div className="text-5xl font-extrabold text-brand">{result.overall}</div>
                    <div className="pb-1 text-xs text-slate-500">/100 overall<br />{lead.name}</div>
                  </div>
                  <div className="space-y-2">
                    {Object.entries(result.categories).map(([k, v]) => (
                      <div key={k}>
                        <div className="flex justify-between text-xs"><span>{k}</span><b>{v}</b></div>
                        <div className="mt-0.5 h-1.5 rounded-full bg-slate-200 dark:bg-slate-800"><div className={`h-full rounded-full ${v < 40 ? "bg-rose-500" : v < 70 ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${v}%` }} /></div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-2 text-[11px]">
                    <M k="Avg views" v={fmt(result.metrics.avgViews)} /><M k="Views/sub" v={`${Math.round(result.metrics.viewsToSubRatio * 100)}%`} />
                    <M k="Engagement" v={`${result.metrics.engagementRate}%`} /><M k="Upload gap" v={`${result.metrics.uploadGapDays}d ±${result.metrics.uploadGapStdDev}`} />
                    <M k="Title len" v={`${result.metrics.avgTitleLen} ch`} /><M k="Kw in titles" v={`${result.metrics.titleKeywordPct}%`} />
                    <M k="Chapters" v={`${result.metrics.descChaptersPct}%`} /><M k="Shorts" v={`${result.metrics.shortsPct}%`} />
                    <M k="Thumb risk" v={`${result.metrics.thumbRisk}`} /><M k="Tags" v={`${result.metrics.tagsPct}%`} />
                  </div>
                </>
              )}
            </Card>
            {result && videos.length > 0 && (
              <>
                <Card title="Summary"><p className="text-xs leading-relaxed">{result.summary}</p><p className="mt-2 rounded-lg bg-brand/10 p-2 text-xs text-brand">{result.opportunity}</p></Card>
                <Card title="Top 5 problems → pitch proofs">
                  <ol className="space-y-2 text-xs">
                    {result.problems.slice(0, 5).map((p, i) => (
                      <li key={i} className="rounded-lg border border-slate-200 p-2 dark:border-slate-800">
                        <div className="flex items-center gap-2"><Badge color={p.severity > 70 ? "red" : "amber"}>{p.category}</Badge><span className="text-[10px] text-slate-400">severity {p.severity}</span></div>
                        <div className="mt-1"><b>Issue:</b> {p.issue}</div>
                        <div><b>Fix:</b> {p.fix}</div>
                        {p.videoTitle && <div className="truncate text-[10px] text-slate-500">e.g. "{p.videoTitle}"</div>}
                      </li>
                    ))}
                    {!result.problems.length && <li className="text-slate-500">No major problems detected.</li>}
                  </ol>
                </Card>
                <Card title="Top 5 quick wins"><ul className="list-inside list-disc space-y-1 text-xs">{result.quickWins.map((w, i) => <li key={i}>{w}</li>)}</ul></Card>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function M({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between rounded bg-slate-50 px-2 py-1 dark:bg-slate-800"><span className="text-slate-500">{k}</span><b>{v}</b></div>;
}

export type { Lead };
