import { useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { DndContext, DragOverlay, PointerSensor, TouchSensor, useDraggable, useDroppable, useSensor, useSensors, type DragEndEvent, type DragStartEvent } from "@dnd-kit/core";
import { format, formatDistanceToNow, startOfMonth } from "date-fns";
import { DollarSign, KanbanSquare } from "lucide-react";
import { db, setLeadStage } from "@/lib/db";
import { STAGES, NICHES, type Lead, type Stage } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Badge, Card, Input, ScoreBadge, Select, Skeleton, Stat, fmt } from "@/components/ui";
import { LeadDrawer } from "@/components/LeadDrawer";
import { cn } from "@/utils/cn";

export default function PipelinePage() {
  const leads = useLiveQuery(() => db.leads.toArray(), []);
  const [q, setQ] = useState("");
  const [niche, setNiche] = useState("");
  const [label, setLabel] = useState("");
  const [openId, setOpenId] = useState<number | null>(null);
  const [active, setActive] = useState<Lead | null>(null);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }), useSensor(TouchSensor, { activationConstraint: { delay: 150, tolerance: 6 } }));

  const filtered = useMemo(() => (leads ?? []).filter((l) => (!q || l.name.toLowerCase().includes(q.toLowerCase()) || l.tags.some((t) => t.toLowerCase().includes(q.toLowerCase()))) && (!niche || l.niche === niche) && (!label || l.scoreLabel === label)), [leads, q, niche, label]);
  const byStage = useMemo(() => Object.fromEntries(STAGES.map((s) => [s, filtered.filter((l) => l.stage === s).sort((a, b) => b.score - a.score)])) as Record<Stage, Lead[]>, [filtered]);

  const won = (leads ?? []).filter((l) => l.stage === "Won");
  const monthStart = startOfMonth(new Date()).toISOString();
  const revenueMonth = won.filter((l) => (l.wonAt ?? l.updatedAt) >= monthStart).reduce((s, l) => s + l.dealValue, 0);
  const mrr = won.filter((l) => l.dealType === "retainer").reduce((s, l) => s + l.dealValue, 0);
  const pipelineValue = (leads ?? []).filter((l) => !["Won", "Lost", "Found"].includes(l.stage)).reduce((s, l) => s + l.dealValue, 0);

  const onDragEnd = async (e: DragEndEvent) => {
    setActive(null);
    const over = e.over?.id as Stage | undefined;
    const id = Number(e.active.id);
    if (!over || !STAGES.includes(over)) return;
    await setLeadStage(id, over);
  };
  const onDragStart = (e: DragStartEvent) => setActive(leads?.find((l) => l.id === Number(e.active.id)) ?? null);

  if (!leads) return <Skeleton className="h-96" />;

  return (
    <div className="space-y-4">
      <PageHeader title="CRM Pipeline" description="Drag cards between stages. Moving to Replied / Won / Lost stops follow-ups automatically." />
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label={`Revenue won · ${format(new Date(), "MMMM")}`} value={`$${revenueMonth.toLocaleString()}`} icon={<DollarSign className="h-5 w-5" />} sub={`${won.length} clients total`} />
        <Stat label="Monthly retainers (MRR)" value={`$${mrr.toLocaleString()}`} icon={<DollarSign className="h-5 w-5" />} />
        <Stat label="Open pipeline value" value={`$${pipelineValue.toLocaleString()}`} icon={<KanbanSquare className="h-5 w-5" />} sub="deal values on active leads" />
      </div>
      <Card className="p-3">
        <div className="flex flex-wrap gap-2">
          <Input className="w-56" placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} />
          <Select className="w-40" value={niche} onChange={(e) => setNiche(e.target.value)}><option value="">All niches</option>{NICHES.map((n) => <option key={n}>{n}</option>)}</Select>
          <Select className="w-32" value={label} onChange={(e) => setLabel(e.target.value)}><option value="">All scores</option><option>Hot</option><option>Warm</option><option>Cold</option></Select>
        </div>
      </Card>
      <DndContext sensors={sensors} onDragEnd={onDragEnd} onDragStart={onDragStart}>
        <div className="flex gap-3 overflow-x-auto pb-3">
          {STAGES.map((s) => <Column key={s} stage={s} leads={byStage[s]} onOpen={setOpenId} />)}
        </div>
        <DragOverlay>{active && <LeadCard lead={active} overlay />}</DragOverlay>
      </DndContext>
      <LeadDrawer leadId={openId} onClose={() => setOpenId(null)} />
    </div>
  );
}

function Column({ stage, leads, onOpen }: { stage: Stage; leads: Lead[]; onOpen: (id: number) => void }) {
  const { setNodeRef, isOver } = useDroppable({ id: stage });
  const value = leads.reduce((s, l) => s + l.dealValue, 0);
  return (
    <div ref={setNodeRef} className={cn("flex w-64 shrink-0 flex-col rounded-xl border border-slate-200 bg-slate-100/60 dark:border-slate-800 dark:bg-slate-900/60", isOver && "ring-2 ring-brand")}>
      <div className="flex items-center justify-between px-3 py-2 text-xs font-semibold">
        <span>{stage}</span>
        <span className="text-slate-500">{leads.length}{value ? ` · $${fmt(value)}` : ""}</span>
      </div>
      <div className="flex min-h-[120px] flex-1 flex-col gap-2 p-2">
        {leads.map((l) => <DraggableCard key={l.id} lead={l} onOpen={onOpen} />)}
        {!leads.length && <div className="flex-1 rounded-lg border border-dashed border-slate-300 p-3 text-center text-[11px] text-slate-400 dark:border-slate-700">Drop here</div>}
      </div>
    </div>
  );
}

function DraggableCard({ lead, onOpen }: { lead: Lead; onOpen: (id: number) => void }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: lead.id! });
  const style = transform ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` } : undefined;
  return (
    <div ref={setNodeRef} style={style} {...listeners} {...attributes} className={cn(isDragging && "opacity-30")} onClick={() => onOpen(lead.id!)}>
      <LeadCard lead={lead} />
    </div>
  );
}

function LeadCard({ lead, overlay }: { lead: Lead; overlay?: boolean }) {
  return (
    <div className={cn("card cursor-grab space-y-1.5 p-3 active:cursor-grabbing", overlay && "rotate-2 shadow-xl")}>
      <div className="flex items-center gap-2">
        {lead.avatar ? <img src={lead.avatar} className="h-6 w-6 rounded-full" alt="" /> : <div className="h-6 w-6 rounded-full bg-brand/20" />}
        <div className="truncate text-sm font-medium">{lead.name}</div>
      </div>
      <div className="flex flex-wrap items-center gap-1">
        <ScoreBadge score={lead.score} label={lead.scoreLabel} />
        <Badge>{lead.niche}</Badge>
        {lead.dealValue > 0 && <Badge color="green">${fmt(lead.dealValue)}{lead.dealType === "retainer" ? "/mo" : ""}</Badge>}
      </div>
      <div className="flex justify-between text-[10px] text-slate-500">
        <span>{formatDistanceToNow(new Date(lead.lastActivityAt), { addSuffix: true }).replace("about ", "")}</span>
        {lead.nextFollowUpAt && <span className={new Date(lead.nextFollowUpAt) < new Date() ? "text-rose-500" : ""}>↻ {format(new Date(lead.nextFollowUpAt), "d MMM")}</span>}
      </div>
    </div>
  );
}
