import { useMemo } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { format, startOfWeek, subWeeks } from "date-fns";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { db } from "@/lib/db";
import { STAGES, stageIndex, type Lead, type Message } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Card, EmptyState, Skeleton, Stat } from "@/components/ui";

const FUNNEL = [
  { label: "Found", min: 0 },
  { label: "Audited", min: 1 },
  { label: "Contacted", min: 2 },
  { label: "Replied", min: 3 },
  { label: "Call", min: 4 },
  { label: "Won", min: 6 },
];

export default function AnalyticsPage() {
  const leads = useLiveQuery(() => db.leads.toArray(), []);
  const messages = useLiveQuery(() => db.messages.toArray(), []);
  const activities = useLiveQuery(() => db.activities.toArray(), []);

  const data = useMemo(() => {
    if (!leads || !messages || !activities) return null;
    const live = leads.filter((l) => l.stage !== "Lost");
    const funnel = FUNNEL.map((f) => ({ name: f.label, value: f.label === "Audited" ? leads.filter((l) => l.latestAuditId || stageIndex(l.stage) >= 1).length : f.label === "Won" ? leads.filter((l) => l.stage === "Won").length : live.filter((l) => stageIndex(l.stage) >= f.min).length }));
    const leadMap = new Map(leads.map((l) => [l.id!, l]));
    const replied = (l?: Lead) => !!l && stageIndex(l.stage) >= 3 && l.stage !== "Lost";
    const firsts = messages.filter((m) => m.kind === "first");
    const breakdown = (key: (m: Message, l?: Lead) => string) => {
      const g = new Map<string, { sent: number; replied: number }>();
      firsts.forEach((m) => {
        const k = key(m, leadMap.get(m.leadId)) || "–";
        const e = g.get(k) ?? { sent: 0, replied: 0 };
        e.sent++;
        if (replied(leadMap.get(m.leadId))) e.replied++;
        g.set(k, e);
      });
      return Array.from(g.entries()).map(([name, v]) => ({ name, sent: v.sent, replied: v.replied, rate: v.sent ? Math.round((v.replied / v.sent) * 100) : 0 })).sort((a, b) => b.rate - a.rate || b.sent - a.sent);
    };
    const won = leads.filter((l) => l.stage === "Won");
    const weeks = Array.from({ length: 8 }, (_, i) => startOfWeek(subWeeks(new Date(), 7 - i), { weekStartsOn: 1 }));
    const weekly = weeks.map((w, i) => {
      const end = weeks[i + 1]?.toISOString() ?? new Date(8.64e15).toISOString();
      const ws = w.toISOString();
      const acts = activities.filter((a) => a.at >= ws && a.at < end);
      return { week: format(w, "d MMM"), Found: acts.filter((a) => a.type === "found").length, Audits: acts.filter((a) => a.type === "audited").length, Messages: acts.filter((a) => a.type === "contacted").length, Replies: acts.filter((a) => a.type === "replied").length };
    });
    return {
      funnel,
      byService: breakdown((m) => m.service),
      byMedium: breakdown((m) => m.medium),
      byTemplate: breakdown((m) => m.templateName),
      byNiche: breakdown((_m, l) => l?.niche ?? "–"),
      byToneLang: breakdown((m) => `${m.tone} · ${m.language}`),
      revenue: won.reduce((s, l) => s + l.dealValue, 0),
      mrr: won.filter((l) => l.dealType === "retainer").reduce((s, l) => s + l.dealValue, 0),
      pipeline: leads.filter((l) => !["Won", "Lost", "Found"].includes(l.stage)).reduce((s, l) => s + l.dealValue, 0),
      weekly,
      sent: firsts.length,
      replyRate: firsts.length ? Math.round((firsts.filter((m) => replied(leadMap.get(m.leadId))).length / firsts.length) * 100) : 0,
    };
  }, [leads, messages, activities]);

  if (!data) return <Skeleton className="h-96" />;

  return (
    <div className="space-y-5">
      <PageHeader title="Analytics" description="What's working: funnel, reply rates by service / medium / template / niche / tone, revenue and weekly history." />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="First messages sent" value={data.sent} />
        <Stat label="Overall reply rate" value={`${data.replyRate}%`} />
        <Stat label="Revenue won" value={`$${data.revenue.toLocaleString()}`} sub={`MRR $${data.mrr.toLocaleString()}`} />
        <Stat label="Pipeline value" value={`$${data.pipeline.toLocaleString()}`} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Funnel" description="found → audited → contacted → replied → call → won">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.funnel} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-slate-200 dark:text-slate-800" />
                <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={70} />
                <Tooltip contentStyle={{ borderRadius: 10, fontSize: 12 }} />
                <Bar dataKey="value" radius={[0, 6, 6, 0]}>{data.funnel.map((_, i) => <Cell key={i} fill="var(--brand)" fillOpacity={1 - i * 0.12} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Weekly activity history" description="Last 8 weeks">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.weekly}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-slate-200 dark:text-slate-800" />
                <XAxis dataKey="week" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={28} />
                <Tooltip contentStyle={{ borderRadius: 10, fontSize: 12 }} />
                <Line type="monotone" dataKey="Found" stroke="var(--brand)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="Audits" stroke="#10b981" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="Messages" stroke="#f59e0b" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="Replies" stroke="#ef4444" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
      {!data.sent ? (
        <EmptyState title="No outreach data yet" hint="Reply-rate breakdowns appear once you mark messages as sent and move leads to Replied." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          <Breakdown title="Reply rate by service" rows={data.byService} />
          <Breakdown title="Reply rate by medium" rows={data.byMedium} />
          <Breakdown title="Best performing templates" rows={data.byTemplate} />
          <Breakdown title="Reply rate by niche" rows={data.byNiche} />
          <Breakdown title="Reply rate by tone / language" rows={data.byToneLang} />
          <Card title="Stage distribution">
            <div className="space-y-1.5 text-xs">{STAGES.map((s) => { const n = leads!.filter((l) => l.stage === s).length; return <div key={s} className="flex items-center gap-2"><span className="w-24 text-slate-500">{s}</span><div className="h-2 flex-1 rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-full rounded-full bg-brand" style={{ width: `${leads!.length ? (n / leads!.length) * 100 : 0}%` }} /></div><span className="w-6 text-right font-medium">{n}</span></div>; })}</div>
          </Card>
        </div>
      )}
    </div>
  );
}

function Breakdown({ title, rows }: { title: string; rows: { name: string; sent: number; replied: number; rate: number }[] }) {
  return (
    <Card title={title}>
      {!rows.length ? <p className="text-xs text-slate-500">No data.</p> : (
        <table className="w-full text-xs"><thead className="text-slate-500"><tr><th className="pb-1 text-left">Name</th><th className="pb-1 text-right">Sent</th><th className="pb-1 text-right">Replied</th><th className="pb-1 text-right">Rate</th></tr></thead>
          <tbody>{rows.slice(0, 8).map((r) => <tr key={r.name} className="border-t border-slate-100 dark:border-slate-800/60"><td className="max-w-[160px] truncate py-1.5" title={r.name}>{r.name}</td><td className="text-right">{r.sent}</td><td className="text-right">{r.replied}</td><td className="text-right font-semibold">{r.rate}%</td></tr>)}</tbody></table>
      )}
    </Card>
  );
}
