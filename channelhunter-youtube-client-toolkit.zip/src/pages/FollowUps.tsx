import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Link } from "react-router-dom";
import { addDays, endOfDay, format, startOfDay } from "date-fns";
import { Bell, CheckCircle2, Copy, Send, Clock, BellRing } from "lucide-react";
import { db } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { completeTask, markAsSent } from "@/lib/leads";
import { buildVars, followUpType, render, applyTone } from "@/lib/outreach";
import type { Lead, Task, Template } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Badge, Button, Card, EmptyState, Skeleton, Switch, Tabs } from "@/components/ui";
import { copyText, useToast } from "@/components/toast";

type Tab = "today" | "overdue" | "upcoming" | "done";

/** Fire one browser notification per day for due follow-ups (if the user opted in). */
export function useDueNotifications(enabled: boolean) {
  useEffect(() => {
    if (!enabled || typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const key = `channelhunter.notified.${new Date().toDateString()}`;
    if (localStorage.getItem(key)) return;
    db.tasks.filter((t) => !t.done && t.dueAt <= endOfDay(new Date()).toISOString()).count().then((n) => {
      if (n > 0) {
        new Notification("ChannelHunter – follow-ups due", { body: `${n} follow-up${n > 1 ? "s" : ""} due today. Open the Task Inbox.` });
        localStorage.setItem(key, "1");
      }
    });
  }, [enabled]);
}

export default function FollowUpsPage() {
  const [settings, save] = useSettings();
  const { toast } = useToast();
  const tasks = useLiveQuery(() => db.tasks.orderBy("dueAt").toArray(), []);
  const leads = useLiveQuery(() => db.leads.toArray(), []);
  const templates = useLiveQuery(() => db.templates.toArray(), []);
  const [tab, setTab] = useState<Tab>("today");
  const leadMap = useMemo(() => new Map(leads?.map((l) => [l.id!, l])), [leads]);

  const now = new Date();
  const buckets = useMemo(() => {
    const t = tasks ?? [];
    const sod = startOfDay(now).toISOString();
    const eod = endOfDay(now).toISOString();
    return {
      today: t.filter((x) => !x.done && x.dueAt >= sod && x.dueAt <= eod),
      overdue: t.filter((x) => !x.done && x.dueAt < sod),
      upcoming: t.filter((x) => !x.done && x.dueAt > eod),
      done: t.filter((x) => x.done).reverse(),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasks]);

  const askPermission = async () => {
    if (typeof Notification === "undefined") return toast("Notifications not supported in this browser", "warning");
    const p = await Notification.requestPermission();
    if (p === "granted") {
      save({ notifications: true });
      toast("Reminders enabled – you'll get one notification per day when follow-ups are due");
    } else toast("Permission denied", "warning");
  };

  if (!tasks || !leads) return <Skeleton className="h-64" />;
  const list = buckets[tab];

  return (
    <div className="space-y-5">
      <PageHeader title="Follow-ups" description={`Reminders only – nothing is auto-sent. Sequence: Day ${settings.followUpDays.join(", ")}. Auto-stops on Replied / Won / Lost / Do-not-contact.`} action={
        <div className="flex items-center gap-3 text-xs">
          {typeof Notification !== "undefined" && Notification.permission === "granted" ? (
            <Switch checked={settings.notifications} onChange={(v) => save({ notifications: v })} label="Browser reminders" />
          ) : (
            <Button size="sm" variant="outline" onClick={askPermission}><Bell className="h-3.5 w-3.5" /> Enable reminders</Button>
          )}
        </div>
      } />

      <Tabs value={tab} onChange={setTab} tabs={[
        { value: "today", label: `Today (${buckets.today.length})` },
        { value: "overdue", label: <span className={buckets.overdue.length ? "text-rose-500" : ""}>Overdue ({buckets.overdue.length})</span> },
        { value: "upcoming", label: `Upcoming (${buckets.upcoming.length})` },
        { value: "done", label: `Done (${buckets.done.length})` },
      ]} />

      {!list.length ? (
        <EmptyState icon={<BellRing className="h-8 w-8" />} title={tab === "done" ? "Nothing completed yet" : "Inbox zero"} hint="Tasks are created automatically when you press “Mark as sent” on a first message in Outreach Studio." />
      ) : (
        <div className="space-y-3">
          {list.map((t) => <TaskCard key={t.id} task={t} lead={leadMap.get(t.leadId)} templates={templates ?? []} />)}
        </div>
      )}
    </div>
  );
}

function TaskCard({ task, lead, templates }: { task: Task; lead?: Lead; templates: Template[] }) {
  const [settings] = useSettings();
  const { toast } = useToast();
  const proofs = useLiveQuery(() => db.proofs.where("leadId").equals(task.leadId).toArray(), [task.leadId]);
  const lastMsg = useLiveQuery(() => db.messages.where("leadId").equals(task.leadId).reverse().sortBy("sentAt").then((m) => m[0]), [task.leadId]);
  const [open, setOpen] = useState(false);

  const type = followUpType(task.day);
  const lang = lastMsg?.language ?? settings.defaultLanguage;
  const tpl = type === "check" ? null : templates.find((t) => t.type === type && t.language === lang) ?? templates.find((t) => t.type === type);
  const draft = useMemo(() => {
    if (!lead) return "";
    const vars = buildVars(lead, proofs?.[0] ?? null, settings);
    if (!tpl) return `Day ${task.day}: open ${lead.name}'s latest video, leave a genuine comment, and check whether they replied.`;
    return applyTone(render(tpl.body, vars, task.day % 3, tpl.language), lastMsg?.tone ?? settings.defaultTone, tpl.language);
  }, [lead, proofs, settings, tpl, task.day, lastMsg]);

  const overdue = !task.done && new Date(task.dueAt) < startOfDay(new Date());
  const sendAndComplete = async () => {
    if (!lead) return;
    if (type !== "check") {
      await markAsSent({ leadId: lead.id!, service: lastMsg?.service ?? "YouTube SEO", medium: lastMsg?.medium ?? "Email", tone: lastMsg?.tone ?? settings.defaultTone, language: lang, templateId: tpl?.id, templateName: tpl?.name ?? "follow-up", body: draft, kind: "followup", followUpDay: task.day });
    }
    await completeTask(task.id!);
    toast("Follow-up logged & task completed");
  };
  const snooze = async (days: number) => {
    await db.tasks.update(task.id!, { dueAt: addDays(new Date(), days).toISOString() });
    toast(`Snoozed ${days} day${days > 1 ? "s" : ""}`, "info");
  };

  return (
    <Card className="p-4">
      <div className="flex flex-wrap items-center gap-2">
        <Badge color={task.done ? "green" : overdue ? "red" : "brand"}>Day {task.day}</Badge>
        <Link to={`/leads?open=${task.leadId}`} className="font-medium hover:underline">{lead?.name ?? "Deleted lead"}</Link>
        {lead && <Badge>{lead.stage}</Badge>}
        <span className="ml-auto inline-flex items-center gap-1 text-xs text-slate-500"><Clock className="h-3 w-3" /> {format(new Date(task.dueAt), "EEE d MMM")}</span>
      </div>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{task.title}</p>
      {!task.done && (
        <>
          <button className="mt-2 text-xs text-brand underline" onClick={() => setOpen((o) => !o)}>{open ? "Hide" : "Show"} follow-up draft</button>
          {open && <pre className="mt-2 whitespace-pre-wrap rounded-lg bg-slate-50 p-3 font-sans text-xs leading-relaxed dark:bg-slate-800">{draft}</pre>}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => copyText(draft).then(() => toast("Draft copied"))}><Copy className="h-3.5 w-3.5" /> Copy draft</Button>
            <Button size="sm" onClick={sendAndComplete}><Send className="h-3.5 w-3.5" /> {type === "check" ? "Done" : "Mark as sent"}</Button>
            <Button size="sm" variant="ghost" onClick={() => completeTask(task.id!)}><CheckCircle2 className="h-3.5 w-3.5" /> Skip</Button>
            <Button size="sm" variant="ghost" onClick={() => snooze(1)}>Snooze 1d</Button>
            <Button size="sm" variant="ghost" onClick={() => snooze(3)}>Snooze 3d</Button>
          </div>
        </>
      )}
    </Card>
  );
}
