import { useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { ExternalLink, Gem, Briefcase, Layers, Search, AlertTriangle, Info } from "lucide-react";
import { db, nowIso } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { COST, enrichWithVideos, estimateEnrichCost, getChannels, getRecentVideos, hasApiKey, resolveChannel, searchChannels, parseChannelInput } from "@/lib/youtube";
import { scoreLead, skipReason } from "@/lib/scoring";
import { createLeadFromChannel } from "@/lib/leads";
import { NICHES, type ChannelData } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Badge, Button, Card, Checkbox, Dialog, EmptyState, Field, Input, ScoreBadge, Select, Skeleton, Textarea, fmt } from "@/components/ui";
import { useToast } from "@/components/toast";

type Preset = "none" | "deep" | "gems" | "business";

interface Filters {
  q: string;
  minSubs: number;
  maxSubs: number;
  country: string;
  language: string;
  lastUploadDays: number;
  minVideos: number;
  minAvgViews: number;
  maxAvgViews: number;
  niche: string;
}

const MAX_ENRICH = 25;

export default function ChannelFinder() {
  const [settings] = useSettings();
  const { toast } = useToast();
  const api = hasApiKey();
  const [f, setF] = useState<Filters>({ q: "", minSubs: settings.subRange.min, maxSubs: settings.subRange.max, country: "", language: "", lastUploadDays: 30, minVideos: 10, minAvgViews: 0, maxAvgViews: 0, niche: settings.niches[0] ?? "Coach" });
  const [preset, setPreset] = useState<Preset>("none");
  const [confirm, setConfirm] = useState<null | { pages: number; token?: string }>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const [results, setResults] = useState<ChannelData[]>([]);
  const [nextToken, setNextToken] = useState<string | undefined>();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulk, setBulk] = useState("");
  const [showBulk, setShowBulk] = useState(false);
  const [listName, setListName] = useState("");
  const [showList, setShowList] = useState(false);

  const ignored = useLiveQuery(() => db.ignored.toArray(), []);
  const leads = useLiveQuery(() => db.leads.toArray(), []);
  const ignoredSet = useMemo(() => new Set(ignored?.map((i) => i.channelId)), [ignored]);
  const leadSet = useMemo(() => new Set(leads?.map((l) => l.channelId)), [leads]);

  const applyPreset = (p: Preset) => {
    setPreset(p);
    if (p === "gems") setF((s) => ({ ...s, minSubs: 1000, maxSubs: 50000, lastUploadDays: 30 }));
    if (p === "business") setF((s) => ({ ...s, minSubs: 1000, maxSubs: 100000 }));
    if (p === "deep") setF((s) => ({ ...s, lastUploadDays: 60 }));
  };

  /** Pure post-processing: filter + enrich (recent videos) + score. */
  const processChannels = async (chans: ChannelData[]) => {
    const filtered = chans.filter((c) => c.subs >= f.minSubs && c.subs <= f.maxSubs && c.videoCount >= f.minVideos && !ignoredSet.has(c.channelId));
    const toEnrich = filtered.slice(0, MAX_ENRICH);
    const out: ChannelData[] = [];
    for (const c of toEnrich) {
      setLoading(`Fetching recent uploads… (${out.length + 1}/${toEnrich.length})`);
      try {
        const vids = await getRecentVideos(c.channelId, 10);
        out.push(enrichWithVideos(c, vids));
      } catch {
        out.push(c);
      }
    }
    out.push(...filtered.slice(MAX_ENRICH));
    return out.filter((c) => {
      if (c.lastUpload && (Date.now() - +new Date(c.lastUpload)) / 86400000 > f.lastUploadDays && (Date.now() - +new Date(c.lastUpload)) / 86400000 <= 180) return false;
      if (f.minAvgViews && (c.avgViews ?? 0) < f.minAvgViews) return false;
      if (f.maxAvgViews && (c.avgViews ?? 0) > f.maxAvgViews) return false;
      if (preset === "gems" && c.viewsToSubRatio !== undefined && c.viewsToSubRatio > 0.2) return false;
      if (preset === "business" && !(c.businessSignals ?? []).length) return false;
      return true;
    });
  };

  const runSearch = async (pages: number, startToken?: string) => {
    setConfirm(null);
    setLoading("Searching channels…");
    try {
      let token = startToken;
      let ids: string[] = [];
      for (let p = 0; p < pages; p++) {
        const res = await searchChannels({ q: f.q, pageToken: token, regionCode: f.country || undefined, relevanceLanguage: f.language || undefined });
        token = res.nextPageToken;
        // Deep discovery: skip page 1 (top-ranked, over-contacted channels)
        if (!(preset === "deep" && p === 0 && !startToken)) ids = ids.concat(res.channelIds);
        if (!token) break;
      }
      setNextToken(token);
      setLoading("Fetching channel stats…");
      const chans = await getChannels(ids);
      const processed = await processChannels(chans);
      setResults((r) => (startToken ? [...r, ...processed] : processed));
      toast(`${processed.length} channels match your filters`);
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setLoading(null);
    }
  };

  const addByUrls = async (text: string) => {
    const lines = text.split(/\n|,|\s+/).map((s) => s.trim()).filter(Boolean);
    if (!lines.length) return;
    setLoading(`Resolving ${lines.length} channel(s)…`);
    try {
      const ids: string[] = [];
      const others: string[] = [];
      lines.forEach((l) => {
        const p = parseChannelInput(l);
        if (p?.kind === "id") ids.push(p.value);
        else others.push(l);
      });
      const chans = ids.length ? await getChannels(ids) : [];
      for (const o of others) {
        const c = await resolveChannel(o).catch(() => null);
        if (c) chans.push(c);
      }
      const enriched: ChannelData[] = [];
      for (const c of chans) {
        const vids = await getRecentVideos(c.channelId, 10).catch(() => []);
        enriched.push(enrichWithVideos(c, vids));
      }
      setResults((r) => [...enriched, ...r.filter((x) => !enriched.some((e) => e.channelId === x.channelId))]);
      setBulk("");
      setShowBulk(false);
      toast(`Resolved ${enriched.length} channel(s)`);
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setLoading(null);
    }
  };

  const scored = useMemo(
    () =>
      results.map((c) => ({
        c,
        score: scoreLead({ channel: c, niche: f.niche, weights: settings.weights, subRange: settings.subRange, targetNiches: settings.niches }),
        skip: skipReason(c),
      })),
    [results, settings, f.niche]
  );

  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const selectedChannels = () => results.filter((c) => selected.has(c.channelId));

  const addToLeads = async () => {
    const chans = selectedChannels();
    for (const c of chans) await createLeadFromChannel(c, f.niche, f.q);
    toast(`${chans.length} lead(s) added`);
    setSelected(new Set());
  };
  const ignoreSelected = async () => {
    await db.ignored.bulkPut(Array.from(selected).map((channelId) => ({ channelId, at: nowIso() })));
    setResults((r) => r.filter((c) => !selected.has(c.channelId)));
    setSelected(new Set());
    toast("Ignored", "info");
  };
  const addToList = async () => {
    if (!listName.trim()) return;
    const existing = await db.lists.where("name").equals(listName.trim()).first();
    const ids = Array.from(selected);
    if (existing) await db.lists.update(existing.id!, { channelIds: Array.from(new Set([...existing.channelIds, ...ids])) });
    else await db.lists.add({ name: listName.trim(), channelIds: ids, createdAt: nowIso() });
    // Lists keep channel snapshots as leads too (so they're never lost); stage stays "Found".
    for (const c of selectedChannels()) await createLeadFromChannel(c, f.niche, f.q).then((l) => db.leads.update(l.id!, { tags: Array.from(new Set([...(l.tags ?? []), listName.trim()])) }));
    setShowList(false);
    setSelected(new Set());
    toast(`Added to list "${listName}"`);
  };

  const searchCost = (pages: number) => pages * COST.search + 1 + estimateEnrichCost(Math.min(MAX_ENRICH, 50 * pages));
  const helperQ = encodeURIComponent(f.q || f.niche);

  return (
    <div className="space-y-5">
      <PageHeader title="Channel Finder" description="Find 1K-100K sub business channels that are active and under-optimised. Skip 1M+ and dead channels automatically." action={<Button variant="outline" onClick={() => setShowBulk(true)}>Add by URL / @handle / bulk</Button>} />

      {!api && (
        <div className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm dark:border-amber-900 dark:bg-amber-950/30">
          <AlertTriangle className="mt-0.5 h-4 w-4 text-amber-500" />
          <div>
            <b>Manual Mode.</b> No YouTube API key set, so search is disabled. You can still add leads by hand (press <kbd className="kbd">N</kbd>), import CSV in Settings, and use the helper links below. <Link to="/settings" className="text-brand underline">Add a free API key</Link> to unlock search (takes 3 minutes).
          </div>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Search" description="search.list costs 100 units – use presets and filters to make each call count." className="lg:col-span-2">
          <div className="mb-3 flex flex-wrap gap-2">
            {([
              ["deep", "Page 2-5 discovery", Layers],
              ["gems", "Hidden gems", Gem],
              ["business", "Business channels", Briefcase],
            ] as const).map(([k, label, Icon]) => (
              <button key={k} onClick={() => applyPreset(preset === k ? "none" : k)} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs transition ${preset === k ? "border-brand bg-brand/10 text-brand" : "border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"}`}>
                <Icon className="h-3.5 w-3.5" /> {label}
              </button>
            ))}
            <span className="ml-auto inline-flex items-center gap-1 text-[11px] text-slate-500"><Info className="h-3 w-3" />{preset === "deep" ? "Skips page 1 (over-contacted top results)" : preset === "gems" ? "1K-50K subs, active, views/sub < 20%" : preset === "business" ? "Only channels with website/course/product/sponsor links" : "Pick a strategy preset"}</span>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Field label="Keyword / niche" className="col-span-2">
              <Input placeholder="e.g. business coach, real estate agent tips" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
            </Field>
            <Field label="Lead niche label">
              <Select value={f.niche} onChange={(e) => setF({ ...f, niche: e.target.value })}>{NICHES.map((n) => <option key={n}>{n}</option>)}</Select>
            </Field>
            <Field label="Last upload within (days)">
              <Input type="number" value={f.lastUploadDays} onChange={(e) => setF({ ...f, lastUploadDays: +e.target.value })} />
            </Field>
            <Field label="Min subs"><Input type="number" value={f.minSubs} onChange={(e) => setF({ ...f, minSubs: +e.target.value })} /></Field>
            <Field label="Max subs"><Input type="number" value={f.maxSubs} onChange={(e) => setF({ ...f, maxSubs: +e.target.value })} /></Field>
            <Field label="Country (ISO)"><Input placeholder="US, GB, BD…" maxLength={2} value={f.country} onChange={(e) => setF({ ...f, country: e.target.value.toUpperCase() })} /></Field>
            <Field label="Language (ISO)"><Input placeholder="en, bn…" maxLength={5} value={f.language} onChange={(e) => setF({ ...f, language: e.target.value })} /></Field>
            <Field label="Min video count"><Input type="number" value={f.minVideos} onChange={(e) => setF({ ...f, minVideos: +e.target.value })} /></Field>
            <Field label="Min avg views"><Input type="number" value={f.minAvgViews} onChange={(e) => setF({ ...f, minAvgViews: +e.target.value })} /></Field>
            <Field label="Max avg views (0 = any)"><Input type="number" value={f.maxAvgViews} onChange={(e) => setF({ ...f, maxAvgViews: +e.target.value })} /></Field>
            <div className="flex items-end">
              <Button className="w-full" disabled={!api || !f.q.trim() || !!loading} onClick={() => setConfirm({ pages: preset === "deep" ? 2 : 1 })}>
                <Search className="h-4 w-4" /> Search
              </Button>
            </div>
          </div>
        </Card>

        <Card title="Other ways to find leads" description="Free, zero-quota. Opens in a new tab.">
          <div className="space-y-2">
            {[
              ["YouTube search for the niche", `https://www.youtube.com/results?search_query=${helperQ}&sp=CAI%253D`],
              ["YouTube: niche + 'for beginners' (this month)", `https://www.youtube.com/results?search_query=${helperQ}+for+beginners&sp=EgIIBA%253D%253D`],
              ["Facebook groups search", `https://www.facebook.com/search/groups/?q=${helperQ}`],
              ["LinkedIn: people posting YouTube videos", `https://www.linkedin.com/search/results/content/?keywords=${helperQ}%20youtube`],
              ["Reddit: 'YouTube growth' questions", `https://www.reddit.com/search/?q=${encodeURIComponent((f.q || f.niche) + " youtube channel growth")}&sort=new`],
              ["Reddit r/NewTubers", `https://www.reddit.com/r/NewTubers/search/?q=${helperQ}&restrict_sr=1`],
              ["Google: niche + 'youtube channel' site:linkedin.com", `https://www.google.com/search?q=${helperQ}+%22youtube+channel%22+site%3Alinkedin.com%2Fin`],
            ].map(([label, href]) => (
              <a key={label} href={href} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-xs hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800">
                {label} <ExternalLink className="h-3 w-3 text-slate-400" />
              </a>
            ))}
          </div>
          <p className="mt-3 text-[11px] text-slate-500">Found a channel? Paste its URL via "Add by URL" (3 units) or add it manually (0 units).</p>
        </Card>
      </div>

      {/* Results */}
      <Card
        title={`Results (${scored.length})`}
        description="Auto-flags Skip for 1M+ subs or no upload in 180 days. Select rows for bulk actions."
        action={
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="ghost" onClick={() => setSelected(new Set(scored.filter((s) => !s.skip).map((s) => s.c.channelId)))}>Select all good</Button>
            <Button size="sm" disabled={!selected.size} onClick={addToLeads}>Add to leads ({selected.size})</Button>
            <Button size="sm" variant="outline" disabled={!selected.size} onClick={() => setShowList(true)}>Add to list</Button>
            <Button size="sm" variant="outline" disabled={!selected.size} onClick={ignoreSelected}>Ignore</Button>
            {nextToken && api && <Button size="sm" variant="secondary" onClick={() => setConfirm({ pages: 1, token: nextToken })}>Next page (100 units)</Button>}
          </div>
        }
      >
        {loading ? (
          <div className="space-y-2">
            <p className="text-xs text-slate-500">{loading}</p>
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10" />)}
          </div>
        ) : !scored.length ? (
          <EmptyState icon={<Search className="h-8 w-8" />} title="No results yet" hint={api ? "Try 'business coach', 'shopify tips', 'real estate agent' or 'online course'. Use a preset to dig past page 1." : "Add channels by URL (needs key) or press N to add leads manually."} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-slate-500">
                <tr className="border-b border-slate-200 dark:border-slate-800">
                  <th className="p-2"></th><th className="p-2">Channel</th><th className="p-2">Subs</th><th className="p-2">Total views</th><th className="p-2">Avg views (10)</th><th className="p-2">Views/sub</th><th className="p-2">Uploads/mo</th><th className="p-2">Last upload</th><th className="p-2">Score</th><th className="p-2">Signals</th>
                </tr>
              </thead>
              <tbody>
                {scored.map(({ c, score, skip }) => (
                  <tr key={c.channelId} className={`border-b border-slate-100 dark:border-slate-800/60 ${skip ? "opacity-50" : ""}`}>
                    <td className="p-2"><Checkbox checked={selected.has(c.channelId)} onChange={() => toggle(c.channelId)} /></td>
                    <td className="p-2">
                      <div className="flex items-center gap-2">
                        {c.avatar ? <img src={c.avatar} className="h-8 w-8 rounded-full" alt="" /> : <div className="h-8 w-8 rounded-full bg-slate-200 dark:bg-slate-700" />}
                        <div className="min-w-0">
                          <a href={`https://www.youtube.com/channel/${c.channelId}`} target="_blank" rel="noreferrer" className="block max-w-[180px] truncate font-medium hover:underline">{c.name}</a>
                          <div className="text-[10px] text-slate-500">{c.handle} {c.country && `· ${c.country}`}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-2">{fmt(c.subs)}</td>
                    <td className="p-2">{fmt(c.totalViews)}</td>
                    <td className="p-2">{fmt(c.avgViews)}</td>
                    <td className="p-2">{c.viewsToSubRatio !== undefined ? `${Math.round(c.viewsToSubRatio * 100)}%` : "–"}</td>
                    <td className="p-2">{c.uploadsPerMonth ?? "–"}</td>
                    <td className="p-2 whitespace-nowrap">{c.lastUpload ? formatDistanceToNow(new Date(c.lastUpload), { addSuffix: true }).replace("about ", "") : "–"}</td>
                    <td className="p-2">{skip ? <Badge color="slate">Skip · {skip}</Badge> : leadSet.has(c.channelId) ? <Badge color="green">Lead ✓</Badge> : <ScoreBadge score={score.score} label={score.label} />}</td>
                    <td className="p-2"><div className="flex max-w-[140px] flex-wrap gap-1">{(c.businessSignals ?? []).slice(0, 3).map((s) => <Badge key={s}>{s}</Badge>)}</div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Confirm search cost */}
      <Dialog open={!!confirm} onClose={() => setConfirm(null)} title="Confirm API cost" footer={<><Button variant="outline" onClick={() => setConfirm(null)}>Cancel</Button><Button onClick={() => confirm && runSearch(confirm.pages, confirm.token)}>Run search</Button></>}>
        {confirm && (
          <div className="space-y-2 text-sm">
            <p>This will call <code>search.list</code> {confirm.pages}× (<b>{confirm.pages * COST.search} units</b>){preset === "deep" && !confirm.token ? " – page 1 is fetched only for its page token and skipped." : ""}</p>
            <p>Then <code>channels.list</code> in batches of 50 (1 unit each) and recent uploads for up to {MAX_ENRICH} matching channels (~2 units each, cached 24h).</p>
            <p className="rounded-lg bg-slate-100 p-2 text-xs dark:bg-slate-800">Estimated maximum: <b>~{searchCost(confirm.pages)} units</b> of your 10,000 daily quota.</p>
          </div>
        )}
      </Dialog>

      {/* Bulk add */}
      <Dialog open={showBulk} onClose={() => setShowBulk(false)} title="Add by URL / @handle / channel ID" footer={<Button disabled={!api || !bulk.trim()} onClick={() => addByUrls(bulk)}>Resolve & add to results</Button>}>
        <Field label="One per line (URLs, @handles, UC… IDs, or video URLs)" hint="Resolved via channels.list (forHandle / id) + uploads playlist. ~3 units per channel.">
          <Textarea className="min-h-[160px] font-mono text-xs" placeholder={"https://youtube.com/@creator\n@anothercreator\nUCxxxxxxxxxxxxxxxxxxxxxx"} value={bulk} onChange={(e) => setBulk(e.target.value)} />
        </Field>
        {!api && <p className="mt-2 text-xs text-amber-600">Needs an API key. In Manual Mode press N to add leads by hand.</p>}
      </Dialog>

      <Dialog open={showList} onClose={() => setShowList(false)} title="Add to list" footer={<Button onClick={addToList}>Save</Button>}>
        <Field label="List name (saved as a tag on the lead)"><Input value={listName} onChange={(e) => setListName(e.target.value)} placeholder="e.g. Coaches – batch 1" /></Field>
      </Dialog>
    </div>
  );
}
