import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Download, Upload, Trash2, KeyRound, ExternalLink, Eye, EyeOff } from "lucide-react";
import { useSettings, resetSettings, type Weights } from "@/lib/settings";
import { WEIGHT_LABELS } from "@/lib/scoring";
import { rescoreAll } from "@/lib/leads";
import { deleteAllData, exportBackup, importBackup, importLeadsCsv, leadsToCsv, downloadFile } from "@/lib/backup";
import { db, purgeExpiredCache } from "@/lib/db";
import { NICHES, SERVICES } from "@/lib/types";
import { PageHeader, QuotaMeter } from "@/components/Layout";
import { Button, Card, Checkbox, Field, Input, Select, Textarea } from "@/components/ui";
import { useToast } from "@/components/toast";

export default function SettingsPage() {
  const [s, save] = useSettings();
  const { toast } = useToast();
  const [showKey, setShowKey] = useState(false);
  const backupRef = useRef<HTMLInputElement>(null);
  const csvRef = useRef<HTMLInputElement>(null);

  const onLogo = (file: File) => {
    if (file.size > 500_000) return toast("Logo must be under 500 KB", "warning");
    const r = new FileReader();
    r.onload = () => save({ profile: { ...s.profile, logo: String(r.result) } });
    r.readAsDataURL(file);
  };
  const readFile = (file: File) => new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = rej; r.readAsText(file); });

  const weightTotal = Object.values(s.weights).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-5">
      <PageHeader title="Settings" description="Everything is stored in this browser (localStorage + IndexedDB). Back up regularly." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Profile & branding" description="Used in reports, proposals and {my_name} / {portfolio_link} / {calendar_link} variables.">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Your name"><Input value={s.profile.name} onChange={(e) => save({ profile: { ...s.profile, name: e.target.value } })} /></Field>
            <Field label="Tagline"><Input value={s.profile.tagline} onChange={(e) => save({ profile: { ...s.profile, tagline: e.target.value } })} /></Field>
            <Field label="Portfolio link"><Input placeholder="https://" value={s.profile.portfolioLink} onChange={(e) => save({ profile: { ...s.profile, portfolioLink: e.target.value } })} /></Field>
            <Field label="Calendar link"><Input placeholder="https://cal.com/…" value={s.profile.calendarLink} onChange={(e) => save({ profile: { ...s.profile, calendarLink: e.target.value } })} /></Field>
            <Field label="Accent colour"><div className="flex items-center gap-2"><input type="color" value={s.profile.accentColor} onChange={(e) => save({ profile: { ...s.profile, accentColor: e.target.value } })} className="h-9 w-12 cursor-pointer rounded border-0 bg-transparent" /><Input value={s.profile.accentColor} onChange={(e) => save({ profile: { ...s.profile, accentColor: e.target.value } })} /></div></Field>
            <Field label="Theme"><Select value={s.theme} onChange={(e) => save({ theme: e.target.value as typeof s.theme })}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></Select></Field>
            <Field label="Logo (base64, < 500 KB)" className="col-span-2">
              <div className="flex items-center gap-3">{s.profile.logo && <img src={s.profile.logo} className="h-10 w-10 rounded-lg object-cover" alt="" />}<input type="file" accept="image/*" className="text-xs" onChange={(e) => e.target.files?.[0] && onLogo(e.target.files[0])} />{s.profile.logo && <Button size="sm" variant="ghost" onClick={() => save({ profile: { ...s.profile, logo: "" } })}>Remove</Button>}</div>
            </Field>
          </div>
        </Card>

        <Card title="YouTube Data API v3 key" description="Your own free key. Stored only in this browser's localStorage and sent only to googleapis.com.">
          <div className="flex gap-2">
            <Input type={showKey ? "text" : "password"} placeholder="AIza…" value={s.apiKey} onChange={(e) => save({ apiKey: e.target.value.trim() })} />
            <Button variant="outline" size="icon" onClick={() => setShowKey((v) => !v)}>{showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</Button>
          </div>
          <details className="mt-3 rounded-lg bg-slate-50 p-3 text-xs dark:bg-slate-800" open={!s.apiKey}>
            <summary className="cursor-pointer font-medium"><KeyRound className="mr-1 inline h-3.5 w-3.5" /> How to get a free key (3 minutes)</summary>
            <ol className="mt-2 list-inside list-decimal space-y-1 text-slate-600 dark:text-slate-300">
              <li>Open <a className="text-brand underline" href="https://console.cloud.google.com/" target="_blank" rel="noreferrer">Google Cloud Console <ExternalLink className="inline h-3 w-3" /></a> and create a project (any name).</li>
              <li>Go to <b>APIs & Services → Library</b>, search <b>YouTube Data API v3</b> → <b>Enable</b>.</li>
              <li>Go to <b>APIs & Services → Credentials → Create credentials → API key</b>. Copy it here.</li>
              <li>Click <b>Edit API key</b> → Application restrictions: <b>HTTP referrers</b> → add your deployed site (e.g. <code>https://yourname.netlify.app/*</code>) and <code>http://localhost:5173/*</code> for dev. API restrictions: restrict to <b>YouTube Data API v3</b>.</li>
              <li>Free quota: <b>10,000 units/day</b>, resets at midnight Pacific time. No billing needed.</li>
            </ol>
          </details>
          <div className="mt-3"><QuotaMeter compact /></div>
          <div className="mt-2 flex gap-2 text-[11px] text-slate-500"><span>Costs: search 100 · channels/videos/playlistItems 1. Responses cached 24h.</span><button className="ml-auto underline" onClick={() => purgeExpiredCache().then(() => db.cache.clear()).then(() => toast("API cache cleared", "info"))}>Clear cache</button></div>
        </Card>

        <Card title="Targeting defaults" description="Used by the Channel Finder, scoring and onboarding.">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Min subscribers"><Input type="number" value={s.subRange.min} onChange={(e) => save({ subRange: { ...s.subRange, min: +e.target.value } })} /></Field>
            <Field label="Max subscribers"><Input type="number" value={s.subRange.max} onChange={(e) => save({ subRange: { ...s.subRange, max: +e.target.value } })} /></Field>
            <div className="col-span-2"><div className="mb-1 text-xs font-medium">Services you sell</div><div className="flex flex-wrap gap-x-4 gap-y-1">{SERVICES.map((x) => <Checkbox key={x} checked={s.services.includes(x)} onChange={(v) => save({ services: v ? [...s.services, x] : s.services.filter((y) => y !== x) })} label={x} />)}</div></div>
            <div className="col-span-2"><div className="mb-1 text-xs font-medium">Target niches</div><div className="flex flex-wrap gap-x-4 gap-y-1">{NICHES.map((x) => <Checkbox key={x} checked={s.niches.includes(x)} onChange={(v) => save({ niches: v ? [...s.niches, x] : s.niches.filter((y) => y !== x) })} label={x} />)}</div></div>
            <Field label="Default language"><Select value={s.defaultLanguage} onChange={(e) => save({ defaultLanguage: e.target.value as typeof s.defaultLanguage })}><option>English</option><option>Bangla</option><option>Banglish</option></Select></Field>
            <Field label="Default tone"><Select value={s.defaultTone} onChange={(e) => save({ defaultTone: e.target.value as typeof s.defaultTone })}><option>Friendly</option><option>Professional</option><option>Direct</option></Select></Field>
            <Field label="Max words per message"><Input type="number" value={s.maxWords} onChange={(e) => save({ maxWords: +e.target.value || 90 })} /></Field>
            <Field label="Follow-up days (comma separated)"><Input value={s.followUpDays.join(", ")} onChange={(e) => save({ followUpDays: e.target.value.split(",").map((x) => +x.trim()).filter((x) => x > 0) })} /></Field>
          </div>
        </Card>

        <Card title="Lead scoring weights" description={`Hot 75+ · Warm 50-74 · Cold <50. Total weight: ${weightTotal}`} action={<Button size="sm" variant="outline" onClick={() => rescoreAll().then(() => toast("All leads re-scored"))}>Re-score all</Button>}>
          <div className="space-y-2">
            {(Object.keys(WEIGHT_LABELS) as (keyof Weights)[]).map((k) => (
              <div key={k} className="grid grid-cols-[1fr_auto_auto] items-center gap-3 text-xs">
                <span>{WEIGHT_LABELS[k]}</span>
                <input type="range" min={0} max={40} value={s.weights[k]} onChange={(e) => save({ weights: { ...s.weights, [k]: +e.target.value } })} className="w-32 accent-[var(--brand)]" />
                <span className="w-6 text-right font-semibold">{s.weights[k]}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Weekly goals">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Channels found"><Input type="number" value={s.weeklyGoals.found} onChange={(e) => save({ weeklyGoals: { ...s.weeklyGoals, found: +e.target.value } })} /></Field>
            <Field label="Audits"><Input type="number" value={s.weeklyGoals.audits} onChange={(e) => save({ weeklyGoals: { ...s.weeklyGoals, audits: +e.target.value } })} /></Field>
            <Field label="Messages"><Input type="number" value={s.weeklyGoals.messages} onChange={(e) => save({ weeklyGoals: { ...s.weeklyGoals, messages: +e.target.value } })} /></Field>
            <Field label="Content posts"><Input type="number" value={s.weeklyGoals.posts} onChange={(e) => save({ weeklyGoals: { ...s.weeklyGoals, posts: +e.target.value } })} /></Field>
          </div>
          <p className="mt-3 text-xs text-slate-500">Templates and packages are edited in <Link className="text-brand underline" to="/outreach">Outreach Studio → Template library</Link> and <Link className="text-brand underline" to="/proposals">Proposals → Packages</Link>.</p>
        </Card>

        <Card title="Do-not-contact list" description="Channel names or IDs, one per line. New leads matching these are flagged automatically.">
          <Textarea className="min-h-[120px] font-mono text-xs" value={s.doNotContactList.join("\n")} onChange={(e) => save({ doNotContactList: e.target.value.split("\n").map((x) => x.trim()).filter(Boolean) })} />
        </Card>

        <Card title="Backup & data" description="Export everything (leads, audits, messages, templates, settings) as JSON. Import restores it on any device." className="lg:col-span-2">
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => exportBackup().then(() => toast("Backup downloaded"))}><Download className="h-4 w-4" /> Export backup (JSON)</Button>
            <Button variant="outline" onClick={() => backupRef.current?.click()}><Upload className="h-4 w-4" /> Restore backup</Button>
            <input ref={backupRef} type="file" accept="application/json" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const mode = confirm("Replace all current data with the backup? (Cancel = merge)") ? "replace" : "merge"; await importBackup(await readFile(f), mode); toast("Backup restored"); } catch (err) { toast((err as Error).message, "error"); } e.target.value = ""; }} />
            <Button variant="outline" onClick={async () => downloadFile("channelhunter-leads.csv", leadsToCsv(await db.leads.toArray()), "text/csv")}><Download className="h-4 w-4" /> Export leads CSV</Button>
            <Button variant="outline" onClick={() => csvRef.current?.click()}><Upload className="h-4 w-4" /> Import leads CSV</Button>
            <input ref={csvRef} type="file" accept=".csv,text/csv" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const n = await importLeadsCsv(await readFile(f)); toast(`Imported ${n} lead(s)`); } catch (err) { toast((err as Error).message, "error"); } e.target.value = ""; }} />
            <Button variant="danger" className="ml-auto" onClick={async () => { if (confirm("Delete ALL data in this browser? This cannot be undone.") && confirm("Really delete everything? Export a backup first!")) { await deleteAllData(); resetSettings(); window.location.reload(); } }}><Trash2 className="h-4 w-4" /> Delete all data</Button>
          </div>
          <p className="mt-3 text-[11px] text-slate-500">CSV import columns: <code>name, channel_url, subs, niche, email, website, notes, avg_views, last_upload</code>. Only <code>name</code> is required.</p>
        </Card>
      </div>
    </div>
  );
}
