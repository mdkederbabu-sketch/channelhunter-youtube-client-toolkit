import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { useSearchParams } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { Download, Users, Mail, Globe, Link2 } from "lucide-react";
import { db } from "@/lib/db";
import { leadsToCsv, downloadFile } from "@/lib/backup";
import { NICHES, STAGES, type Lead } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Badge, Button, Card, EmptyState, Input, ScoreBadge, Select, Skeleton, Tabs, fmt } from "@/components/ui";
import { LeadDrawer } from "@/components/LeadDrawer";

type View = "leads" | "contacts";

export default function LeadsPage() {
  const [params, setParams] = useSearchParams();
  const leads = useLiveQuery(() => db.leads.orderBy("updatedAt").reverse().toArray(), []);
  const [q, setQ] = useState(params.get("q") ?? "");
  const [stage, setStage] = useState("");
  const [niche, setNiche] = useState("");
  const [label, setLabel] = useState("");
  const [contactFilter, setContactFilter] = useState("");
  const [view, setView] = useState<View>("leads");
  const [openId, setOpenId] = useState<number | null>(params.get("open") ? Number(params.get("open")) : null);

  useEffect(() => {
    const qq = params.get("q");
    if (qq !== null) setQ(qq);
    const o = params.get("open");
    if (o) setOpenId(Number(o));
  }, [params]);

  const filtered = useMemo(() => {
    if (!leads) return [];
    const s = q.trim().toLowerCase();
    return leads.filter((l) => {
      if (s && !`${l.name} ${l.handle ?? ""} ${l.niche} ${l.tags.join(" ")} ${l.notes} ${l.contact.email} ${l.contact.website}`.toLowerCase().includes(s)) return false;
      if (stage && l.stage !== stage) return false;
      if (niche && l.niche !== niche) return false;
      if (label && l.scoreLabel !== label) return false;
      if (contactFilter === "found" && !l.contact.found) return false;
      if (contactFilter === "missing" && l.contact.found) return false;
      if (contactFilter === "dnc" && !l.doNotContact) return false;
      return true;
    });
  }, [leads, q, stage, niche, label, contactFilter]);

  const close = () => {
    setOpenId(null);
    if (params.get("open")) {
      params.delete("open");
      setParams(params, { replace: true });
    }
  };

  if (!leads) return <Skeleton className="h-64" />;

  return (
    <div className="space-y-4">
      <PageHeader title="Leads & Contacts" description={`${leads.length} leads · contact info is collected manually from public business-inquiry sources only.`} action={<Button variant="outline" onClick={() => downloadFile(`channelhunter-leads-${new Date().toISOString().slice(0, 10)}.csv`, leadsToCsv(filtered), "text/csv")}><Download className="h-4 w-4" /> Export CSV ({filtered.length})</Button>} />

      <Card>
        <div className="flex flex-wrap items-center gap-2">
          <Tabs value={view} onChange={setView} tabs={[{ value: "leads", label: "Leads" }, { value: "contacts", label: "Contacts" }]} />
          <Input className="w-56" placeholder="Search name, tag, note…" value={q} onChange={(e) => setQ(e.target.value)} />
          <Select className="w-36" value={stage} onChange={(e) => setStage(e.target.value)}><option value="">All stages</option>{STAGES.map((s) => <option key={s}>{s}</option>)}</Select>
          <Select className="w-36" value={niche} onChange={(e) => setNiche(e.target.value)}><option value="">All niches</option>{NICHES.map((s) => <option key={s}>{s}</option>)}</Select>
          <Select className="w-28" value={label} onChange={(e) => setLabel(e.target.value)}><option value="">All scores</option><option>Hot</option><option>Warm</option><option>Cold</option></Select>
          <Select className="w-40" value={contactFilter} onChange={(e) => setContactFilter(e.target.value)}><option value="">Any contact</option><option value="found">Contact found</option><option value="missing">Contact missing</option><option value="dnc">Do not contact</option></Select>
        </div>
      </Card>

      {!filtered.length ? (
        <EmptyState icon={<Users className="h-8 w-8" />} title={leads.length ? "No leads match these filters" : "No leads yet"} hint={leads.length ? "Try clearing a filter." : "Use the Channel Finder, press N to add one manually, or import a CSV from Settings."} />
      ) : (
        <Card className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 dark:bg-slate-800/60">
                {view === "leads" ? (
                  <tr><th className="p-3">Channel</th><th className="p-3">Niche</th><th className="p-3">Subs</th><th className="p-3">Avg views</th><th className="p-3">Views/sub</th><th className="p-3">Score</th><th className="p-3">Stage</th><th className="p-3">Next follow-up</th><th className="p-3">Updated</th></tr>
                ) : (
                  <tr><th className="p-3">Channel</th><th className="p-3">Found?</th><th className="p-3">Email</th><th className="p-3">Website</th><th className="p-3">LinkedIn</th><th className="p-3">Socials</th><th className="p-3">Source</th><th className="p-3">Flags</th></tr>
                )}
              </thead>
              <tbody>
                {filtered.map((l) => (
                  <tr key={l.id} onClick={() => setOpenId(l.id!)} className="cursor-pointer border-t border-slate-100 hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/40">
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        {l.avatar ? <img src={l.avatar} className="h-7 w-7 rounded-full" alt="" /> : <div className="flex h-7 w-7 items-center justify-center rounded-full bg-brand/10 text-[10px] font-bold text-brand">{l.name.slice(0, 2).toUpperCase()}</div>}
                        <div className="min-w-0"><div className="max-w-[200px] truncate font-medium">{l.name}</div><div className="flex gap-1">{l.tags.slice(0, 2).map((t) => <Badge key={t}>{t}</Badge>)}</div></div>
                      </div>
                    </td>
                    {view === "leads" ? (
                      <>
                        <td className="p-3">{l.niche}</td>
                        <td className="p-3">{fmt(l.subs)}</td>
                        <td className="p-3">{fmt(l.avgViews)}</td>
                        <td className="p-3">{l.viewsToSubRatio !== undefined ? `${Math.round(l.viewsToSubRatio * 100)}%` : "–"}</td>
                        <td className="p-3"><ScoreBadge score={l.score} label={l.scoreLabel} /></td>
                        <td className="p-3"><Badge color={l.stage === "Won" ? "green" : l.stage === "Lost" ? "red" : "slate"}>{l.stage}</Badge></td>
                        <td className="p-3 whitespace-nowrap">{l.nextFollowUpAt ? formatDistanceToNow(new Date(l.nextFollowUpAt), { addSuffix: true }) : "–"}</td>
                        <td className="p-3 whitespace-nowrap text-slate-500">{formatDistanceToNow(new Date(l.updatedAt), { addSuffix: true }).replace("about ", "")}</td>
                      </>
                    ) : (
                      <>
                        <td className="p-3">{l.contact.found ? <Badge color="green">Yes</Badge> : <Badge>No</Badge>}</td>
                        <td className="p-3">{l.contact.email ? <span className="inline-flex items-center gap-1"><Mail className="h-3 w-3" />{l.contact.email}</span> : "–"}</td>
                        <td className="p-3">{l.contact.website ? <span className="inline-flex items-center gap-1"><Globe className="h-3 w-3" />{l.contact.website.replace(/^https?:\/\//, "").slice(0, 28)}</span> : "–"}</td>
                        <td className="p-3">{l.contact.linkedin ? <Link2 className="h-3.5 w-3.5 text-sky-600" /> : "–"}</td>
                        <td className="p-3">{[l.contact.instagram && "IG", l.contact.x && "X", l.contact.facebook && "FB", l.contact.whatsapp && "WA"].filter(Boolean).join(" · ") || "–"}</td>
                        <td className="p-3">{l.contact.source || "–"}</td>
                        <td className="p-3">{l.doNotContact && <Badge color="red">DNC</Badge>}</td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <LeadDrawer leadId={openId} onClose={close} />
    </div>
  );
}

export type { Lead };
