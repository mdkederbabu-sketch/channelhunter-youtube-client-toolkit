import { useLiveQuery } from "dexie-react-hooks";
import { Link } from "react-router-dom";
import { endOfDay, format, startOfWeek, subDays } from "date-fns";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Users, ClipboardCheck, Send, MessageCircle, Phone, Trophy, Percent, TrendingUp, CheckCircle2 } from "lucide-react";
import { db, logActivity } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { stageIndex } from "@/lib/types";
import { completeTask } from "@/lib/leads";
import { PageHeader, QuotaMeter } from "@/components/Layout";
import { Button, Card, EmptyState, Input, Progress, Skeleton, Stat } from "@/components/ui";
import { useToast } from "@/components/toast";

export default function Dashboard() {
  const [settings, save] = useSettings();
  const { toast } = useToast();
  const leads = useLiveQuery(() => db.leads.toArray(), []);
  const activities = useLiveQuery(() => db.activities.where("at").above(subDays(new Date(), 60).toISOString()).toArray(), []);
  const tasks = useLiveQuery(() => db.tasks.filter((t) => !t.done && t.dueAt <= endOfDay(new Date()).toISOString()).sortBy("dueAt"), []);
  const pendingTasks = useLiveQuery(() => db.tasks.filter((t) => !t.done).count(), []);

  if (!leads || !activities) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-20" />)}
      </div>
    );
  }

  const count = (minStage: number) => leads.filter((l) => stageIndex(l.stage) >= minStage && l.stage !== "Lost").length;
  const found = leads.length;
  const audited = leads.filter((l) => l.latestAuditId).length;
  const contacted = count(2);
  const replied = count(3);
  const calls = count(4);
  const won = leads.filter((l) => l.stage === "Won").length;
  const replyRate = contacted ? Math.round((replied / contacted) * 100) : 0;
  const conversion = contacted ? Math.round((won / contacted) * 100) : 0;

  // Weekly chart (last 7 days)
  const days = Array.from({ length: 7 }, (_, i) => subDays(new Date(), 6 - i));
  const chart = days.map((d) => {
    const key = format(d, "yyyy-MM-dd");
    const acts = activities.filter((a) => a.at.slice(0, 10) === key);
    return {
      day: format(d, "EEE"),
      Found: acts.filter((a) => a.type === "found").length,
      Audits: acts.filter((a) => a.type === "audited").length,
      Messages: acts.filter((a) => a.type === "contacted").length,
      "Follow-ups": acts.filter((a) => a.type === "followup").length,
    };
  });

  // Weekly goals (week starts Monday)
  const ws = startOfWeek(new Date(), { weekStartsOn: 1 }).toISOString();
  const week = activities.filter((a) => a.at >= ws);
  const g = settings.weeklyGoals;
  const goals = [
    { key: "found", label: "Channels found", value: week.filter((a) => a.type === "found").length, target: g.found },
    { key: "audits", label: "Audits", value: week.filter((a) => a.type === "audited").length, target: g.audits },
    { key: "messages", label: "Messages sent", value: week.filter((a) => a.type === "contacted").length, target: g.messages },
    { key: "followups", label: "Follow-ups pending", value: pendingTasks ?? 0, target: 0 },
    { key: "posts", label: "Content posts", value: week.filter((a) => a.type === "post").length, target: g.posts },
  ] as const;

  return (
    <div className="space-y-6">
      <PageHeader title={`Good ${new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening"}${settings.profile.name ? ", " + settings.profile.name.split(" ")[0] : ""}`} description="Your client-hunting command centre. Everything here is stored only in this browser." action={<Link to="/finder"><Button>Find channels</Button></Link>} />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Leads found" value={found} icon={<Users className="h-5 w-5" />} />
        <Stat label="Audited" value={audited} icon={<ClipboardCheck className="h-5 w-5" />} />
        <Stat label="Contacted" value={contacted} icon={<Send className="h-5 w-5" />} />
        <Stat label="Replied" value={replied} icon={<MessageCircle className="h-5 w-5" />} />
        <Stat label="Calls booked" value={calls} icon={<Phone className="h-5 w-5" />} />
        <Stat label="Clients won" value={won} icon={<Trophy className="h-5 w-5" />} />
        <Stat label="Reply rate" value={`${replyRate}%`} sub="replied / contacted" icon={<Percent className="h-5 w-5" />} />
        <Stat label="Conversion" value={`${conversion}%`} sub="won / contacted" icon={<TrendingUp className="h-5 w-5" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Weekly activity" description="Last 7 days" className="lg:col-span-2">
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} barSize={10}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-slate-200 dark:text-slate-800" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={28} />
                <Tooltip contentStyle={{ borderRadius: 10, fontSize: 12 }} />
                <Bar dataKey="Found" fill="var(--brand)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="Audits" fill="#10b981" radius={[3, 3, 0, 0]} />
                <Bar dataKey="Messages" fill="#f59e0b" radius={[3, 3, 0, 0]} />
                <Bar dataKey="Follow-ups" fill="#64748b" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Today's tasks" description="Follow-ups due or overdue" action={<Link to="/followups" className="text-xs text-brand hover:underline">Inbox</Link>}>
          {!tasks?.length ? (
            <EmptyState title="All clear" hint="Follow-ups appear here automatically when you mark a message as sent." />
          ) : (
            <ul className="space-y-2">
              {tasks.slice(0, 8).map((t) => (
                <li key={t.id} className="flex items-start gap-2 text-sm">
                  <button onClick={() => completeTask(t.id!).then(() => toast("Task done"))} className="mt-0.5 text-slate-400 hover:text-emerald-500" aria-label="Done"><CheckCircle2 className="h-4 w-4" /></button>
                  <div className="min-w-0 flex-1">
                    <Link to={`/followups`} className="block truncate hover:underline">{t.title}</Link>
                    <div className="text-[11px] text-slate-500">{format(new Date(t.dueAt), "d MMM")}{new Date(t.dueAt) < new Date(new Date().toDateString()) ? " · overdue" : ""}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Weekly goals" description="Week starts Monday · targets are editable" className="lg:col-span-2" action={<Button size="sm" variant="outline" onClick={async () => { await logActivity("post", "Published a content post"); toast("Content post logged"); }}>+ Log content post</Button>}>
          <div className="space-y-3">
            {goals.map((gl) => (
              <div key={gl.key} className="grid grid-cols-[1fr_auto] items-center gap-3 sm:grid-cols-[180px_1fr_auto]">
                <span className="text-sm">{gl.label}</span>
                <div className="col-span-2 sm:col-span-1">
                  {gl.key === "followups" ? (
                    <div className="text-xs text-slate-500">{gl.value} pending – target: all done on time</div>
                  ) : (
                    <Progress value={gl.target ? (gl.value / gl.target) * 100 : 0} color={gl.value >= gl.target ? "bg-emerald-500" : undefined} />
                  )}
                </div>
                <div className="flex items-center gap-1 text-xs">
                  <span className="font-semibold">{gl.value}</span>
                  {gl.key !== "followups" && (
                    <>
                      <span className="text-slate-400">/</span>
                      <Input type="number" className="h-7 w-16 px-2 py-0 text-xs" value={gl.target} onChange={(e) => save({ weeklyGoals: { ...g, [gl.key]: Number(e.target.value) || 0 } })} />
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
        <div className="space-y-4">
          <QuotaMeter />
          <Card title="Daily hunting routine">
            <ol className="list-inside list-decimal space-y-1 text-xs text-slate-600 dark:text-slate-300">
              <li>Find 5-10 channels (1K-100K subs, active)</li>
              <li>5-minute audit → collect proof</li>
              <li>Find contact (About tab, links, LinkedIn)</li>
              <li>Send personalised message</li>
              <li>Clear today's follow-ups</li>
              <li>Post 1 proof/content piece</li>
            </ol>
            <Link to="/routine" className="mt-3 inline-block text-xs text-brand hover:underline">Open routine checklist →</Link>
          </Card>
        </div>
      </div>
    </div>
  );
}
