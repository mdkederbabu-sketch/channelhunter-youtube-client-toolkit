import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { useSearchParams } from "react-router-dom";
import { Printer, Plus, Trash2, Copy, Image as ImageIcon } from "lucide-react";
import { db, logActivity, nowIso, setLeadStage } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { openPrintWindow, proposalHtml } from "@/lib/report";
import { DEFAULT_PACKAGES } from "@/lib/templates";
import { NICHES, type CaseStudy, type Package } from "@/lib/types";
import { PageHeader } from "@/components/Layout";
import { Button, Card, Checkbox, Field, Input, Select, Tabs, Textarea, Switch } from "@/components/ui";
import { copyText, useToast } from "@/components/toast";

type Tab = "proposal" | "packages" | "cases" | "proof";

export default function ProposalsPage() {
  const [params] = useSearchParams();
  const [settings] = useSettings();
  const [tab, setTab] = useState<Tab>("proposal");
  const leads = useLiveQuery(() => db.leads.orderBy("updatedAt").reverse().toArray(), []);
  const packages = useLiveQuery(() => db.packages.toArray(), []);
  const cases = useLiveQuery(() => db.caseStudies.orderBy("createdAt").reverse().toArray(), []);
  const [leadId, setLeadId] = useState(Number(params.get("lead")) || 0);
  const [pkgId, setPkgId] = useState(0);
  const [caseIds, setCaseIds] = useState<number[]>([]);
  const [notes, setNotes] = useState("");
  const lead = useLiveQuery(() => (leadId ? db.leads.get(leadId) : undefined), [leadId]);
  const audit = useLiveQuery(() => (lead?.latestAuditId ? db.audits.get(lead.latestAuditId) : undefined), [lead?.latestAuditId]);

  useEffect(() => {
    if (!pkgId && packages?.length) setPkgId(packages.find((p) => p.highlight)?.id ?? packages[0].id!);
  }, [packages, pkgId]);

  const generate = async () => {
    if (!lead || !packages) return;
    const pkg = packages.find((p) => p.id === pkgId) ?? packages[0];
    openPrintWindow(proposalHtml(lead, audit ?? null, packages, pkg, (cases ?? []).filter((c) => caseIds.includes(c.id!)), settings, notes));
    if (["Replied", "Call Booked"].includes(lead.stage)) await setLeadStage(lead.id!, "Proposal Sent");
    else await logActivity("proposal", `Generated proposal (${pkg.name})`, lead.id);
  };

  return (
    <div className="space-y-5">
      <PageHeader title="Proposal & Pricing" description="Package builder, one-click proposals filled with audit data, and a case-study library for proof." />
      <Tabs value={tab} onChange={setTab} tabs={[{ value: "proposal", label: "Proposal generator" }, { value: "packages", label: "Packages" }, { value: "cases", label: `Case studies (${cases?.length ?? 0})` }, { value: "proof", label: "Proof checklist" }]} />

      {tab === "proposal" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title="Build proposal" className="space-y-3 lg:col-span-1">
            <Field label="Lead"><Select value={leadId} onChange={(e) => setLeadId(Number(e.target.value))}><option value={0}>Select lead…</option>{leads?.map((l) => <option key={l.id} value={l.id}>{l.name} · {l.stage}</option>)}</Select></Field>
            <Field label="Recommended package"><Select value={pkgId} onChange={(e) => setPkgId(Number(e.target.value))}>{packages?.map((p) => <option key={p.id} value={p.id}>{p.name} – ${p.price} {p.period}</option>)}</Select></Field>
            <div>
              <div className="mb-1 text-xs font-medium">Include case studies</div>
              <div className="space-y-1">{cases?.map((c) => <Checkbox key={c.id} checked={caseIds.includes(c.id!)} onChange={(v) => setCaseIds((s) => (v ? [...s, c.id!] : s.filter((x) => x !== c.id)))} label={`${c.client} (${c.niche})`} />)}{!cases?.length && <p className="text-xs text-slate-500">No case studies yet.</p>}</div>
            </div>
            <Field label="Custom notes"><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Timeline, what's included first, guarantees…" /></Field>
            <Button className="w-full" disabled={!lead} onClick={generate}><Printer className="h-4 w-4" /> Generate printable proposal</Button>
            <p className="text-[11px] text-slate-500">Opens a branded HTML page – use Print → Save as PDF. {lead && !audit && "Tip: run an audit first so the proposal includes real findings."}</p>
          </Card>
          <Card title="Preview" className="lg:col-span-2">
            {!lead ? <p className="text-sm text-slate-500">Select a lead.</p> : (
              <div className="space-y-3 text-sm">
                <div className="text-lg font-semibold">Growth Proposal for {lead.name}</div>
                <div className="text-xs text-slate-500">{lead.subs.toLocaleString()} subs · {lead.niche}{audit ? ` · audit score ${audit.overall}/100` : " · no audit yet"}</div>
                {audit && <p className="text-xs">{audit.summary}</p>}
                {audit && <ul className="list-inside list-disc text-xs">{audit.problems.slice(0, 4).map((p, i) => <li key={i}><b>{p.category}:</b> {p.issue}</li>)}</ul>}
                <div className="grid gap-2 sm:grid-cols-3">{packages?.map((p) => <div key={p.id} className={`rounded-lg border p-3 text-xs ${p.id === pkgId ? "border-brand" : "border-slate-200 dark:border-slate-800"}`}><div className="font-semibold">{p.name}</div><div className="text-lg font-bold">${p.price}<span className="text-[10px] font-normal text-slate-500"> {p.period}</span></div><ul className="mt-1 list-inside list-disc text-slate-500">{p.deliverables.slice(0, 4).map((d) => <li key={d}>{d}</li>)}</ul></div>)}</div>
              </div>
            )}
          </Card>
        </div>
      )}

      {tab === "packages" && <Packages packages={packages ?? []} />}
      {tab === "cases" && <Cases cases={cases ?? []} />}
      {tab === "proof" && <ProofChecklist />}
    </div>
  );
}

function Packages({ packages }: { packages: Package[] }) {
  const { toast } = useToast();
  const update = (p: Package, patch: Partial<Package>) => db.packages.update(p.id!, patch);
  return (
    <div className="space-y-3">
      <div className="grid gap-4 lg:grid-cols-3">
        {packages.map((p) => (
          <Card key={p.id} className={p.highlight ? "ring-2 ring-brand" : ""}>
            <div className="mb-3 flex items-center gap-2"><Input className="font-semibold" value={p.name} onChange={(e) => update(p, { name: e.target.value })} /><Switch checked={p.highlight} onChange={(v) => update(p, { highlight: v })} label="Featured" /></div>
            <div className="mb-3 grid grid-cols-2 gap-2">
              <Field label="Price ($)"><Input type="number" value={p.price} onChange={(e) => update(p, { price: Number(e.target.value) })} /></Field>
              <Field label="Billing"><Select value={p.period} onChange={(e) => update(p, { period: e.target.value as Package["period"] })}><option value="one-time">One-time</option><option value="per month">Per month</option></Select></Field>
            </div>
            <Field label="Deliverables (one per line)"><Textarea className="min-h-[160px] text-xs" value={p.deliverables.join("\n")} onChange={(e) => update(p, { deliverables: e.target.value.split("\n") })} /></Field>
            <div className="mt-2 flex justify-between"><Button size="sm" variant="ghost" onClick={() => copyText(`${p.name} – $${p.price} ${p.period}\n${p.deliverables.map((d) => `• ${d}`).join("\n")}`).then(() => toast("Copied"))}><Copy className="h-3.5 w-3.5" /> Copy</Button><Button size="sm" variant="ghost" onClick={() => db.packages.delete(p.id!)}><Trash2 className="h-3.5 w-3.5" /></Button></div>
          </Card>
        ))}
      </div>
      <div className="flex gap-2">
        <Button variant="outline" onClick={() => db.packages.add({ name: "Custom", price: 0, period: "one-time", deliverables: [""], highlight: false })}><Plus className="h-4 w-4" /> Add package</Button>
        <Button variant="ghost" onClick={async () => { await db.packages.clear(); await db.packages.bulkAdd(DEFAULT_PACKAGES); }}>Reset defaults</Button>
      </div>
    </div>
  );
}

function Cases({ cases }: { cases: CaseStudy[] }) {
  const { toast } = useToast();
  const empty: CaseStudy = { client: "", niche: NICHES[0], beforeCtr: 0, afterCtr: 0, beforeViews: 0, afterViews: 0, beforeSubs: 0, afterSubs: 0, notes: "", createdAt: nowIso() };
  const [draft, setDraft] = useState<CaseStudy>(empty);
  const onFile = (file: File) => {
    if (file.size > 1_500_000) return toast("Keep screenshots under 1.5 MB", "warning");
    const r = new FileReader();
    r.onload = () => setDraft((d) => ({ ...d, screenshot: String(r.result) }));
    r.readAsDataURL(file);
  };
  const snippet = (c: CaseStudy) => `Case study: ${c.client} (${c.niche}) – CTR ${c.beforeCtr}% → ${c.afterCtr}%, views ${c.beforeViews.toLocaleString()} → ${c.afterViews.toLocaleString()}, subs ${c.beforeSubs.toLocaleString()} → ${c.afterSubs.toLocaleString()}.`;
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Add case study" className="space-y-2">
        <Field label="Client / channel"><Input value={draft.client} onChange={(e) => setDraft({ ...draft, client: e.target.value })} /></Field>
        <Field label="Niche"><Select value={draft.niche} onChange={(e) => setDraft({ ...draft, niche: e.target.value })}>{NICHES.map((n) => <option key={n}>{n}</option>)}</Select></Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="CTR before %"><Input type="number" step="0.1" value={draft.beforeCtr} onChange={(e) => setDraft({ ...draft, beforeCtr: +e.target.value })} /></Field>
          <Field label="CTR after %"><Input type="number" step="0.1" value={draft.afterCtr} onChange={(e) => setDraft({ ...draft, afterCtr: +e.target.value })} /></Field>
          <Field label="Views before"><Input type="number" value={draft.beforeViews} onChange={(e) => setDraft({ ...draft, beforeViews: +e.target.value })} /></Field>
          <Field label="Views after"><Input type="number" value={draft.afterViews} onChange={(e) => setDraft({ ...draft, afterViews: +e.target.value })} /></Field>
          <Field label="Subs before"><Input type="number" value={draft.beforeSubs} onChange={(e) => setDraft({ ...draft, beforeSubs: +e.target.value })} /></Field>
          <Field label="Subs after"><Input type="number" value={draft.afterSubs} onChange={(e) => setDraft({ ...draft, afterSubs: +e.target.value })} /></Field>
        </div>
        <Field label="Screenshot (stored as base64)"><input type="file" accept="image/*" className="text-xs" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} /></Field>
        <Field label="Notes"><Textarea className="min-h-[60px]" value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} /></Field>
        <Button className="w-full" disabled={!draft.client} onClick={async () => { await db.caseStudies.add({ ...draft, createdAt: nowIso() }); setDraft(empty); toast("Case study saved"); }}><Plus className="h-4 w-4" /> Save</Button>
      </Card>
      <div className="space-y-3 lg:col-span-2">
        {!cases.length && <Card><p className="text-sm text-slate-500">No case studies yet. Even a free audit that lifted one client's CTR is proof – add it here and insert it into messages & proposals.</p></Card>}
        {cases.map((c) => (
          <Card key={c.id} className="flex gap-4">
            {c.screenshot ? <img src={c.screenshot} className="h-24 w-36 shrink-0 rounded-lg object-cover" alt="" /> : <div className="flex h-24 w-36 shrink-0 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800"><ImageIcon className="h-6 w-6 text-slate-400" /></div>}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2"><b>{c.client}</b><span className="text-xs text-slate-500">{c.niche}</span></div>
              <div className="mt-1 grid grid-cols-3 gap-2 text-xs"><div>CTR <b>{c.beforeCtr}% → {c.afterCtr}%</b></div><div>Views <b>{c.beforeViews.toLocaleString()} → {c.afterViews.toLocaleString()}</b></div><div>Subs <b>{c.beforeSubs.toLocaleString()} → {c.afterSubs.toLocaleString()}</b></div></div>
              {c.notes && <p className="mt-1 text-xs text-slate-500">{c.notes}</p>}
              <div className="mt-2 flex gap-2"><Button size="sm" variant="outline" onClick={() => copyText(snippet(c)).then(() => toast("Snippet copied – paste as {case_study}"))}><Copy className="h-3.5 w-3.5" /> Copy snippet</Button><Button size="sm" variant="ghost" onClick={() => db.caseStudies.delete(c.id!)}><Trash2 className="h-3.5 w-3.5" /></Button></div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

const PROOF_ITEMS = [
  "Turn every result (even a free audit) into a 60-second before/after Short",
  "Post one LinkedIn case-study carousel per week (problem → fix → numbers)",
  "Share a Facebook post in 2 niche groups: 'I audited 10 coach channels, here's what I found'",
  "Pin a 'How I lifted CTR 28%' video on your own channel",
  "Add 3 testimonials/screenshots to your portfolio page",
  "Record a Loom audit of a public channel and post it (permission-free teaching content)",
  "Ask every Won client for a 2-line testimonial at day 30",
];

function ProofChecklist() {
  const key = "channelhunter.proof";
  const [done, setDone] = useState<Record<string, boolean>>(() => JSON.parse(localStorage.getItem(key) ?? "{}"));
  const toggle = (k: string, v: boolean) => { const n = { ...done, [k]: v }; setDone(n); localStorage.setItem(key, JSON.stringify(n)); };
  return (
    <Card title="Proof checklist" description="Publishing proof turns cold outreach into inbound leads. Tick what you've shipped.">
      <div className="space-y-2">{PROOF_ITEMS.map((i) => <Checkbox key={i} checked={!!done[i]} onChange={(v) => toggle(i, v)} label={i} />)}</div>
      <p className="mt-3 text-[11px] text-slate-500">Log each post on the Dashboard ("+ Log content post") to track your weekly goal.</p>
    </Card>
  );
}
