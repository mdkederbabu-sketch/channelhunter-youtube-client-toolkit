import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ClipboardCheck, Users, Send, BellRing, Megaphone, RotateCcw } from "lucide-react";
import { useSettings } from "@/lib/settings";
import { PageHeader } from "@/components/Layout";
import { Button, Card, Checkbox, Progress } from "@/components/ui";

const STEPS = [
  { key: "find", icon: Search, title: "Find channels", time: "20 min", to: "/finder", items: ["Search 1 niche keyword with a preset (Page 2-5 / Hidden gems / Business)", "Skip 1M+ and dead channels (auto-flagged)", "Add 5-10 channels that have business signals to leads"] },
  { key: "audit", icon: ClipboardCheck, title: "Audit", time: "5 min each", to: "/audit", items: ["Fetch last 15-20 videos", "Toggle thumbnail checks for 12 thumbnails", "Tick channel-level + AEO checklists", "Save → proofs are created automatically"] },
  { key: "contact", icon: Users, title: "Find contact", time: "3 min each", to: "/leads", items: ["About tab → business email", "Banner / description links → website contact page", "LinkedIn profile of the owner", "Tick 'Contact found?'"] },
  { key: "send", icon: Send, title: "Send message", time: "3 min each", to: "/outreach", items: ["Pick the strongest proof", "Generate 3 variants, pick one, personalise one more line", "Check the spam meter is green", "Copy → paste → send manually → 'Mark as sent'"] },
  { key: "followup", icon: BellRing, title: "Follow-ups", time: "10 min", to: "/followups", items: ["Clear Overdue first, then Today", "Day 3: quick idea · Day 7: mini tip · Day 14: last note", "Move replies to 'Replied' to stop the sequence"] },
  { key: "post", icon: Megaphone, title: "Post content", time: "15 min", to: "/proposals", items: ["Publish 1 proof piece (Short, LinkedIn or Facebook post)", "Log it on the Dashboard (+ Log content post)"] },
];

export default function RoutinePage() {
  const [settings] = useSettings();
  const key = `channelhunter.routine.${new Date().toDateString()}`;
  const [done, setDone] = useState<Record<string, boolean>>(() => JSON.parse(localStorage.getItem(key) ?? "{}"));
  const toggle = (k: string, v: boolean) => { const n = { ...done, [k]: v }; setDone(n); localStorage.setItem(key, JSON.stringify(n)); };
  const total = STEPS.reduce((s, st) => s + st.items.length, 0);
  const completed = Object.values(done).filter(Boolean).length;
  const g = settings.weeklyGoals;

  return (
    <div className="space-y-5">
      <PageHeader title="Daily Hunting Routine" description="~90 minutes a day. Resets every day. Consistency beats volume – 5 great messages beat 50 generic ones." action={<Button variant="ghost" onClick={() => { setDone({}); localStorage.removeItem(key); }}><RotateCcw className="h-4 w-4" /> Reset today</Button>} />
      <Card>
        <div className="mb-2 flex justify-between text-sm"><span className="font-medium">Today's progress</span><span>{completed}/{total}</span></div>
        <Progress value={(completed / total) * 100} color={completed === total ? "bg-emerald-500" : undefined} />
        <p className="mt-2 text-xs text-slate-500">Weekly targets: {g.found} channels · {g.audits} audits · {g.messages} messages · {g.posts} posts → daily ≈ {Math.ceil(g.found / 5)} channels, {Math.ceil(g.audits / 5)} audits, {Math.ceil(g.messages / 5)} messages.</p>
      </Card>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {STEPS.map((s, i) => (
          <Card key={s.key} title={<span className="flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand/10 text-[11px] font-bold text-brand">{i + 1}</span>{s.title}</span>} description={s.time} action={<Link to={s.to} className="text-xs text-brand hover:underline">Open →</Link>}>
            <div className="space-y-2">{s.items.map((it) => <Checkbox key={it} checked={!!done[`${s.key}:${it}`]} onChange={(v) => toggle(`${s.key}:${it}`, v)} label={<span className={done[`${s.key}:${it}`] ? "text-slate-400 line-through" : ""}>{it}</span>} />)}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
