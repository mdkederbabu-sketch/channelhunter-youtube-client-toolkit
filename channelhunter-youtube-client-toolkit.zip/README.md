# ChannelHunter

A **free, 100% client-side** client-hunting toolkit for freelancers who sell YouTube SEO, AEO/GEO, thumbnail & CTR optimisation, channel optimisation, analytics and growth strategy.

- **No login, no signup, no backend.** The whole website is the tool – it opens straight to the dashboard.
- **All data lives in your browser** (IndexedDB via Dexie + localStorage). Backup/restore as JSON, export leads as CSV.
- **No paid APIs, no AI calls.** Outreach messages come from a built-in template engine (variables + randomized phrasing variants).
- The **only external API is YouTube Data API v3**, using *your own free key*. Without a key the app runs in **Manual Mode**.
- **Compliance-first:** official API only, no scraping, no email harvesting, no auto-sending. *This tool helps you write personalized, low-volume outreach. Sending is always manual.*

## Run locally

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # static build in dist/
npm run preview    # preview the production build
npx tsx tests/engine.test.ts   # unit tests for the pure audit / scoring / outreach engines
```

## Stack

Vite · React 19 · TypeScript · Tailwind CSS v4 · shadcn-style UI primitives · Recharts · dnd-kit · Dexie (IndexedDB) · zod · date-fns · lucide-react · react-router (hash routing, works on any static host) · PWA manifest + service worker.

## Folder structure

```
src/
  lib/
    types.ts       – shared domain types (Lead, Audit, Template, Task …)
    db.ts          – Dexie database, activity log, 24h API cache, quota tracking
    settings.ts    – zod-validated settings in localStorage (+ React hook)
    youtube.ts     – quota-aware YouTube Data API v3 client (search/channels/playlistItems/videos)
    audit.ts       – pure 5-minute audit engine (titles, descriptions, tags, performance, thumbnails, channel, AEO/GEO)
    scoring.ts     – pure lead scoring (Hot / Warm / Cold) with editable weights
    templates.ts   – 72 built-in first-message templates (6 services × 4 × EN/Bangla/Banglish) + follow-ups + comments
    outreach.ts    – template engine: {variables}, [spin|syntax], 3 variants, spam-risk checker, CSV helpers
    leads.ts       – lead lifecycle: create, re-score, mark-as-sent → follow-up tasks
    backup.ts      – JSON backup/restore, CSV import/export, delete-all
    report.ts      – branded printable HTML for audit reports and proposals (window.print → PDF)
  components/      – Layout (sidebar, shortcuts, quota meter), LeadDrawer, Onboarding, UI primitives, toasts, ErrorBoundary
  pages/           – Dashboard, ChannelFinder, Audit, Leads (+Contacts), Outreach, FollowUps, Pipeline, Proposals, Analytics, Settings, Routine
public/            – manifest.webmanifest, sw.js
tests/             – engine.test.ts (node:assert, run with tsx)
```

## The hunting workflow the app is built around

1. **Find channels** (Channel Finder) – 1K-100K subs, active, business niches. 1M+ and dead channels (no upload in 180 days) are auto-flagged *Skip*.
2. **5-minute audit** (Audit Engine) – auto SEO/performance metrics + thumbnail & channel checklists → Top 5 problems become reusable **pitch proofs**.
3. **Score & qualify** – Hot (75+) / Warm (50-74) / Cold (<50), re-scored after every audit.
4. **Find contact manually** (Leads → Contact tab) – quick links to the About page, Google, LinkedIn, website.
5. **Send a personalised message** (Outreach Studio) – compliment + specific problem + free value + tiny ask. Spam meter. Copy → paste → send manually → *Mark as sent*.
6. **Follow up** – Day 1, 3, 7, 14 reminders with drafts ready. Auto-stops on Replied / Won / Lost / Do-not-contact.
7. **Pipeline → Client** (Kanban) and build **proof** (case studies, proposals).

Keyboard shortcuts: `/` focus search · `N` new lead.

## Quota strategy (YouTube Data API)

| Call | Cost | How ChannelHunter uses it |
|---|---|---|
| `search.list` | **100** | Only on explicit confirm. "Page 2-5 discovery" skips page 1. |
| `channels.list` | 1 | Batched up to 50 IDs. Also resolves `@handles` via `forHandle`. |
| `playlistItems.list` | 1 | Uploads playlist (`UC…` → `UU…`) instead of `search.list` for recent videos. |
| `videos.list` | 1 | Batched up to 50 IDs for stats/duration/tags. |

Every response is cached in IndexedDB for 24 h. Units are tracked per (Pacific) day with a warning at 80 % of 10,000.

## How to get a free YouTube API key (3 minutes)

1. Go to <https://console.cloud.google.com/> and create a project.
2. **APIs & Services → Library** → search **YouTube Data API v3** → **Enable**.
3. **APIs & Services → Credentials → Create credentials → API key**. Copy it into ChannelHunter → Settings.
4. Click **Edit API key** → *Application restrictions:* **HTTP referrers** → add your deployed site, e.g. `https://your-site.netlify.app/*` (and `http://localhost:5173/*` for dev). *API restrictions:* restrict to **YouTube Data API v3**.
5. Free quota is 10,000 units/day, resets at midnight Pacific time. No billing account needed.

The key is stored only in your browser's localStorage and sent only to `googleapis.com`.

## Deploy for free

The build is fully static (`dist/`).

**Netlify** – New site from Git → build command `npm run build`, publish directory `dist`. (Or drag-and-drop the `dist` folder on app.netlify.com/drop.)

**Vercel** – Import repo → Framework: Vite → build `npm run build`, output `dist`.

**Cloudflare Pages** – Create project → build `npm run build`, output `dist`.

**GitHub Pages** – `npm run build`, then push `dist/` to a `gh-pages` branch (e.g. `npx gh-pages -d dist`) and enable Pages for that branch. Hash routing means no 404 rewrites are needed on any host.

After deploying, add the site URL as an HTTP-referrer restriction on your API key.

## Backup

Settings → **Export backup (JSON)** saves every table + settings. **Restore backup** on any device/browser. Leads can also be exported/imported as CSV (`name, channel_url, subs, niche, email, website, notes, avg_views, last_upload`).

## Privacy & compliance

- Uses only the official YouTube Data API with your own key – no scraping.
- Contact details are entered by you from public business-inquiry sources (About tab, website, LinkedIn). No harvesting.
- Nothing is sent automatically; the app only logs what *you* sent manually and reminds you to follow up.
