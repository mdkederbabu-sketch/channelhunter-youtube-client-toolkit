/**
 * Lightweight unit tests for the pure engines (no framework needed).
 * Run:  npx tsx tests/engine.test.ts
 */
import assert from "node:assert/strict";
import { buildBuiltInTemplates } from "../src/lib/templates";
import { generateVariants, parseCsv, render, resolveSpins, spamCheck, toCsv } from "../src/lib/outreach";
import { parseManualVideos, runAudit } from "../src/lib/audit";
import { labelFor, scoreLead, skipReason } from "../src/lib/scoring";
import { SettingsSchema } from "../src/lib/settings";
import { parseChannelInput, parseDuration, detectBusinessSignals } from "../src/lib/youtube";

const settings = SettingsSchema.parse({});
let passed = 0;
const test = (name: string, fn: () => void) => {
  fn();
  passed++;
  console.log("✓", name);
};

test("built-in templates: 4 per service per language + follow-ups + comments", () => {
  const t = buildBuiltInTemplates();
  assert.equal(t.filter((x) => x.type === "first").length, 6 * 4 * 3);
  assert.equal(t.filter((x) => x.type.startsWith("followup")).length, 3 * 3);
  assert.equal(t.filter((x) => x.type === "comment").length, 3 * 3);
});

test("example SEO template renders exactly", () => {
  const seo = buildBuiltInTemplates().find((t) => t.name === "YouTube SEO – Specific compliment (English)")!;
  const out = render(seo.body, { name: "Sara", video_title: "Pricing 101", issue: "titles lack keywords", fix: "adding the keyword first", ctr_gain: "20-30%" }, 0);
  assert.equal(out, "Hi Sara, I watched 'Pricing 101' and the content is solid. One thing I noticed: titles lack keywords. That's likely holding back search discovery. A quick fix would be adding the keyword first, which can lift CTR by 20-30%. Want me to send a free 2-minute audit of your channel?");
});

test("spin syntax picks different options per variant", () => {
  assert.equal(resolveSpins("[a|b] [x|y|z]", 0), "a y");
  assert.equal(resolveSpins("[a|b] [x|y|z]", 1), "b z");
});

test("3 variants differ", () => {
  const seo = buildBuiltInTemplates().find((t) => t.type === "first" && t.language === "English")!;
  const v = generateVariants(seo, { name: "A", video_title: "B", issue: "c", fix: "d", ctr_gain: "20%", channel: "Ch", keyword: "k", my_name: "me", portfolio_link: "", calendar_link: "" }, "Friendly", settings, "LinkedIn DM");
  assert.equal(v.length, 3);
  assert.notEqual(v[0].body, v[1].body);
});

test("spam checker flags generic/pricey messages and passes personal ones", () => {
  assert.equal(spamCheck("I can grow your channel GUARANTEED for $500 http://a.com http://b.com", 90).level, "red");
  assert.equal(spamCheck("Hi Sara, I watched 'Pricing 101' and noticed the title has no keyword. Want a free 2-minute audit?", 90).level, "green");
});

test("csv round-trip", () => {
  const rows = parseCsv(toCsv([{ name: "Acme, Inc", subs: 1200 }]));
  assert.deepEqual(rows, [{ name: "Acme, Inc", subs: "1200" }]);
});

test("youtube helpers", () => {
  assert.deepEqual(parseChannelInput("https://youtube.com/@mkbhd"), { kind: "handle", value: "@mkbhd" });
  assert.equal(parseChannelInput("https://www.youtube.com/channel/UC1234567890123456789012")?.kind, "id");
  assert.equal(parseDuration("PT1H2M3S"), 3723);
  assert.ok(detectBusinessSignals("Join my course at https://x.com").includes("course"));
});

test("audit produces scores, problems and proofs", () => {
  const videos = parseManualVideos("my vlog ;; 100 ;; 2 ;; 0 ;; 2025-01-15 ;; 300 ;; short\nanother ;; 300 ;; 5 ;; 1 ;; 2025-02-01 ;; 700 ;; ");
  const ch = { channelId: "UCx", name: "Sara", subs: 12000, totalViews: 1, videoCount: 10, lastUpload: new Date().toISOString() };
  const a = runAudit({ channel: ch, videos, niche: "Coach", thumbChecks: {}, channelChecks: {}, aeoChecks: {} });
  assert.ok(a.overall >= 0 && a.overall <= 100);
  assert.ok(a.problems.length >= 3);
  assert.ok(a.problems.every((p) => p.issue && p.fix));
  assert.equal(a.quickWins.length, 5);
});

test("scoring labels and skip rules", () => {
  assert.equal(labelFor(80), "Hot");
  assert.equal(labelFor(50), "Warm");
  assert.equal(labelFor(49), "Cold");
  const big = { channelId: "UCy", name: "Big", subs: 2_000_000, totalViews: 1, videoCount: 10 };
  assert.equal(skipReason(big), "1M+ subscribers");
  assert.ok(scoreLead({ channel: big, weights: settings.weights, subRange: settings.subRange, targetNiches: settings.niches }).score <= 25);
});

console.log(`\n${passed} tests passed`);
